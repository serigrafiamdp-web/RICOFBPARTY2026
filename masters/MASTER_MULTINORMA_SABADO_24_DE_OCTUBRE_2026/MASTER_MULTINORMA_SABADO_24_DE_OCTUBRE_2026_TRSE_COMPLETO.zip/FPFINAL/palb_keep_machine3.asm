; TEST70B - no alias after SYSINFO; 10 bytes in $3BDC-$3BE5.
* = $3BDC
    sta $8BBF
    lda #0
    sta $8B9E
    pla
    rts
