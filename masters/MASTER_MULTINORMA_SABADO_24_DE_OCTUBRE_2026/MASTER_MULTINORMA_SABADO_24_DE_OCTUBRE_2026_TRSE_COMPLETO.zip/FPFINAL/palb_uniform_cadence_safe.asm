; TEST70B: 50 bytes en FFC8-FFF9. Mismo salto final a $8B10.
; A preservado. ID 1: -1/44. ID 3: -1/200 except stages23+, como Drean.
; ID 2/4: sin cambios. Fase en $8B9E, temp threshold en $8B9F.
* = $FFC8
palb_uniform_cadence:
    pha
    lda $8BBF
    lsr
    bcc done
    beq old
    lda $3946
    cmp #23
    bcs done
    lda #200
    bne set_threshold
old:
    lda #44
set_threshold:
    sta $8B9F
    lda $8B9E
    clc
    adc $3902
    cmp $8B9F
    bcc store
    sbc $8B9F
    dec $3902
store:
    sta $8B9E
done:
    pla
    jmp $8B10
