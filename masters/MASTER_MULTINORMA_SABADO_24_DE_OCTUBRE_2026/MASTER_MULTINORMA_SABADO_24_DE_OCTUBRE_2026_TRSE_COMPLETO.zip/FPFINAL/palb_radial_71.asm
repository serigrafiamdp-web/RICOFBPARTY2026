; TEST75E: PAL-B only, stages 14..21 constant 2 pixels per tick.
; Enter only from the PAL-B ($38C0=3) path at $8B2F; Drean bypasses.
; Main loop now allows every frame for PAL-B stages 14..22; the
; pixel step is set here AFTER all original global caps and bonuses.
; 6502 A changed, X and Y untouched. Original accumulator restored by
; existing TEST71 resume helper at $3970 (LDA $3757, JMP $8B32).
; Occupied $EBE8-$EBF9 (18 B), no overlap with outro colors at $EC00.
* = $EBE8
palb_radial_71:
    lda $3946          ; show_stage
    sec
    sbc #14
    cmp #8             ; stage14..21 only, stage22 inherits 2/3 from MAIN
    bcs resume         ; 5 bytes ahead
    lda #2
    sta $3902          ; scroll_step_effective
resume:
    jmp $3970

; Existing resume helper left unchanged ($3970..$3975):
* = $3970
palb_radial_resume_71:
    lda $3757          ; original bonus phase
    jmp $8B32          ; continue original CLC in helper
