; TEST70B: cloned PAL-B and Drean logical clocks, EXACT 23 bytes $33E8-$33FE
* = $33E8
    lda $38C0
    cmp #3
    beq palb_clock
drean_clock:
    lda #1
    sta $38C7
    jmp $706C
palb_clock:
    lda #1
    sta $38C7
    jmp $706C
