"""Experimental OUTRO-only third voice alternator, byte-for-byte derived from approved peak-15 ZIP.

Only change RAS 3-byte hooks and *unused* scroll-bin FF padding. Do not touch the MASTER.
Wave definition = each $80-phase half, one wave per SID. Horn: waves 1,10,19,28,...
"""
from pathlib import Path
import zipfile,re
from build_outro_extra_voices import Asm,variants

ROOT=Path('/mnt/data')
BASE=ROOT/'DEMO_PRUEBA_OUTRO_PICO_MAXIMO_SID_15_TIMING_APROBADO.zip'
DEST=ROOT/'DEMO_PRUEBA_OUTRO_TRES_SONIDOS_ALTERNADOS_BOCINA_CICLOS_1_10.zip'
ORIGIN=0xF900  # after text FF at F8A3; well before dictionary at FC7B
SCROLL_BASE=0xF200
DICT_OFF=0xA7B
TEXT_END_OFF=0x6A3


def assemble():
    a=Asm(ORIGIN)
    a.abs(0x4C,'init');a.abs(0x4C,'tick')
    a.mark('init')
    a.abs(0x8E,'profile')  # STX profile BEFORE calling original engine
    a.lohi(0x20,0x8400)
    a.op(0x48,0x98,0x48)  # save engine A, Y
    a.op(0xA9,0)
    for field in ('wave_index','last_half','mode'): a.abs(0x8D,field)
    a.abs(0x20,'configure')
    a.op(0x68,0xA8,0x68);a.abs(0xAE,'profile');a.op(0x60)

    a.mark('tick')
    a.abs(0x8D,'phase');a.abs(0x8E,'profile')
    a.lohi(0x20,0x8BC1)  # approved sound once only
    a.op(0x48,0x98,0x48)
    a.abs(0xAD,'phase');a.op(0x29,0x80);a.abs(0xCD,'last_half')
    a.rel(0xF0,'same_wave')
    a.abs(0x8D,'last_half')
    a.abs(0xEE,'wave_index')  # increment only at 0x7F->0x80, 0xFF->0x00
    a.abs(0xAD,'wave_index');a.op(0xC9,9);a.rel(0x90,'choose')
    a.op(0xA9,0);a.abs(0x8D,'wave_index')
    a.mark('choose')
    a.abs(0xAD,'wave_index');a.rel(0xF0,'choose_horn')
    a.op(0x29,1);a.rel(0xF0,'choose_rumble')
    a.op(0xA9,1);a.rel(0xD0,'store_mode')
    a.mark('choose_rumble');a.op(0xA9,2);a.rel(0xD0,'store_mode')
    a.mark('choose_horn');a.op(0xA9,0)
    a.mark('store_mode');a.abs(0x8D,'mode');a.abs(0x20,'configure')
    a.mark('same_wave');a.abs(0x20,'gates')
    a.op(0x68,0xA8,0x68);a.abs(0xAE,'profile');a.op(0x60)

    # On each half-cycle boundary: stop old gate, switch waveform/frequency/ADSR,
    # change ONLY voice1 filter routing (voice2 ambience stays unfiltered).
    a.mark('configure')
    a.op(0xA9,0,0x8D,0x04,0xD4)
    a.abs(0xAE,'profile');a.rel(0xF0,'second_gate_off')
    a.op(0xA0,0x04,0x91,0xFB)
    a.mark('second_gate_off')
    a.abs(0xAE,'mode');a.abs(0xBD,'offsets');a.op(0xAA,0xA0,0)
    a.mark('params_loop')
    a.abs(0xBD,'params1');a.op(0x99,0x00,0xD4)
    a.abs(0xAD,'profile');a.rel(0xF0,'skip_second_param')
    a.abs(0xBD,'params2');a.op(0x91,0xFB)
    a.mark('skip_second_param')
    a.op(0xE8,0xC8,0xC0,7);a.rel(0xD0,'params_loop')
    a.abs(0xAD,'mode');a.op(0xC9,1);a.rel(0xF0,'filter_water')
    a.op(0xA9,0x24);a.rel(0xD0,'filter_write')
    a.mark('filter_water');a.op(0xA9,0x25)
    a.mark('filter_write');a.op(0x8D,0x17,0xD4)
    a.abs(0xAE,'profile');a.rel(0xF0,'configure_done')
    a.op(0xA0,0x17,0x91,0xFB)
    a.mark('configure_done');a.op(0x60)

    a.mark('gates')
    a.abs(0xAD,'mode');a.rel(0xF0,'horn')
    a.op(0xC9,1);a.rel(0xF0,'water')
    a.abs(0x4C,'rumble')
    # Longer horn than original 4 phases: 12 phases 0x10..0x1B.
    # ADSR, saw waveform, frequencies exactly as liked in repaired horn trial.
    a.mark('horn')
    a.abs(0xAD,'phase');a.op(0x29,0x7F,0xC9,0x10);a.rel(0x90,'horn_off')
    a.op(0xC9,0x1C);a.rel(0xB0,'horn_off')
    a.op(0xA9,0x21);a.rel(0xD0,'horn_write')
    a.mark('horn_off');a.op(0xA9,0x20)
    a.mark('horn_write');a.op(0x8D,0x04,0xD4)
    a.abs(0xAE,'profile');a.rel(0xF0,'horn_done')
    a.op(0xA0,0x04,0x91,0xFB)
    a.mark('horn_done');a.op(0x60)

    # Identical gating logic and original frequencies of water trial.
    a.mark('water')
    a.abs(0xAD,'phase');a.op(0xC9,0x60);a.rel(0x90,'water_1off')
    a.op(0xC9,0x80);a.rel(0xB0,'water_1off')
    a.op(0xA9,0x81);a.rel(0xD0,'water_1write')
    a.mark('water_1off');a.op(0xA9,0x80)
    a.mark('water_1write');a.op(0x8D,0x04,0xD4)
    a.abs(0xAE,'profile');a.rel(0xF0,'water_done')
    a.abs(0xAD,'phase');a.op(0xC9,0xE0);a.rel(0x90,'water_2off')
    a.op(0xA9,0x81);a.rel(0xD0,'water_2write')
    a.mark('water_2off');a.op(0xA9,0x80)
    a.mark('water_2write');a.op(0xA0,0x04,0x91,0xFB)
    a.mark('water_done');a.op(0x60)

    # Identical gating logic and original frequencies of rumble trial.
    a.mark('rumble')
    a.abs(0xAD,'phase');a.op(0x18,0x69,0x20,0xC9,0x80);a.rel(0xB0,'rumble_1off')
    a.op(0xA9,0x11);a.rel(0xD0,'rumble_1write')
    a.mark('rumble_1off');a.op(0xA9,0x10)
    a.mark('rumble_1write');a.op(0x8D,0x04,0xD4)
    a.abs(0xAE,'profile');a.rel(0xF0,'rumble_done')
    a.abs(0xAD,'phase');a.op(0x18,0x69,0xA0,0xC9,0x80);a.rel(0xB0,'rumble_2off')
    a.op(0xA9,0x11);a.rel(0xD0,'rumble_2write')
    a.mark('rumble_2off');a.op(0xA9,0x10)
    a.mark('rumble_2write');a.op(0xA0,0x04,0x91,0xFB)
    a.mark('rumble_done');a.op(0x60)

    a.mark('offsets');a.op(0,7,14)
    a.mark('params1')
    for name in ('BOCINA_LEJANA','AGUA_ESPUMA','RUMOR_GRAVE'):a.op(*variants[name]['params1'])
    a.mark('params2')
    for name in ('BOCINA_LEJANA','AGUA_ESPUMA','RUMOR_GRAVE'):a.op(*variants[name]['params2'])
    for field in ('profile','phase','wave_index','last_half','mode'):
        a.mark(field);a.op(0)
    b=a.done()
    assert ORIGIN+len(b) < SCROLL_BASE+DICT_OFF,(hex(ORIGIN+len(b)),len(b))
    assert int.from_bytes(b[1:3],'little')==a.l['init']
    assert int.from_bytes(b[4:6],'little')==a.l['tick']
    return a,b


def build():
    asm,helper=assemble()
    with zipfile.ZipFile(BASE) as z:
        assert z.testzip() is None
        original={name:z.read(name) for name in z.namelist()}
    src=dict(original)
    ras=src['DEMO.ras']
    old=b'        jsr $8400\n        jsr $8B07             ; OUTRO:'
    new=f'        jsr ${ORIGIN:04X}\n        jsr $8B07             ; OUTRO:'.encode()
    assert ras.count(old)==1
    ras=ras.replace(old,new,1)
    old=b'        jsr $8BC1             ; OUTRO-only: curva aprobada + ~20% en TODA la envolvente.'
    new=f'        jsr ${ORIGIN+3:04X}             ; OUTRO-only: motor aprobado + alternancia voz extra.'.encode()
    assert ras.count(old)==1
    ras=ras.replace(old,new,1)
    assert ras.count(f'jsr ${ORIGIN:04X}'.encode())==1 and ras.count(f'jsr ${ORIGIN+3:04X}'.encode())==1
    src['DEMO.ras']=ras
    scroll=bytearray(src['outro_line25_scroll.bin'])
    offset=ORIGIN-SCROLL_BASE
    assert len(scroll)==0xDC8
    assert scroll[TEXT_END_OFF]==255 and all(x==255 for x in scroll[TEXT_END_OFF+1:DICT_OFF])
    assert offset>=TEXT_END_OFF+0x50 and offset+len(helper)<DICT_OFF
    assert all(x==255 for x in scroll[offset:offset+len(helper)])
    scroll[offset:offset+len(helper)]=helper
    src['outro_line25_scroll.bin']=bytes(scroll)
    assert scroll[:TEXT_END_OFF+1]==original['outro_line25_scroll.bin'][:TEXT_END_OFF+1]
    assert scroll[DICT_OFF:]==original['outro_line25_scroll.bin'][DICT_OFF:]
    assert {n for n in original if original[n]!=src[n]}=={'DEMO.ras','outro_line25_scroll.bin'}
    inc={v.decode() for v in re.findall(rb'incbin\("([^"\r\n]+)"',ras)}
    assert inc<=src.keys(),inc-src.keys()

    # Address-labelled genuine instruction data, plus byte-reproducible builder source.
    hdr=[
        '; RICOS 2026 EXPERIMENTO: 3 opciones en voz 1 de cada SID, solo outro.',
        f'; Entradas: ${ORIGIN:04X} INIT, ${ORIGIN+3:04X} TICK. Bytes generados: {len(helper)}.',
        '; Fase de cada ola: 128 unidades. 1a bocina en ola 1, siguiente en 10, 19, 28...',
        '; Bocina: misma afinacion, diente de sierra y ADSR que prueba aprobada; GATE $10..$1B (antes $10..$13).',
        '; El ciclo se detecta por cruce bit7 de fase, no por frames; se mantiene timing original.',
        '; Al cambiar de ciclo: cortar GATE previo, configurar nueva voz y ruteo filtro voz1 SOLO agua.',
        '; Las voces 2/3, la intro, el motor $8400/$8BC1, la musica y la parte visual no cambian.',
        '; Este archivo documenta el binario incrustado; el script Python adjunto contiene las etiquetas y emite estos bytes.',
    ]
    for i in range(0,len(helper),16):
        hdr.append(f'; ${ORIGIN+i:04X}: '+','.join(f'${x:02X}' for x in helper[i:i+16]))
    src['outro_voice1_tres_efectos.asm']=('\n'.join(hdr)+'\n').encode('utf8')
    src['LEEME_OUTRO_TRES_SONIDOS.txt']=(
        'RICOS FLASH PARTY 2026 - PRUEBA REVERSIBLE: TRES SONIDOS ALTERNADOS\n'
        'MASTER NO MODIFICADO. Base: DEMO_PRUEBA_OUTRO_PICO_MAXIMO_SID_15_TIMING_APROBADO.zip.\n'
        'Una ola es cada semiciclo de 128 fases: mitad SID1 o mitad SID2.\n'
        'Secuencia 1..10: BOCINA, AGUA, RUMOR, AGUA, RUMOR, AGUA, RUMOR, AGUA, RUMOR, BOCINA.\n'
        'Se repite cada nueve olas: bocina en 1,10,19,28...\n'
        'La bocina conserva exactamente su frecuencia, forma de onda y ADSR, pero la nota se sostiene 12 pasos de fase en vez de 4, dentro de la pausa ambiental lenta.\n'
        'Cada SID aporta su voz 1 experimental si el segundo esta realmente detectado. Solo un tipo de efecto en cada ola.\n'
        'Voz2 ambiente permanente fuera de filtro, voz3 ola original. El filtro enruta voz1+voz3 solo durante la variante agua.\n'
        'El sonido aprobado se ejecuta una sola vez en cada llamada. La musica, intro, texto scroll y animaciones quedan byte-identicos.\n'
        f'Solo se modifican 2 hooks JSR del DEMO.ras y bytes de relleno FF del scroll ${ORIGIN:04X}..${ORIGIN+len(helper)-1:04X}.\n'
        'IMPORTANTE: extraer ZIP completo, reemplazar DEMO.ras y outro_line25_scroll.bin.\n'
        'Pruebas automaticas de codigo y ZIP no sustituyen COMPILAR y ESCUCHAR en TRSE/WinVICE y hardware real.\n'
    ).encode('utf8')
    # include build source as standalone reference for reproducibility; not required by TRSE.
    src['build_outro_3_effects_alternation.py']=Path(__file__).read_bytes()
    with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,data in src.items():z.writestr(n,data)
    with zipfile.ZipFile(DEST) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        assert z.read('outro_line25_scroll.bin')[offset:offset+len(helper)]==helper
        assert all(z.read(n)==v for n,v in original.items() if n not in ('DEMO.ras','outro_line25_scroll.bin'))
    print('BUILD',DEST,'size',DEST.stat().st_size,'helper',len(helper),'span',hex(ORIGIN),hex(ORIGIN+len(helper)-1), 'ZIP PASS')
    print('Entrypoints',hex(asm.l['init']),hex(asm.l['tick']), 'dictionary',hex(SCROLL_BASE+DICT_OFF),'firstFF',hex(SCROLL_BASE+TEXT_END_OFF))
    return DEST,asm,helper

if __name__=='__main__':build()
