; RICOS 2026 EXPERIMENTO: 3 opciones en voz 1 de cada SID, compartido en ambas escenas.
; Entradas: $F900 INIT, $F903 TICK. Bytes generados: 364.
; Fase de cada ola: 128 unidades. 1a bocina en ola 1, siguiente en 10, 19, 28...
; Bocina: misma afinacion, diente de sierra y ADSR que prueba aprobada; GATE $10..$1B (antes $10..$13).
; El ciclo se detecta por cruce bit7 de fase, no por frames; se mantiene timing original.
; Al cambiar de ciclo: cortar GATE previo, configurar nueva voz y ruteo filtro voz1 SOLO agua.
; Las voces 2/3, la intro, el motor $8400/$8BC1, la musica y la parte visual no cambian.
; Este archivo documenta el binario incrustado; el script Python adjunto contiene las etiquetas y emite estos bytes.
; $F900: $4C,$06,$F9,$4C,$24,$F9,$8E,$67,$FA,$20,$0C,$84,$48,$98,$48,$A9
; $F910: $00,$8D,$69,$FA,$8D,$6A,$FA,$8D,$6B,$FA,$20,$6F,$F9,$68,$A8,$68
; $F920: $AE,$67,$FA,$60,$8D,$68,$FA,$8E,$67,$FA,$20,$C1,$8B,$48,$98,$48
; $F930: $AD,$68,$FA,$29,$80,$CD,$6A,$FA,$F0,$2B,$8D,$6A,$FA,$EE,$69,$FA
; $F940: $AD,$69,$FA,$C9,$09,$90,$05,$A9,$00,$8D,$69,$FA,$AD,$69,$FA,$F0
; $F950: $0C,$29,$01,$F0,$04,$A9,$01,$D0,$06,$A9,$02,$D0,$02,$A9,$00,$8D
; $F960: $6B,$FA,$20,$6F,$F9,$20,$B6,$F9,$68,$A8,$68,$AE,$67,$FA,$60,$A9
; $F970: $00,$8D,$04,$D4,$AE,$67,$FA,$F0,$04,$A0,$04,$91,$FB,$AE,$6B,$FA
; $F980: $BD,$3A,$FA,$AA,$A0,$00,$BD,$3D,$FA,$99,$00,$D4,$AD,$67,$FA,$F0
; $F990: $05,$BD,$52,$FA,$91,$FB,$E8,$C8,$C0,$07,$D0,$EA,$AD,$6B,$FA,$C9
; $F9A0: $01,$F0,$04,$A9,$24,$D0,$02,$A9,$25,$8D,$17,$D4,$AE,$67,$FA,$F0
; $F9B0: $04,$A0,$17,$91,$FB,$60,$AD,$6B,$FA,$F0,$07,$C9,$01,$F0,$23,$4C
; $F9C0: $0D,$FA,$AD,$68,$FA,$29,$7F,$C9,$10,$90,$08,$C9,$1C,$B0,$04,$A9
; $F9D0: $21,$D0,$02,$A9,$20,$8D,$04,$D4,$AE,$67,$FA,$F0,$04,$A0,$04,$91
; $F9E0: $FB,$60,$AD,$68,$FA,$C9,$60,$90,$08,$C9,$80,$B0,$04,$A9,$81,$D0
; $F9F0: $02,$A9,$80,$8D,$04,$D4,$AE,$67,$FA,$F0,$11,$AD,$68,$FA,$C9,$E0
; $FA00: $90,$04,$A9,$81,$D0,$02,$A9,$80,$A0,$04,$91,$FB,$60,$AD,$68,$FA
; $FA10: $18,$69,$20,$C9,$80,$B0,$04,$A9,$11,$D0,$02,$A9,$10,$8D,$04,$D4
; $FA20: $AE,$67,$FA,$F0,$14,$AD,$68,$FA,$18,$69,$A0,$C9,$80,$B0,$04,$A9
; $FA30: $11,$D0,$02,$A9,$10,$A0,$04,$91,$FB,$60,$00,$07,$0E,$C0,$06,$00
; $FA40: $00,$20,$A7,$58,$00,$28,$00,$00,$80,$15,$48,$00,$04,$00,$00,$10
; $FA50: $97,$38,$C8,$06,$00,$00,$20,$A7,$58,$00,$34,$00,$00,$80,$15,$48
; $FA60: $00,$05,$00,$00,$10,$97,$38,$00,$00,$00,$00,$00
