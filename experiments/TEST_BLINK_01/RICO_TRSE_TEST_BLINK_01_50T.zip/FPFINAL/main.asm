
 processor 6502
	org $801
StartBlock801:
	; Starting new memory block at $801
	.byte $b ; lo byte of next line
	.byte $8 ; hi byte of next line
	.byte $0a, $00 ; line 10 (lo, hi)
	.byte $9e, $20 ; SYS token and a space
	.byte   $32,$30,$36,$34
	.byte $00, $00, $00 ; end of program
	; Ending memory block at $801
EndBlock801:
	org $810
StartBlock810:
	; Starting new memory block at $810
DemoPETSCIIFlashparty2026
	jmp block1
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	; Ending memory block at $810
	
; // DEMO PETSCII FLASHPARTY 2026 / C64 PAL / TRSE / 6510
; //
; // MOTOR: scroll PETSCII ping-pong + fine scroll VIC-II + doble buffer.
; // SID: $8C00, rampa sincronizada, corte y cola final.
; // MAIN: $5000 | charset $2000 | mask $2800 | PETSCII map $C500.
; // Screen A $0400 | Screen B $3000.
; //
; // STAGES CLAVE:
; // 05 scroll 2,2,2,1.
; // 11/12 scroll 2,2,1,2,2,1,2,1.
; // 13 PETSCII centrado + blink.
; // 14+ animacion independiente chars 207/208/204/250.
; // 23-25 cierre circular final.
; //
; // SALIDA:
; // OUTRO STAGE 1 TEST: final -> negro ~1 s -> arte estatico, RUN/STOP -> BASIC.
; // RUN/STOP mantiene la salida inmediata a BASIC durante la demo.
; //
; // IMPORTANTE: conservar timings, stage map, SID y valores FINE TUNING.
; // RECURSOS FIJOS
; // OUTRO STAGE 1: original user BINs; $E000..$EFE7 in RAM under KERNAL.
; // No overlap with MAIN, VIC bank0, music or original test binaries.
; // NTSC OLD and NORMAL: scene 5 constant 2 pixels BEFORE their visual -5% correction.
; // Exact RAM gap $EFE8-$EFFF (24 bytes) between outro colors and $F000 loader.
; // Pixel/coarse ocean pan ported from intro $1800. Stored under KERNAL,
; // separate from MAIN and the 193-byte loader at $F000..$F0C0.
; // SYSINFO64 TEXTO LARGO: lector de frases en huecos libres verificados.
; // Loader estatico termina $F0C0; paneo del mar termina $F1B4.
; // SCROLL LINEA 25: BIN aislado en RAM bajo KERNAL. Init $F200, tick $F203.
; // Caracteres normales y color gris claro ($0F), solo $07C0/$DBC0.
; // N en el outro: restaurar SOLO los 23 glifos diferentes o animados.
; // Se ejecuta una sola vez por reinicio, antes de comenzar la demo.
; // $8000: hueco MAIN -> MUSICA confirmado en mapa TRSE del usuario.
; // PALETAS 0..9: codigo y tablas fuera de MAIN, justo despues de $8000..$811D.
; // Solo se ejecuta con RAM visible ($01=$35); no ocupa MAIN ni desplaza SID.
; // MOTOR OCEANICO UNICO, usado tanto por SYSINFO como por el cierre.
; // $8400 INIT / $8403 TICK shared by both scenes; $8409 CREST HOLD.
; // SOLO OUTRO: iniciador sonoro adelantado, en hueco justo despues de audio $8400..$8B06.
; // Misma duracion visual/negro: conserva el init de texto y precarga fade=2 en OUTRO.
; // PRUEBA: PAL-B -0.5% adicional vs. prueba previa -1%; NTSC +4%; DREAN -1.5%.
; // Rutina fuera de MAIN, en hueco $8B10-$8BFF.
; // Audio termina $8B06 y musica empieza $8C00: direcciones intactas.
; // Ganancia unica de ruido oceanico para ambas escenas; no afecta musica.
; // SID VICIOS
; // DATOS DE INTRO / TERMINAL
; // Zona libre separada de MAIN para evitar choque con $B0A0.
; // Mensajes de la terminal de carga. Screen codes + $00 terminador.
; // FIX29C: tablas de solo lectura movidas fuera de MAIN.
; // Libera espacio antes del bloque fijo $B0A0 sin cambiar el motor.
; // PODA SEGURA: antiguo texto sin referencias; mismo tamano y direccion, reservado para nueva OUTRO.
; // Palette scroll state: reuse 1 of 29 already-reserved bytes.
; // Following address layout remains IDENTICAL.
; // Mismo espacio TOTAL de 28 bytes: 26 reservados + latches V y S.
; // No desplazar ningun dato posterior de INTRO_DATA.
; // PALETAS DEMO 0..9: los MISMOS 26 bytes reservados del MASTER.
; // TRSE elimina 23 bytes no referidos desde RAS: active/map/unused.
; // Estado active y mapa estan ahora en BIN $8346-$8356.
; // REQ y latches son $3758, $3759, $375A en el PRG comprobado.
; // Bitsets: latches 1..8 en LO, 9 y 0 en HI.
; // No desplazar outro_v_key_latch, demo_s_key_latch ni otro dato.
; // 0 gris; 1..10 teclas 1..9,0
; // 1..10; 0 sin solicitud
; // PODA SEGURA: antiguo texto sin referencias; mismo tamano y direccion, reservado para nueva OUTRO.
; // Drean visual-only fractional accumulator; replaces 1 reserved byte.
; // Keep the original 12-byte reserved region exactly the same total size.
; // Intro-only sprite window: reuse EXACTLY the existing 10 spare bytes.
; // No INTRO_DATA addresses after this block move.
; // FIX34B: read-only engine tables relocated from MAIN.
; // This frees MAIN without changing runtime behavior.
; // FIX37B: compact SID2 base-address lookup.
; // index 0=none, 1=$DE00, 2=$D420, 3=$D500.
; // FIX37C: runtime read-only constants relocated from MAIN.
; // Frees code/data space before the fixed music block at $8C00.
; // primer radial / secuencia circular (despues del blink Stage 13)
; // inicio inmediato para afinar sincronizacion
; // FIX38: runtime state relocated from MAIN to free space before $8C00.
; // Symbolic addresses keep behavior unchanged.
; // FIX38B: additional MAIN scalar state relocated to INTRO_DATA.
; // Addresses change only symbolically; engine logic is unchanged.
; // FIX40: extra scalar state relocated from MAIN for volume-shadow code.
; // All references remain symbolic; behavior is unchanged.
; // FIX46: char backups moved from MAIN for safe code margin.
; // Solo OUTRO: contador de aceleracion fraccionaria del texto linea 25.
; // Se anade al FINAL de INTRO_DATA para no desplazar variables existentes.
; // SOLO OUTRO audio: reloj independiente de la animacion dividida en pantalla.
; // Se anade al final del bloque de datos; no desplaza ninguna variable previa.
; // SINGLE OCEAN ENGINE: ROM-safe entry bridge; fixed RAM gap.
; // Historical BIN names are retained for project compatibility.
; // MOTOR PRINCIPAL
; // TEST SEA-WAVES: isolated 6502 helper, stays below radial maps at $3BE8.
; // A=slow phase, X=SID2 detected (0=mono), $FB/$FC=SID2 base if found.
; // Smooth 16-bit frequency: $0800..$0FF0..$0800, opposite on SID2.
; // Two-times-longer cycle and quiet persistent noise beds (voice 2, sustain 1).
; // Staggered voice-3 gates for overlap; master volumes untouched.
; // PETSCII editor artwork, 40x25, user-owned bytes preserved verbatim.
; // $1000-$13E7 and $1400-$17E7: CPU RAM under VIC charset-ROM window.
; // SID2 standalone visual start: fits after the original 1000-byte map.
; // $13E8-$13FB; same six-frame blink, no SID probe or artwork changes.
; // SID2 standalone visual finish / final-reload red restoration.
; // $17E8-$17F6, immediately after the original 1000-byte color file.
; // Copy full artwork after all existing tests; animated bottom rows generated by code.
; // Only the user's MACHINE row (#6); variant map/color bytes unchanged.
; // A = detected_machine: 1/2 NTSC, 3 PAL-B, 4 baseline Drean PAL-N.
; // $1D00..$1DFF lies after approved loader ($1C00..$1CC0), before $2000.
; // Intro-only horizontal subcharacter renderer in unallocated low RAM.
; // HEARTS: blank the color of pending markers ONLY. The PETSCII art is unchanged.
; // FIX S: intro_pixel_scroll.bin now reads/writes its flag at $3B96, NOT at
; // $3B47 (PHP opcode of the SYSINFO SID-address hide routine).
; // $18C7..$18F1 is the free gap directly after the approved $1800 pixel-scroll.
; // Hide exactly row 22 in the $0800 test-visible art page; no art file edits.
; // $18F2-$18FC fits after pending hearts and before IEC at $1900.
; // Completed hearts to restore after the final $0400 artwork/color reload.
; // $1DE1..$1DF0 is free after the approved $1D00 machine-row resource.
; // Same row 22 on the $0400 art screen, after final reload, before VIC switches.
; // $1DF1-$1DFB fits before LFSR helper $1E00.
; // LFSR + ENV3 confirmed visual actions; add ONLY SID1 heart start/done/tick.
; // Previous entrypoints $1E00..$1E15 kept fixed; SID1 $1E18=start, $1E1B=done.
; // SID1 classification presentation uses $1BC0 / $1CC1, OUTSIDE RAM test scratch; no test changes.
; // RAM self-tests write $4F70-$4FBF; never execute code from that scratch area.
; // Two separate confirmed FREE gaps, after existing IEC and art-loader assets.
; // Intro-only standard IEC acknowledgement for devices 8-11; detection logic unchanged.
; // O oculta: NO usar $4FC0..$4FFF para codigo: RAM TEST ($BC60) los pisa
; // guardando alli los 64 bytes de $4F80..$4FBF, aunque el mapa diga libres.
; // A0C1-A0FD: 61 bytes libres entre el final de music.bin y los mapas A100.
; // El unico array se retiene por la llamada SIMBOLICA desde la DEMO.
; // A0C1-A0DF: probe O en DEMO (flag del prompt o teclado en vivo).
; // A0E0-A0FD: scanner S/O del prompt; el wrapper $1A2E mapea BASIC fuera
; // temporalmente y restaura exactamente el valor previo de $01.
; // OUTRO normal sin cambiar; MAIN no crece; BIN intactos.
; // PRESS A KEY: scanner incorporado al FUENTE (no depende de BIN nuevo).
; // IMPORTANTE TRSE: usar referencias simbolicas, no JSR/JMP $xxxx numericos: la optimizacion puede omitir arrays no referidos.
; // Wrapper RAM ejecutable siempre: $1A2E-$1A3B (14 bytes).
; // Preserva $01 y pila; LORAM=0 expone $A0E0 bajo BASIC; espera RTS
; // del scanner tras llamar al mismo stop de paleta $5A73 que funcionaba.
; // IEC display-only heart: starts red/pink during probe, settles red at finish.
; // Entry $1A40=start, $1A43=done/restore, $1A46=frame dispatcher.
; // Located after IEC $1900-$1A2D and before existing SID1 vectors at $1BC0.
; // PRESS A KEY: decision incorporada al FUENTE; $1A94-$1A9E (11 bytes).
; // $3B97=0 significa S: repetir el PROCEDIMIENTO desde $500F.
; // El SYSINFO original fue llamado con JSR $500F desde $76B2:
; // NO reiniciar MAIN ni TXS dentro del procedimiento; preservar la direccion
; // de retorno original en pila. Al finalizar una tecla no-S, RTS en $5A90
; // vuelve al flujo normal tras JSR y la demo comienza como siempre.
; // Cosmetic-only hearts in the unused $1AA0..$1BBF gap; no JOY reads.
; // Entries: hide JOY $1AA0, DUAL start/done $1AA3/$1AA6,
; // JOY start/done $1AA9/$1AAC, frame tick $1AAF, final red $1AB2.
; // Cosmetic CPU/VIC-CIA/RAM frame tick: no test code or hardware access.
; // Fits exactly in the free $1B68..$1BBF gap after the approved fake hearts.
; // SID2 frame dispatcher in free intro-data tail; $39D2-$39F9.
; // If not SID2, tail-jump to exact old $1E06 heartbeat tick.
; // Sea helper still begins unmodified at $3A00.
; // Intro charset animation: separate helper in unused gap before radial maps.
; // COSMETIC ONLY: hide SID1/SID2 address until each actual test finishes.
; // FIX S: $3B47..$3B89 = executable SID-address helper; $3B8A..$3B95 = prompt.
; // $3B96 is reserved for the intro_pixel_scroll direction byte (formerly $3B47).
; // $3B97 se reserva para S en PRESS A KEY; $3B98..$3B9D libres.
; // $3B9E..$3BA0 = sea-animation state.
; // remain reserved for the unchanged sea animation state. No SID writes here.
; // Restore the author's row 22 in original PETSCII after first sea frame.
; // $3B8A-$3B95; sea-only state $3B9E-$3BA0 left strictly unchanged.
; // OrgAsm FIX: 22 free bytes immediately after the UNCHANGED stereo.bin.
; // Entry $CFEA = original JOY hide + basic hide;
; //       $CFF1 = original final-heart restore + basic result restore;
; //       $CFF8 = start VIC/CIA cosmetics.
; // Keeps MAIN below music at $8C00; no changes to SID or tests.
; // SID1 preserves its approved model animation. SID2 & DUAL MODE: visual-only.
; // Starts at the byte immediately AFTER current 939-byte ui.bin ($C3AB).
; // Entrypoints: init=$C3AB, found=$C3C9, render=$C3DD.
; // No CIA/SID writes, no joystick code, no changes to detection or demo engine.
; // Visual-only hooks for the already tested CPU, VIC/CIA and RAM diagnostics.
; // $C450..$C4FF: free immediately after the approved SID2 visual ($C44F).
; // Never overlap CHAR data at $C500.
; // RAM DATA R/W, RAM ADDRESS, COLOR RAM, STACK PUSH/POP + charset visual sample.
; // No changes to sea sound, SID tests, or visual demo.
; // $BC60..$BFFF was unallocated in the user's TRSE memory map.
; // Only RAM-test pause/scroll JSR targets change: all test instructions preserved.
; // Under BASIC ROM, this helper is called only while LORAM is disabled.
; // Three flags occupy the existing unused $1FFA..$1FFC gap.
; // PAL-B-only cadence test: under-KERNAL RAM after approved outro binary.
; // $FFC8..$FFF9 free in static map; vectors $FFFA..$FFFF untouched.
; // Unlike $4F70, this area is not RAM-test scratch.
; // |                         >>> FINE TUNING <<<                                |
; // Stages 11/12 comparten la misma velocidad rotatoria.
; // STAGE 13 / PETSCII CENTRADO + BLINK CONSTANTE RAPIDO
; // |                       <<< FIN FINE TUNING >>>                              |
; // CONFIGURACION INTERNA FIJA DE ESTA DEMO
; // DIRECCIONES INDEPENDIENTES DE LOS 4 CHARS PETSCII
; // BACKUP DE LOS 4 CHARS ORIGINALES.
; // TABLA DE VELOCIDADES SID
; // TABLA DE GRADIENTES
; // TABLA INTERNA DE SUAVIZADO DEL SCROLL
; // VARIABLES INTERNAS DEL FINAL AUTOMATICO
; // RETORNO AUTOMATICO A BASIC DESPUES DEL NEGRO FINAL.
; // ESC en emulador / RUN-STOP en C64 real.
; // DETECCION DE MAQUINA / INTRO DE ARRANQUE
; // 1 = NTSC OLD, 2 = NTSC, 3 = PAL-B, 4 = DREAN PAL-N
; // PERFIL INFORMATIVO REAL / EMULADOR.
; // 1 = REAL-LIKE, 2 = EMULATED-LIKE.
; // Es heuristico: NO afecta el funcionamiento de la demo.
; // Mensajes de la terminal movidos a INTRO_DATA $3400 para no crecer MAIN.
; // RELOJ LOGICO MULTISISTEMA
; // PAL-B / PAL-N: 1 tick por frame.
; // NTSC old: 37 ticks / 45 frames.
; // NTSC new: 31 ticks / 37 frames.
; // Este tick gobierna SID y logica visual juntos.
; // FIX18: flag local del loop para ejecutar como maximo UN tick visual por VBlank.
; // STAGE 5 / TRANSICION HORIZONTAL UNICA:
; // Movimiento espacial SOLO para Stage 13.
; // Fase de scroll para stages 11/12:
; // STAGE 5 / DEGRADE HORIZONTAL UNICO
; // STAGE 13 / BLINK GLOBAL + PETSCII FIJO
	; NodeProcedureDecl 51
	; Ending memory block at $810
EndBlock810:
	org $1000
StartBlock1000:
	; Starting new memory block at $1000
intro_art_map
	incbin	 "C:/FPRICO/FPFINAL///ricotestmap.bin"
end_incbin_intro_art_map
EndBlock1000:
	org $13e8
StartBlock13e8:
	; Starting new memory block at $13e8
intro_sid2_heart_start
	incbin	 "C:/FPRICO/FPFINAL///intro_sid2_heart_start.bin"
end_incbin_intro_sid2_heart_start
EndBlock13e8:
	org $1400
StartBlock1400:
	; Starting new memory block at $1400
intro_art_color
	incbin	 "C:/FPRICO/FPFINAL///ricotestcolor.bin"
end_incbin_intro_art_color
EndBlock1400:
	org $17e8
StartBlock17e8:
	; Starting new memory block at $17e8
intro_sid2_heart_done
	incbin	 "C:/FPRICO/FPFINAL///intro_sid2_heart_done.bin"
end_incbin_intro_sid2_heart_done
EndBlock17e8:
	org $1800
StartBlock1800:
	; Starting new memory block at $1800
intro_pixel_scroll
	incbin	 "C:/FPRICO/FPFINAL///intro_pixel_scroll.bin"
end_incbin_intro_pixel_scroll
EndBlock1800:
	org $18c7
StartBlock18c7:
	; Starting new memory block at $18c7
intro_heart_pending
	incbin	 "C:/FPRICO/FPFINAL///intro_heart_pending.bin"
end_incbin_intro_heart_pending
EndBlock18c7:
	org $18f2
StartBlock18f2:
	; Starting new memory block at $18f2
intro_prompt_hide_initial
	incbin	 "C:/FPRICO/FPFINAL///intro_prompt_hide_initial.bin"
end_incbin_intro_prompt_hide_initial
EndBlock18f2:
	org $1900
StartBlock1900:
	; Starting new memory block at $1900
intro_io_probe
	incbin	 "C:/FPRICO/FPFINAL///intro_iec_09.bin"
end_incbin_intro_io_probe
EndBlock1900:
	org $1a2e
StartBlock1a2e:
	; Starting new memory block at $1a2e
intro_prompt_s_source_scan	dc.b $a5, $1, $48, $29, $fe, $85, $1, $20
	dc.b $e0, $a0, $68, $85, $1, $60
EndBlock1a2e:
	org $1a40
StartBlock1a40:
	; Starting new memory block at $1a40
intro_iec_heart
	incbin	 "C:/FPRICO/FPFINAL///intro_iec_heart.bin"
end_incbin_intro_iec_heart
EndBlock1a40:
	org $1a94
StartBlock1a94:
	; Starting new memory block at $1a94
intro_prompt_s_source_dispatch	dc.b $ad, $97, $3b, $f0, $3, $4c, $95, $8b
	dc.b $4c, $f, $50
EndBlock1a94:
	org $1aa0
StartBlock1aa0:
	; Starting new memory block at $1aa0
intro_fake_hearts
	incbin	 "C:/FPRICO/FPFINAL///intro_fake_hearts.bin"
end_incbin_intro_fake_hearts
EndBlock1aa0:
	org $1b68
StartBlock1b68:
	; Starting new memory block at $1b68
intro_basic_tests_tick
	incbin	 "C:/FPRICO/FPFINAL///intro_basic_tests_tick.bin"
end_incbin_intro_basic_tests_tick
EndBlock1b68:
	org $1bc0
StartBlock1bc0:
	; Starting new memory block at $1bc0
intro_sid1_vectors
	incbin	 "C:/FPRICO/FPFINAL///intro_sid1_vectors.bin"
end_incbin_intro_sid1_vectors
EndBlock1bc0:
	org $1c00
StartBlock1c00:
	; Starting new memory block at $1c00
intro_art_loader
	incbin	 "C:/FPRICO/FPFINAL///intro_art_loader.bin"
end_incbin_intro_art_loader
EndBlock1c00:
	org $1cc1
StartBlock1cc1:
	; Starting new memory block at $1cc1
intro_sid1_render
	incbin	 "C:/FPRICO/FPFINAL///intro_sid1_render.bin"
end_incbin_intro_sid1_render
EndBlock1cc1:
	org $1d00
StartBlock1d00:
	; Starting new memory block at $1d00
intro_machine_row
	incbin	 "C:/FPRICO/FPFINAL///intro_machine_row.bin"
end_incbin_intro_machine_row
EndBlock1d00:
	org $1de1
StartBlock1de1:
	; Starting new memory block at $1de1
intro_heart_completed
	incbin	 "C:/FPRICO/FPFINAL///intro_heart_completed.bin"
end_incbin_intro_heart_completed
EndBlock1de1:
	org $1df1
StartBlock1df1:
	; Starting new memory block at $1df1
intro_prompt_hide_final
	incbin	 "C:/FPRICO/FPFINAL///intro_prompt_hide_final.bin"
end_incbin_intro_prompt_hide_final
EndBlock1df1:
	org $1e00
StartBlock1e00:
	; Starting new memory block at $1e00
intro_lfsr_heart
	incbin	 "C:/FPRICO/FPFINAL///intro_lfsr_heart.bin"
end_incbin_intro_lfsr_heart
EndBlock1e00:
	org $2000
StartBlock2000:
	org $2000
tileset_data:
	incbin	 "C:/FPRICO/FPFINAL///tileset.bin"
end_incbin_tileset_data:
EndBlock2000:
	org $3400
StartBlock3400:
	; Starting new memory block at $3400
intro_msg_vic_pal	dc.b $3, $f, $d, $d, $f, $4, $f, $12
	dc.b $5, $20, $d, $1, $3, $8, $9, $e
	dc.b $5, $20, $10, $1, $c, $0
	; Resuming memory block at $3400
intro_msg_vic_ntsc	dc.b $3, $f, $d, $d, $f, $4, $f, $12
	dc.b $5, $20, $d, $1, $3, $8, $9, $e
	dc.b $5, $20, $e, $14, $13, $3, $0
	; Resuming memory block at $3400
intro_msg_vic_drean	dc.b $3, $f, $d, $d, $f, $4, $f, $12
	dc.b $5, $20, $d, $1, $3, $8, $9, $e
	dc.b $5, $20, $4, $12, $5, $1, $e, $0
	; Resuming memory block at $3400
intro_msg_vic_frame	dc.b $16, $9, $3, $2f, $3, $9, $1, $20
	dc.b $6, $12, $1, $d, $5, $20, $14, $9
	dc.b $d, $5, $12, $20, $2e, $2e, $2e, $20
	dc.b $f, $b, $20, $f, $b, $0
	; Resuming memory block at $3400
intro_msg_dual_on	dc.b $4, $15, $1, $c, $20, $13, $9, $4
	dc.b $20, $d, $f, $4, $5, $20, $f, $e
	dc.b $0
	; Resuming memory block at $3400
intro_msg_dual_off	dc.b $4, $15, $1, $c, $20, $13, $9, $4
	dc.b $20, $d, $f, $4, $5, $20, $f, $6
	dc.b $6, $0
	; Resuming memory block at $3400
intro_msg_lfsr_fast	dc.b $13, $9, $4, $20, $c, $6, $13, $12
	dc.b $20, $1, $3, $14, $9, $16, $9, $14
	dc.b $19, $20, $6, $1, $13, $14, $20, $f
	dc.b $b, $0
	; Resuming memory block at $3400
intro_msg_lfsr_slow	dc.b $13, $9, $4, $20, $c, $6, $13, $12
	dc.b $20, $1, $3, $14, $9, $16, $9, $14
	dc.b $19, $20, $13, $c, $f, $17, $20, $f
	dc.b $b, $0
	; Resuming memory block at $3400
intro_msg_lfsr_no	dc.b $13, $9, $4, $20, $c, $6, $13, $12
	dc.b $20, $1, $3, $14, $9, $16, $9, $14
	dc.b $19, $20, $e, $f, $20, $12, $5, $13
	dc.b $10, $f, $e, $13, $5, $0
	; Resuming memory block at $3400
intro_msg_sidmodel_6581	dc.b $13, $9, $4, $20, $31, $20, $d, $f
	dc.b $4, $5, $c, $20, $36, $35, $38, $31
	dc.b $2d, $c, $9, $b, $5, $0
	; Resuming memory block at $3400
intro_msg_sidmodel_8580	dc.b $13, $9, $4, $20, $31, $20, $d, $f
	dc.b $4, $5, $c, $20, $38, $35, $38, $30
	dc.b $2d, $c, $9, $b, $5, $0
	; Resuming memory block at $3400
intro_msg_sid2_no	dc.b $13, $9, $4, $20, $32, $20, $e, $f
	dc.b $14, $20, $6, $f, $15, $e, $4, $0
	; Resuming memory block at $3400
radial_phase_lut	dc.b $0, $1, $2, $3, $4, $5, $0, $1
	dc.b $2, $3, $4, $5, $0, $1, $2, $3
	dc.b $4, $5, $0, $1, $2, $3, $4, $5
	dc.b $0, $1, $2, $3, $4, $5, $0, $1
	dc.b $2, $3, $4, $5, $0, $1, $2, $3
	dc.b $4, $5, $0, $1, $2, $3, $4, $5
	dc.b $0, $1, $2, $3, $4, $5, $0, $1
	dc.b $2, $3, $4, $5, $0, $1, $2, $3
	dc.b $0, $0, $1, $1, $2, $2, $3, $3
	dc.b $4, $4, $5, $5, $0, $0, $1, $1
	dc.b $2, $2, $3, $3, $4, $4, $5, $5
	dc.b $0, $0, $1, $1, $2, $2, $3, $3
	dc.b $4, $4, $5, $5, $0, $0, $1, $1
	dc.b $2, $2, $3, $3, $4, $4, $5, $5
	dc.b $0, $0, $1, $1, $2, $2, $3, $3
	dc.b $4, $4, $5, $5, $0, $0, $1, $1
	dc.b $0, $0, $0, $1, $1, $1, $2, $2
	dc.b $2, $3, $3, $3, $4, $4, $4, $5
	dc.b $5, $5, $0, $0, $0, $1, $1, $1
	dc.b $2, $2, $2, $3, $3, $3, $4, $4
	dc.b $4, $5, $5, $5, $0, $0, $0, $1
	dc.b $1, $1, $2, $2, $2, $3, $3, $3
	dc.b $4, $4, $4, $5, $5, $5, $0, $0
	dc.b $0, $1, $1, $1, $2, $2, $2, $3
	dc.b $0, $0, $0, $0, $1, $1, $1, $1
	dc.b $2, $2, $2, $2, $3, $3, $3, $3
	dc.b $4, $4, $4, $4, $5, $5, $5, $5
	dc.b $0, $0, $0, $0, $1, $1, $1, $1
	dc.b $2, $2, $2, $2, $3, $3, $3, $3
	dc.b $4, $4, $4, $4, $5, $5, $5, $5
	dc.b $0, $0, $0, $0, $1, $1, $1, $1
	dc.b $2, $2, $2, $2, $3, $3, $3, $3
	; Resuming memory block at $3400
screen_lo	dc.b $0, $28, $50, $78, $a0, $c8, $f0, $18
	dc.b $40, $68, $90, $b8, $e0, $8, $30, $58
	dc.b $80, $a8, $d0, $f8, $20, $48, $70, $98
	dc.b $c0
	; Resuming memory block at $3400
screen_hi	dc.b $4, $4, $4, $4, $4, $4, $4, $5
	dc.b $5, $5, $5, $5, $5, $6, $6, $6
	dc.b $6, $6, $6, $6, $7, $7, $7, $7
	dc.b $7
	; Resuming memory block at $3400
screen_hi_b	dc.b $30, $30, $30, $30, $30, $30, $30, $31
	dc.b $31, $31, $31, $31, $31, $32, $32, $32
	dc.b $32, $32, $32, $32, $33, $33, $33, $33
	dc.b $33
	; Resuming memory block at $3400
color_lo	dc.b $0, $28, $50, $78, $a0, $c8, $f0, $18
	dc.b $40, $68, $90, $b8, $e0, $8, $30, $58
	dc.b $80, $a8, $d0, $f8, $20, $48, $70, $98
	dc.b $c0
	; Resuming memory block at $3400
color_hi	dc.b $d8, $d8, $d8, $d8, $d8, $d8, $d8, $d9
	dc.b $d9, $d9, $d9, $d9, $d9, $da, $da, $da
	dc.b $da, $da, $da, $da, $db, $db, $db, $db
	dc.b $db
	; Resuming memory block at $3400
src_char_lo	dc.b $0, $28, $50, $78, $a0, $c8, $f0, $18
	dc.b $40, $68, $90, $b8, $e0, $8, $30, $58
	dc.b $80, $a8, $d0, $f8, $20, $48, $70, $98
	dc.b $c0, $e8, $10, $38, $60, $88, $b0, $d8
	dc.b $0, $28, $50, $78, $a0, $c8, $f0, $18
	dc.b $40, $68, $90, $b8, $e0, $8, $30, $58
	dc.b $80, $a8, $d0, $f8, $20, $48, $70, $98
	dc.b $c0, $e8, $10, $38
	; Resuming memory block at $3400
src_char_hi	dc.b $c5, $c5, $c5, $c5, $c5, $c5, $c5, $c6
	dc.b $c6, $c6, $c6, $c6, $c6, $c7, $c7, $c7
	dc.b $c7, $c7, $c7, $c7, $c8, $c8, $c8, $c8
	dc.b $c8, $c8, $c9, $c9, $c9, $c9, $c9, $c9
	dc.b $ca, $ca, $ca, $ca, $ca, $ca, $ca, $cb
	dc.b $cb, $cb, $cb, $cb, $cb, $cc, $cc, $cc
	dc.b $cc, $cc, $cc, $cc, $cd, $cd, $cd, $cd
	dc.b $cd, $cd, $ce, $ce
	; Resuming memory block at $3400
intro_msg_sid2_de00	dc.b $13, $9, $4, $20, $32, $20, $24, $4
	dc.b $5, $30, $30, $20, $d, $f, $4, $5
	dc.b $c, $20, $15, $e, $b, $e, $f, $17
	dc.b $e, $0
	; Resuming memory block at $3400
intro_msg_sid2_d420	dc.b $13, $9, $4, $20, $32, $20, $24, $4
	dc.b $34, $32, $30, $20, $d, $f, $4, $5
	dc.b $c, $20, $15, $e, $b, $e, $f, $17
	dc.b $e, $0
	; Resuming memory block at $3400
intro_msg_sid2_d500	dc.b $13, $9, $4, $20, $32, $20, $24, $4
	dc.b $35, $30, $30, $20, $d, $f, $4, $5
	dc.b $c, $20, $15, $e, $b, $e, $f, $17
	dc.b $e, $0
	; Resuming memory block at $3400
intro_palette_divider	dc.b	$00
	; Resuming memory block at $3400
demo_palette_request	dc.b	$00
	; Resuming memory block at $3400
demo_palette_latch_lo	dc.b	$00
	; Resuming memory block at $3400
demo_palette_latch_hi	dc.b	$00
	; Resuming memory block at $3400
outro_v_key_latch	dc.b	$00
	; Resuming memory block at $3400
demo_s_key_latch	dc.b	$00
	; Resuming memory block at $3400
intro_msg_agent_hello	dc.b $12, $9, $3, $f, $13, $20, $3, $36
	dc.b $34, $20, $12, $5, $1, $c, $20, $8
	dc.b $1, $12, $4, $17, $1, $12, $5, $20
	dc.b $4, $5, $14, $5, $3, $14, $9, $f
	dc.b $e, $0
	; Resuming memory block at $3400
drean_visual_phase	dc.b	$00
	; Resuming memory block at $3400
ntsc_visual_phase	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_group	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_phase	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_divider	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_hold	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_row	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_old_lo	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_old_hi	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_next_lo	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_next_hi	dc.b	$00
	; Resuming memory block at $3400
intro_sprite_saved_xhi	dc.b	$00
	; Resuming memory block at $3400
chars_izq	dc.b $0, $0, $0, $0, $0, $0, $0, $0
	; Resuming memory block at $3400
chars_der	dc.b $cc, $cf, $d0, $fa, $0, $0, $0, $0
	; Resuming memory block at $3400
chars_arriba	dc.b $0, $0, $0, $0, $0, $0, $0, $0
	; Resuming memory block at $3400
chars_abajo	dc.b $0, $0, $0, $0, $0, $0, $0, $0
	; Resuming memory block at $3400
sid_speed_table	dc.b $b, $d, $10, $12, $16, $1b, $20, $27
	dc.b $2e, $32
	; Resuming memory block at $3400
sid_gradient_table	dc.b $1, $2, $3, $5, $7, $b, $f, $13
	dc.b $18, $1d
	; Resuming memory block at $3400
scroll_smooth_table	dc.b $80, $8d, $9a, $a7, $b4, $c1, $ce, $db
	dc.b $e8, $f5
	; Resuming memory block at $3400
scroll_turbo_base_table	dc.b $0, $0, $0, $0, $0, $1, $1, $1
	dc.b $1, $1, $2
	; Resuming memory block at $3400
scroll_turbo_frac_table	dc.b $0, $33, $66, $99, $cc, $0, $33, $66
	dc.b $99, $cc, $0
	; Resuming memory block at $3400
blink_sequence_gray	dc.b $1, $f, $c, $b, $c, $f
	; Resuming memory block at $3400
blink_sequence_black	dc.b $0, $0, $0, $1, $1, $1, $0, $0
	dc.b $0
	; Resuming memory block at $3400
color_degrade	dc.b $b, $b, $c, $c, $f, $f, $1, $1
	dc.b $f, $f, $c, $c, $b, $b, $c, $c
	dc.b $f, $f, $1, $1, $f, $f, $c, $c
	dc.b $b
	; Resuming memory block at $3400
horizontal_full_gradient	dc.b $1, $1, $1, $1, $1, $1, $1, $f
	dc.b $f, $f, $f, $f, $f, $c, $c, $c
	dc.b $c, $c, $c, $b, $b, $b, $b, $b
	dc.b $b
	; Resuming memory block at $3400
radial_palette	dc.b $b, $c, $f, $1, $f, $c
	; Resuming memory block at $3400
radial_anchor_lo	dc.b $e8, $d0, $b8, $a0, $88, $0, $e8, $d0
	dc.b $b8
	; Resuming memory block at $3400
radial_anchor_hi	dc.b $3b, $3f, $43, $47, $4b, $a1, $a4, $a8
	dc.b $ac
	; Resuming memory block at $3400
radial_anchor_path	dc.b $1, $6, $4, $8, $2, $7, $3, $5
	; Resuming memory block at $3400
radial_row_offset_lo	dc.b $0, $28, $50, $78, $a0, $c8, $f0, $18
	dc.b $40, $68, $90, $b8, $e0, $8, $30, $58
	dc.b $80, $a8, $d0, $f8, $20, $48, $70, $98
	dc.b $c0
	; Resuming memory block at $3400
radial_row_offset_hi	dc.b $0, $0, $0, $0, $0, $0, $0, $1
	dc.b $1, $1, $1, $1, $1, $2, $2, $2
	dc.b $2, $2, $2, $2, $3, $3, $3, $3
	dc.b $3
	; Resuming memory block at $3400
vertical_phase_width_table	dc.b $7, $7, $6, $7, $7, $6, $4, $3
	dc.b $3, $4, $3, $3, $2, $2, $1, $2
	dc.b $2, $1, $2, $1, $1, $2, $1, $1
	; Resuming memory block at $3400
intro_sid2_base_lo	dc.b $0, $0, $20, $0
	; Resuming memory block at $3400
intro_sid2_base_hi	dc.b $0, $de, $d4, $d5
	; Resuming memory block at $3400
scroll_step	dc.b	$02
	; Resuming memory block at $3400
scroll_turbo_enabled	dc.b	$00
	; Resuming memory block at $3400
top_mask_restore_raster	dc.b	$3d
	; Resuming memory block at $3400
anim_speed	dc.b	$04
	; Resuming memory block at $3400
anim_start_show_stage	dc.b	$0e
	; Resuming memory block at $3400
anim_start_delay_frames	dc.b	$00
	; Resuming memory block at $3400
rotating_lines_speed	dc.b	$06
	; Resuming memory block at $3400
final_circular_fast_step	dc.b	$03
	; Resuming memory block at $3400
rotating_move_step	dc.b	$02
	; Resuming memory block at $3400
rotating_move_max	dc.b	$08
	; Resuming memory block at $3400
stage13_center_src_top	dc.b	$10
	; Resuming memory block at $3400
stage13_blink_speed	dc.b	$01
	; Resuming memory block at $3400
sid_end_play_hi	dc.b	$20
	; Resuming memory block at $3400
sid_end_play_lo	dc.b	$c6
	; Resuming memory block at $3400
scroll_end_advance_hi	dc.b	$01
	; Resuming memory block at $3400
scroll_end_advance_lo	dc.b	$77
	; Resuming memory block at $3400
final_center_hold_enabled	dc.b	$01
	; Resuming memory block at $3400
final_center_next_line	dc.b	$48
	; Resuming memory block at $3400
final_center_fine_scroll	dc.b	$03
	; Resuming memory block at $3400
final_center_direction	dc.b	$01
	; Resuming memory block at $3400
limit_up	dc.b	$74
	; Resuming memory block at $3400
limit_down	dc.b	$1e
	; Resuming memory block at $3400
scroll_sid_link	dc.b	$01
	; Resuming memory block at $3400
scroll_rate_mid1	dc.b	$14
	; Resuming memory block at $3400
scroll_rate_mid2	dc.b	$1e
	; Resuming memory block at $3400
scroll_rate_fast	dc.b	$28
	; Resuming memory block at $3400
top_mask_enabled	dc.b	$01
	; Resuming memory block at $3400
vertical_scroll_start_direction	dc.b	$00
	; Resuming memory block at $3400
sid_ramp_enabled	dc.b	$01
	; Resuming memory block at $3400
sid_start_on_first_content	dc.b	$00
	; Resuming memory block at $3400
sid_end_enabled	dc.b	$01
	; Resuming memory block at $3400
basic_return_delay_frames	dc.b	$7d
	; Resuming memory block at $3400
sid_rate	dc.b	$0b
	; Resuming memory block at $3400
sid_accum	dc.b	$00
	; Resuming memory block at $3400
sid_ramp_frame_counter	dc.b	$00
	; Resuming memory block at $3400
sid_ramp_block_counter	dc.b	$00
	; Resuming memory block at $3400
sid_gradient_blocks	dc.b	$01
	; Resuming memory block at $3400
sid_ramp_active	dc.b	$00
	; Resuming memory block at $3400
sid_first_content_triggered	dc.b	$00
	; Resuming memory block at $3400
sid_play_count_lo	dc.b	$00
	; Resuming memory block at $3400
sid_play_count_hi	dc.b	$00
	; Resuming memory block at $3400
sid_end_state	dc.b	$00
	; Resuming memory block at $3400
sid_tail_counter	dc.b	$00
	; Resuming memory block at $3400
demo_finished	dc.b	$00
	; Resuming memory block at $3400
basic_return_counter	dc.b	$00
	; Resuming memory block at $3400
escape_requested	dc.b	$00
	; Resuming memory block at $3400
detected_machine	dc.b	$00
	; Resuming memory block at $3400
startup_intro_done	dc.b	$00
	; Resuming memory block at $3400
startup_intro_seconds	dc.b	$0a
	; Resuming memory block at $3400
startup_intro_fps	dc.b	$32
	; Resuming memory block at $3400
startup_intro_second_counter	dc.b	$00
	; Resuming memory block at $3400
startup_intro_frame_counter	dc.b	$00
	; Resuming memory block at $3400
hardware_profile	dc.b	$00
	; Resuming memory block at $3400
demo_logic_tick	dc.b	$01
	; Resuming memory block at $3400
demo_tick_accum	dc.b	$00
	; Resuming memory block at $3400
demo_visual_do_tick	dc.b	$00
	; Resuming memory block at $3400
scroll_end_trigger_lo	dc.b	$00
	; Resuming memory block at $3400
scroll_end_trigger_hi	dc.b	$00
	; Resuming memory block at $3400
scroll_end_armed	dc.b	$00
	; Resuming memory block at $3400
final_center_hold_active	dc.b	$00
	; Resuming memory block at $3400
screen_active	dc.b	$00
	; Resuming memory block at $3400
screen_d018_real	dc.b	$18
	; Resuming memory block at $3400
screen_d018_mask	dc.b	$1a
	; Resuming memory block at $3400
next_line	dc.b	$2a
	; Resuming memory block at $3400
scroll_turbo_final_seconds	dc.b	$1e
	; Resuming memory block at $3400
scroll_turbo_max_step	dc.b	$04
	; Resuming memory block at $3400
anim_combo_black_period	dc.b	$01
	; Resuming memory block at $3400
blink_global_speed	dc.b	$03
	; Resuming memory block at $3400
blink_global_black	dc.b	$01
	; Resuming memory block at $3400
radial_anchor_motion_period	dc.b	$02
	; Resuming memory block at $3400
sid_speed_mode	dc.b	$01
	; Resuming memory block at $3400
sid_ramp_target_rate	dc.b	$32
	; Resuming memory block at $3400
sid_gradient	dc.b	$06
	; Resuming memory block at $3400
sid_tail_frames	dc.b	$64
	; Resuming memory block at $3400
scroll_speed_manual	dc.b	$00
	; Resuming memory block at $3400
scroll_speed_slow	dc.b	$02
	; Resuming memory block at $3400
scroll_speed_mid1	dc.b	$02
	; Resuming memory block at $3400
scroll_speed_mid2	dc.b	$01
	; Resuming memory block at $3400
scroll_speed_fast	dc.b	$01
	; Resuming memory block at $3400
anim_active	dc.b	$00
	; Resuming memory block at $3400
n_izq	dc.b	$00
	; Resuming memory block at $3400
n_der	dc.b	$04
	; Resuming memory block at $3400
n_arriba	dc.b	$00
	; Resuming memory block at $3400
n_abajo	dc.b	$00
	; Resuming memory block at $3400
color_mode	dc.b	$02
	; Resuming memory block at $3400
linear_subdivision	dc.b	$07
	; Resuming memory block at $3400
linear_mirror	dc.b	$00
	; Resuming memory block at $3400
flat_color	dc.b	$01
	; Resuming memory block at $3400
cross_subdivision	dc.b	$01
	; Resuming memory block at $3400
cross_row_period	dc.b	$02
	; Resuming memory block at $3400
cross_mirror	dc.b	$00
	; Resuming memory block at $3400
vertical_subdivision	dc.b	$03
	; Resuming memory block at $3400
vertical_mirror	dc.b	$00
	; Resuming memory block at $3400
vertical_scroll_enabled	dc.b	$01
	; Resuming memory block at $3400
vertical_scroll_speed	dc.b	$04
	; Resuming memory block at $3400
vertical_scroll_motion	dc.b	$00
	; Resuming memory block at $3400
radial_subdivision	dc.b	$02
	; Resuming memory block at $3400
radial_direction	dc.b	$00
	; Resuming memory block at $3400
radial_scroll_enabled	dc.b	$01
	; Resuming memory block at $3400
radial_scroll_speed	dc.b	$02
	; Resuming memory block at $3400
radial_anchor_motion_enabled	dc.b	$00
	; Resuming memory block at $3400
radial_anchor_motion_direction	dc.b	$00
	; Resuming memory block at $3400
radial_anchor	dc.b	$00
	; Resuming memory block at $3400
scroll_speed	dc.b	$04
	; Resuming memory block at $3400
scroll_phase	dc.b	$00
	; Resuming memory block at $3400
scroll_phase_step	dc.b	$80
	; Resuming memory block at $3400
scroll_fullspeed	dc.b	$00
	; Resuming memory block at $3400
scroll_update_now	dc.b	$00
	; Resuming memory block at $3400
scroll_coarse_event	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_base_extra	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_frac_step	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_phase	dc.b	$00
	; Resuming memory block at $3400
scroll_step_effective	dc.b	$02
	; Resuming memory block at $3400
scroll_turbo_trigger_lo	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_trigger_hi	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_lead_lo	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_lead_hi	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_active	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_stage	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_stage_counter	dc.b	$00
	; Resuming memory block at $3400
scroll_turbo_stage_plays	dc.b	$96
	; Resuming memory block at $3400
fine_scroll	dc.b	$07
	; Resuming memory block at $3400
speed_counter	dc.b	$00
	; Resuming memory block at $3400
direction	dc.b	$01
	; Resuming memory block at $3400
src_idx	dc.b	0
	; Resuming memory block at $3400
map_idx	dc.b	0
	; Resuming memory block at $3400
top_mask_phase	dc.b	$00
	; Resuming memory block at $3400
anim_counter	dc.b	$00
	; Resuming memory block at $3400
anim_idx	dc.b	0
	; Resuming memory block at $3400
anim_i	dc.b	0
	; Resuming memory block at $3400
blink_global_counter	dc.b	$00
	; Resuming memory block at $3400
blink_global_phase	dc.b	$00
	; Resuming memory block at $3400
linear_phase	dc.b	$00
	; Resuming memory block at $3400
linear_repeat	dc.b	$00
	; Resuming memory block at $3400
linear_band_rows	dc.b	$02
	; Resuming memory block at $3400
linear_row	dc.b	$00
	; Resuming memory block at $3400
vertical_phase	dc.b	$00
	; Resuming memory block at $3400
vertical_repeat	dc.b	$00
	; Resuming memory block at $3400
vertical_band_cols	dc.b	$02
	; Resuming memory block at $3400
vertical_row	dc.b	$00
	; Resuming memory block at $3400
vertical_col	dc.b	$00
	; Resuming memory block at $3400
vertical_current_color	dc.b	$00
	; Resuming memory block at $3400
vertical_table_base	dc.b	$00
	; Resuming memory block at $3400
vertical_scroll_offset	dc.b	$00
	; Resuming memory block at $3400
vertical_scroll_counter	dc.b	$00
	; Resuming memory block at $3400
vertical_scroll_direction	dc.b	$00
	; Resuming memory block at $3400
radial_phase	dc.b	$00
	; Resuming memory block at $3400
radial_scroll_counter	dc.b	$00
	; Resuming memory block at $3400
radial_update_active	dc.b	$00
	; Resuming memory block at $3400
radial_slice	dc.b	$00
	; Resuming memory block at $3400
radial_anchor_motion_index	dc.b	$00
	; Resuming memory block at $3400
radial_anchor_motion_counter	dc.b	$00
	; Resuming memory block at $3400
radial_row	dc.b	$00
	; Resuming memory block at $3400
radial_rows_left	dc.b	$00
	; Resuming memory block at $3400
radial_lut_base	dc.b	$20
	; Resuming memory block at $3400
cross_phase	dc.b	$00
	; Resuming memory block at $3400
cross_repeat	dc.b	$00
	; Resuming memory block at $3400
cross_idx	dc.b	$00
	; Resuming memory block at $3400
cross_row	dc.b	$00
	; Resuming memory block at $3400
cross_band_width	dc.b	$0a
	; Resuming memory block at $3400
cross_band_remaining	dc.b	$00
	; Resuming memory block at $3400
cross_current_color	dc.b	$00
	; Resuming memory block at $3400
rotating_lines_counter	dc.b	$00
	; Resuming memory block at $3400
rotating_lines_step	dc.b	$00
	; Resuming memory block at $3400
rotating_lines_direction	dc.b	$00
	; Resuming memory block at $3400
rotating_speed_current	dc.b	$08
	; Resuming memory block at $3400
rotating_move_enabled	dc.b	$00
	; Resuming memory block at $3400
rotating_move_offset	dc.b	$00
	; Resuming memory block at $3400
rotating_move_direction	dc.b	$00
	; Resuming memory block at $3400
rotating_scroll_phase	dc.b	$00
	; Resuming memory block at $3400
final23_scroll_phase	dc.b	$00
	; Resuming memory block at $3400
stage5_scroll_phase	dc.b	$00
	; Resuming memory block at $3400
final24_scroll_phase	dc.b	$00
	; Resuming memory block at $3400
final25_scroll_phase	dc.b	$00
	; Resuming memory block at $3400
rotating_bin_rows_left	dc.b	$00
	; Resuming memory block at $3400
rotating_bin_mirror	dc.b	$00
	; Resuming memory block at $3400
stage13_static_active	dc.b	$00
	; Resuming memory block at $3400
stage13_ghost_next_line	dc.b	$74
	; Resuming memory block at $3400
stage13_ghost_fine_scroll	dc.b	$07
	; Resuming memory block at $3400
stage13_consumed_update	dc.b	$00
	; Resuming memory block at $3400
show_stage	dc.b	$00
	; Resuming memory block at $3400
anim_sequence_started	dc.b	$00
	; Resuming memory block at $3400
anim_start_pending	dc.b	$00
	; Resuming memory block at $3400
anim_start_delay_counter	dc.b	$00
	; Resuming memory block at $3400
anim_combo_stage	dc.b	$00
	; Resuming memory block at $3400
anim_combo_period_counter	dc.b	$00
	; Resuming memory block at $3400
col_val	dc.b	0
	; Resuming memory block at $3400
char_original_207	dc.b $0, $0, $0, $0, $0, $0, $0, $0
	; Resuming memory block at $3400
char_original_208	dc.b $0, $0, $0, $0, $0, $0, $0, $0
	; Resuming memory block at $3400
char_original_204	dc.b $0, $0, $0, $0, $0, $0, $0, $0
	; Resuming memory block at $3400
char_original_250	dc.b $0, $0, $0, $0, $0, $0, $0, $0
	; Resuming memory block at $3400
outro_text_speed10_counter	dc.b	$00
	; Resuming memory block at $3400
outro_audio_phase	dc.b	$00
	; Resuming memory block at $3400
outro_audio_divider	dc.b	$00
EndBlock3400:
	org $3978
StartBlock3978:
	; Starting new memory block at $3978
shared_ocean_bridge
	incbin	 "C:/FPRICO/FPFINAL///shared_ocean_bridge.bin"
end_incbin_shared_ocean_bridge
EndBlock3978:
	org $39d2
StartBlock39d2:
	; Starting new memory block at $39d2
intro_sid2_heart_tick
	incbin	 "C:/FPRICO/FPFINAL///intro_sid2_heart_tick.bin"
end_incbin_intro_sid2_heart_tick
EndBlock39d2:
	org $3a00
StartBlock3a00:
	; Starting new memory block at $3a00
sea_waves_helper
	incbin	 "C:/FPRICO/FPFINAL///sea_waves.bin"
end_incbin_sea_waves_helper
EndBlock3a00:
	org $3abc
StartBlock3abc:
	; Starting new memory block at $3abc
intro_charset_anim
	incbin	 "C:/FPRICO/FPFINAL///intro_charset_anim.bin"
end_incbin_intro_charset_anim
EndBlock3abc:
	org $3b47
StartBlock3b47:
	; Starting new memory block at $3b47
intro_sid_addresses_a
	incbin	 "C:/FPRICO/FPFINAL///intro_sid_addresses_a.bin"
end_incbin_intro_sid_addresses_a
EndBlock3b47:
	org $3b8a
StartBlock3b8a:
	; Starting new memory block at $3b8a
intro_prompt_reveal
	incbin	 "C:/FPRICO/FPFINAL///intro_prompt_reveal.bin"
end_incbin_intro_prompt_reveal
EndBlock3b8a:
	org $3ba1
StartBlock3ba1:
	; Starting new memory block at $3ba1
intro_sid_addresses_b
	incbin	 "C:/FPRICO/FPFINAL///intro_sid_addresses_b.bin"
end_incbin_intro_sid_addresses_b
EndBlock3ba1:
	org $3be8
StartBlock3be8:
	org $3be8
radial_maps_low:
	incbin	 "C:/FPRICO/FPFINAL///radial_maps_low.bin"
end_incbin_radial_maps_low:
EndBlock3be8:
	org $5000
StartBlock5000:
	; Starting new memory block at $5000
vic_sprites = $d015
	; Resuming memory block at $5000
vic_d011 = $d011
	; Resuming memory block at $5000
vic_d016 = $d016
	; Resuming memory block at $5000
vic_d018 = $d018
	; Resuming memory block at $5000
vic_border = $d020
	; Resuming memory block at $5000
vic_fondo = $d021
	; Resuming memory block at $5000
	; ***********  Defining procedure : WaitVBlank
	;    Procedure type : User-defined procedure
WaitVBlank
wait_hit:
        lda $D012
        cmp #251
        bne wait_hit
wait_leave:
        lda $D012
        cmp #251
        beq wait_leave
    
	rts
end_procedure_WaitVBlank
	; NodeProcedureDecl 51
	; ***********  Defining procedure : MostrarPantallaDeteccion
	;    Procedure type : User-defined procedure
MostrarPantallaDeteccion
	lda #$0
	; Calling storevariable on generic assign expression
	sta detected_machine
	lda #$32
	; Calling storevariable on generic assign expression
	sta startup_intro_fps
        sei
        ; Pantalla apagada y negra durante la medicion.
        lda #$0B
        sta $D011
        lda #$00
        sta $D020
        sta $D021
        ; CIA1 Timer B = $FFFF.
        lda #$FF
        sta $DC06
        sta $DC07
        ; Esperar comienzo exacto de un frame:
        ; primero entrar en raster >255, luego volver a raster 0.
intro_detect_wait_hi_1:
        bit $D011
        bpl intro_detect_wait_hi_1
intro_detect_wait_zero_1:
        bit $D011
        bmi intro_detect_wait_zero_1
        ; Arrancar Timer B contando ciclos de CPU.
        lda #%00011001
        sta $DC0F
        ; Esperar exactamente el siguiente comienzo de frame.
intro_detect_wait_hi_2:
        bit $D011
        bpl intro_detect_wait_hi_2
intro_detect_wait_zero_2:
        bit $D011
        bmi intro_detect_wait_zero_2
        ; A sigue conteniendo $19, por eso recargar $FF.
        ; Diferencia del high-byte del timer:
        ; PAL-B  -> $4C -> bits bajos 00
        ; NTSC1  -> $41 -> bits bajos 01
        ; NTSC2  -> $42 -> bits bajos 10
        ; PAL-N  -> $4F -> bits bajos 11
        lda #$FF
        sec
        sbc $DC07
        and #$03
        tay
        ; Detener Timer B: ya termino la medicion.
        lda #$00
        sta $DC0F
        ; Traducir resultado bruto:
        ; 0 PAL-B -> 3
        ; 1 NTSC OLD -> 1
        ; 2 NTSC -> 2
        ; 3 DREAN -> 4
        tya
        beq intro_detect_tww_pal
        cmp #$03
        beq intro_detect_tww_drean
        ; 1 y 2 coinciden con nuestra codificacion.
        sta detected_machine
        jmp intro_detect_tww_done
intro_detect_tww_pal:
        lda #$03
        sta detected_machine
        jmp intro_detect_tww_done
intro_detect_tww_drean:
        lda #$04
        sta detected_machine
intro_detect_tww_done:
    
	; Binary clause Simplified: LESS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$3;keep
	bcs MostrarPantallaDeteccion_eblock6
MostrarPantallaDeteccion_ctb5: ;Main true block ;keep 
	
; // FIX22: deteccion robusta de VIC por ciclos de UN FRAME completo.
; // Timer B CIA1:
; // resultado bruto 0 = PAL-B
; // resultado bruto 1 = NTSC OLD
; // resultado bruto 2 = NTSC
; // resultado bruto 3 = DREAN PAL-N
; //
; // Luego lo convertimos a nuestra codificacion:
; // 1 = NTSC OLD, 2 = NTSC, 3 = PAL-B, 4 = DREAN PAL-N.
; // NTSC = ~60 fps. PAL-B y DREAN PAL-N = ~50 fps.
	lda #$3c
	; Calling storevariable on generic assign expression
	sta startup_intro_fps
	jmp MostrarPantallaDeteccion_edblock7
MostrarPantallaDeteccion_eblock6
	lda #$32
	; Calling storevariable on generic assign expression
	sta startup_intro_fps
MostrarPantallaDeteccion_edblock7
        lda $DD00
        ora #$03
        sta $DD00
        lda #$14
        sta $D018
        lda #$C8
        sta $D016
        lda #$1B
        sta $D011
        lda #$00
        sta $D020
        sta $D021
        ; Limpiar pantalla completa a espacios.
        lda #$20
        ldx #$00
intro_clear_screen_0:
        sta $0400,x
        sta $0500,x
        sta $0600,x
        inx
        bne intro_clear_screen_0
        ldx #$00
intro_clear_screen_tail:
        sta $0700,x
        inx
        cpx #$E8
        bne intro_clear_screen_tail
        ; Color base blanco.
        lda #$01
        ldx #$00
intro_clear_color_0:
        sta $D800,x
        sta $D900,x
        sta $DA00,x
        inx
        bne intro_clear_color_0
        ldx #$00
intro_clear_color_tail:
        sta $DB00,x
        inx
        cpx #$E8
        bne intro_clear_color_tail
        ; FIX36 diagnostic result scratch:
        ; startup_intro_seconds = SID LFSR functional flag (1/0).
        lda #$00
        sta startup_intro_seconds
        sta startup_intro_fps
        jsr $1C56  ; Show fixed user artwork before ANY diagnostics.
        lda detected_machine
        jsr $1D00  ; Patch ONLY machine row 6 in both art screens and color buffers.
        jsr $1E09  ; Hide existing LFSR and ENV3 results in visible artwork.
        jsr $1BC0  ; SID1: hide 6581-LIKE model text until real classification.
        jsr $C3AB  ; SID2 model hidden; fixed artwork DUAL SID MODE starts MONO.
        jsr $CFEA  ; Same original JOY hide + CPU/VIC/RAM OK hide, in bridge.
        jsr $18C7  ; Pending test hearts black. MACHINE is already tested/red.
        jsr $3B47  ; Conceal ONLY the two 5-character SID address fields.
        jsr $18F2  ; Hide full PRESS A KEY row 22 while all diagnostics run.
    
        ; FIX34: evidence-driven diagnostic agent.
        ldx #$00
intro_agent_hello_print:
        lda intro_msg_agent_hello,x
        beq intro_agent_hello_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_agent_hello_print
intro_agent_hello_done:
        jsr intro_term_pause
        jsr intro_term_scroll
        ; VIC-II / MACHINE TIMING
intro_type_vic_select:
        lda detected_machine
        cmp #$04
        beq intro_type_vic_drean_start
        cmp #$03
        beq intro_type_vic_pal_start
intro_type_vic_ntsc_start:
        ldx #$00
intro_type_vic_ntsc:
        lda intro_msg_vic_ntsc,x
        beq intro_type_vic_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_type_vic_ntsc
intro_type_vic_pal_start:
        ldx #$00
intro_type_vic_pal:
        lda intro_msg_vic_pal,x
        beq intro_type_vic_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_type_vic_pal
intro_type_vic_drean_start:
        ldx #$00
intro_type_vic_drean:
        lda intro_msg_vic_drean,x
        beq intro_type_vic_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_type_vic_drean
intro_type_vic_done:
        jsr intro_term_pause
        jsr intro_term_scroll
        jsr $CFF8  ; Identical VIC/CIA start instructions, relocated out of MAIN.
        ; VIC and CIA timing share the already measured VIC-frame / CIA1 Timer B result.
        ; Display one combined line; the two OKs are not independent measurements.
        ldx #$00
intro_type_vic_frame:
        lda intro_msg_vic_frame,x
        beq intro_type_vic_frame_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_type_vic_frame
intro_type_vic_frame_done:
        jsr intro_term_pause
        jsr $1BB5  ; Identical VIC/CIA result instructions, relocated out of MAIN.
        jsr intro_term_scroll
        ; OSC3/LFSR functional classification remains unchanged.
        ; The redundant CIA stability probe and OSC3 hexadecimal display are omitted.
intro_lfsr_setup:
        jsr $1E00  ; Activate red/pink heart for the REAL LFSR test.
        ; TEST=1 para partir de un estado limpio, luego NOISE.
        lda #$08
        sta $D412
        lda #$FF
        sta $D40E
        sta $D40F
        lda #$80
        sta $D412
        ; Dar tiempo al oscilador/LFSR para arrancar.
        jsr intro_term_wait_frame
        ; Preserve the original 24 frame OSC3 warm-up/sampling time, but do not
        ; draw the hexadecimal sample or consume a screen row.
        ldy #$18
intro_lfsr_warmup_loop:
        lda $D41B
        jsr intro_term_wait_frame
        dey
        bne intro_lfsr_warmup_loop
        ; Perfil de velocidad inspirado en ventanas de OSC3:
        ; tres ventanas consecutivas de 8 lecturas.
        ; Si las 3 dan 7 cambios => FAST.
        ldy #$03
intro_lfsr_fast_windows:
        jsr intro_lfsr_count8
        cmp #$07
        bne intro_lfsr_not_fast
        dey
        bne intro_lfsr_fast_windows
        lda #$01
        sta hardware_profile
        jmp intro_lfsr_classified
intro_lfsr_not_fast:
        ; Esperar unas decenas de ms y confirmar que haya actividad.
        ldy #$03
intro_lfsr_activity_wait:
        jsr intro_term_wait_frame
        dey
        bne intro_lfsr_activity_wait
        jsr intro_lfsr_count8
        cmp #$03
        bcc intro_lfsr_no_activity
        lda #$02
        sta hardware_profile
        jmp intro_lfsr_classified
intro_lfsr_no_activity:
        lda #$03
        sta hardware_profile
intro_lfsr_classified:
        ; Save a simple functional result for final OK/NO marking.
        ; FAST or SLOW = active generator = OK. NO ACTIVITY = NO.
        lda hardware_profile
        cmp #$03
        beq intro_lfsr_store_no
        lda #$01
        bne intro_lfsr_store_flag
intro_lfsr_store_no:
        lda #$00
intro_lfsr_store_flag:
        sta startup_intro_seconds
        ; Stop Voice 3 before printing its functional result on this same row.
        lda #$00
        sta $D412
        sta $D40E
        sta $D40F
        lda hardware_profile
        cmp #$01
        beq intro_type_lfsr_fast_start
        cmp #$02
        beq intro_type_lfsr_slow_start
intro_type_lfsr_no_start:
        ldx #$00
intro_type_lfsr_no:
        lda intro_msg_lfsr_no,x
        beq intro_type_lfsr_result_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_type_lfsr_no
intro_type_lfsr_slow_start:
        ldx #$00
intro_type_lfsr_slow:
        lda intro_msg_lfsr_slow,x
        beq intro_type_lfsr_result_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_type_lfsr_slow
intro_type_lfsr_fast_start:
        ldx #$00
intro_type_lfsr_fast:
        lda intro_msg_lfsr_fast,x
        beq intro_type_lfsr_result_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_type_lfsr_fast
intro_type_lfsr_result_done:
        lda startup_intro_seconds  ; Actual LFSR classification: 1=OK, 0=FAIL.
        jsr $1E03  ; Stop blinking, red heart; reveal real result with art colors.
        jsr intro_term_pause
        jsr intro_term_scroll
        ; SID ENV3 RESPONSE: use the original $C100 test and its real A=0/1 result.
        ; Visual-only hooks: second row's OK is hidden and heart blinks red/pink.
        jsr $1E0F  ; Start ENV3 heart, row 14.
        jsr $C100  ; Unchanged SID ENV3 test (returns A=0 FAIL / 1 OK).
        jsr $1E12  ; Freeze heart red, reveal OK from art or show real FAIL.
        jsr intro_term_pause
        jsr intro_term_scroll
        jmp intro_sid_model_test
        ; Cuenta cambios entre 8 lecturas consecutivas de OSC3.
        ; Devuelve A = 0..7.
intro_lfsr_count8:
        lda $D41B
        sta startup_intro_frame_counter
        lda #$00
        sta startup_intro_second_counter
        ldx #$07
intro_lfsr_count8_loop:
        lda $D41B
        cmp startup_intro_frame_counter
        beq intro_lfsr_count8_same
        inc startup_intro_second_counter
intro_lfsr_count8_same:
        sta startup_intro_frame_counter
        dex
        bne intro_lfsr_count8_loop
        lda startup_intro_second_counter
        rts
        ; ---------------------------------------------------------
        ; FIX29B: SID MODEL compacto.
        ; Test OSC3 de retardo: bit0 diferencia 6581/8580.
        ; ---------------------------------------------------------
intro_sid_model_test:
        jsr $1E18  ; SID1 heart begins red/pink blink; no SID test changed.
intro_sid_model_wait:
        lda $D012
        cmp #$FF
        bne intro_sid_model_wait
        lda #$FF
        sta $D412
        sta $D40E
        sta $D40F
        lda #$20
        sta $D412
        lda $D41B
        lsr
        bcc intro_sid_model_8580
intro_sid_model_6581:
        jsr $1BC9  ; Record existing 6581-LIKE branch, unchanged decision.
        ldx #$00
intro_sid_model_6581_print:
        lda intro_msg_sidmodel_6581,x
        beq intro_sid_model_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_sid_model_6581_print
intro_sid_model_8580:
        jsr $1BCC  ; Record existing 8580-LIKE branch, unchanged decision.
        ldx #$00
intro_sid_model_8580_print:
        lda intro_msg_sidmodel_8580,x
        beq intro_sid_model_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_sid_model_8580_print
intro_sid_model_done:
        ; FIX37: no short confirmation burst here.
        ; The final dual-SID sea test will keep the noise continuous.
        lda #$00
        sta $D412
        sta $D418
        jsr $1E1B  ; SID1 test finished; heart red, no effect on SID writes.
        jsr $1BC3  ; Reveal the detected model on the fixed art screen.
        jsr $3B5D  ; SID1 test complete: reveal standard $D400 from user's art.
        jsr intro_term_pause
        jsr intro_term_scroll
        ; ---------------------------------------------------------
        ; SECOND SID: DE00 (VICE default), D420 and D500.
        ; $FB/$FC = temporary candidate base pointer.
        ; ---------------------------------------------------------
        jsr $13E8  ; SID2 marker active: blink red/pink while address is probed.
        lda $FB
        pha
        lda $FC
        pha
        ; VICE uses $DE00 as the default second-SID base.
        lda #$00
        sta $FB
        lda #$DE
        sta $FC
        jsr intro_sid2_probe
        bcs intro_sid2_found_de00
        ; Very common internal stereo-SID address.
        lda #$20
        sta $FB
        lda #$D4
        sta $FC
        jsr intro_sid2_probe
        bcs intro_sid2_found_d420
        ; Another common internal stereo-SID address.
        lda #$00
        sta $FB
        lda #$D5
        sta $FC
        jsr intro_sid2_probe
        bcs intro_sid2_found_d500
intro_sid2_not_found:
        lda #$00
        sta startup_intro_second_counter
        jmp intro_sid2_restore
intro_sid2_found_de00:
        lda #$01
        bne intro_sid2_store_found
intro_sid2_found_d420:
        lda #$02
        bne intro_sid2_store_found
intro_sid2_found_d500:
        lda #$03
intro_sid2_store_found:
        sta startup_intro_second_counter
        jsr $C3C9  ; Confirmed SID2: visible MONO -> STEREO immediately.
intro_sid2_restore:
        ; Keep $FB/$FC pointing at the detected candidate.
        ; SID2 address detection is trusted here.
        ; Model classification is deliberately disabled until validated
        ; independently on VICE and real hardware.
        lda startup_intro_second_counter
        beq intro_sid2_no_start
        cmp #$01
        beq intro_sid2_de00_start
        cmp #$02
        beq intro_sid2_d420_start
        jmp intro_sid2_d500_start
intro_sid2_de00_start:
        ldx #$00
intro_sid2_de00_print:
        lda intro_msg_sid2_de00,x
        beq intro_sid2_print_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_sid2_de00_print
intro_sid2_d420_start:
        ldx #$00
intro_sid2_d420_print:
        lda intro_msg_sid2_d420,x
        beq intro_sid2_print_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_sid2_d420_print
intro_sid2_d500_start:
        ldx #$00
intro_sid2_d500_print:
        lda intro_msg_sid2_d500,x
        beq intro_sid2_print_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_sid2_d500_print
intro_sid2_no_start:
        ldx #$00
intro_sid2_no_print:
        lda intro_msg_sid2_no,x
        beq intro_sid2_print_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_sid2_no_print
intro_sid2_print_done:
intro_sid2_click_done:
        ; Save SID2 evidence address for final reasoning:
        ; 0 none, 1 DE00, 2 D420, 3 D500.
        lda startup_intro_second_counter
        sta hardware_profile
        jsr $C3DD  ; SID2 model UNKNOWN/NOT FOUND; mode real.
        ; Restore original temporary zero-page values.
        pla
        sta $FC
        pla
        sta $FB
        lda hardware_profile
        jsr $3BA1  ; SID2 test complete: render real address, or ----- if absent.
        jsr $17E8  ; SID2 completed: stop blink and leave its heart solid red.
        jsr intro_term_pause
        jsr intro_term_scroll
        ; SID REPLACEMENT TYPE - SIDKick-pico exact signature only.
        jsr $C300
        jsr intro_term_pause
        jsr intro_term_scroll
        ; Cosmetic DUAL heart runs for BOTH MONO and STEREO confirmations.
        jsr $1AA3  ; Start the row-16 red/pink heartbeat; no SID logic changed.
        ; Terminal history ON/OFF unchanged; fixed artwork mode is MONO/STEREO.
        lda hardware_profile
        beq intro_dual_mode_off_start
intro_dual_mode_on_start:
        ldx #$00
intro_dual_mode_on_print:
        lda intro_msg_dual_on,x
        beq intro_dual_mode_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_dual_mode_on_print
intro_dual_mode_off_start:
        ldx #$00
intro_dual_mode_off_print:
        lda intro_msg_dual_off,x
        beq intro_dual_mode_done
        sta $07C1,x
        jsr intro_term_wait_frame
        inx
        bne intro_dual_mode_off_print
intro_dual_mode_done:
        jsr intro_term_pause
        jsr $1AA6  ; DUAL confirmation finished: heart solid red in either mode.
        ; JOY check remains removed; continue directly to visual-only fake stage.
        jmp intro_post_dual_sid
        ; ---------------------------------------------------------
        ; FIX33: SECOND SID MIRROR + ACTIVITY PROBE
        ; Candidate base is in ($FB/$FC).
        ;
        ; Phase 1:
        ; Run NOISE on SID 1 ($D400), keep candidate silent.
        ; If candidate OSC3 becomes non-zero, candidate is a mirror.
        ;
        ; Phase 2:
        ; Run NOISE on the candidate itself.
        ; Require changing OSC3 values to confirm a real SID-like slot.
        ;
        ; C=1 independent active SID, C=0 mirror/absent.
        ; ---------------------------------------------------------
intro_sid2_probe:
        ; Keep candidate Voice 3 silent.
        lda #$00
        ldy #$12
        sta ($FB),y
        ldy #$0E
        sta ($FB),y
        iny
        sta ($FB),y
        ; Reset SID 1 Voice 3 / LFSR.
        lda #$08
        sta $D412
        lda #$00
        sta $D40E
        sta $D40F
        sta $D412
        ; SID 1 noise at maximum frequency.
        lda #$FF
        sta $D40E
        sta $D40F
        lda #$81
        sta $D412
        ; A mirror of SID 1 will now expose non-zero OSC3 here.
        ldx #$0A
intro_sid2_mirror_loop:
        ldy #$1B
        lda ($FB),y
        bne intro_sid2_probe_no
        dex
        bne intro_sid2_mirror_loop
        ; Candidate did NOT mirror SID 1. Stop SID 1.
        lda #$00
        sta $D412
        sta $D40E
        sta $D40F
        ; Now start candidate Voice 3 noise itself.
        lda #$08
        ldy #$12
        sta ($FB),y
        lda #$FF
        ldy #$0E
        sta ($FB),y
        iny
        sta ($FB),y
        lda #$80
        ldy #$12
        sta ($FB),y
        ; Give OSC3 time to advance.
        jsr intro_term_wait_frame
        ; Positive confirmation:
        ; require at least 3 changes across 8 candidate OSC3 reads.
        ldy #$1B
        lda ($FB),y
        sta hardware_profile
        lda #$00
        sta startup_intro_frame_counter
        ldx #$07
intro_sid2_activity_loop:
        ldy #$1B
        lda ($FB),y
        cmp hardware_profile
        beq intro_sid2_activity_same
        inc startup_intro_frame_counter
intro_sid2_activity_same:
        sta hardware_profile
        dex
        bne intro_sid2_activity_loop
        ; Stop candidate after probe.
        lda #$00
        ldy #$12
        sta ($FB),y
        ldy #$0E
        sta ($FB),y
        iny
        sta ($FB),y
        lda startup_intro_frame_counter
        cmp #$03
        bcc intro_sid2_probe_no_clean
        sec
        rts
intro_sid2_probe_no:
        ; Stop SID 1 if mirror / invalid candidate was seen.
        lda #$00
        sta $D412
        sta $D40E
        sta $D40F
intro_sid2_probe_no_clean:
        ; Also leave candidate Voice 3 off.
        lda #$00
        ldy #$12
        sta ($FB),y
        clc
        rts
        ; The UCI information-only probe was removed.
        ; JOY helper does its own initial scroll, immediately after DUAL SID.
intro_post_dual_sid:
        ; Fake JOY visual ONLY: no CIA reads, joystick probe or result inference.
        ; The original art's two OKs were hidden at initialization.
        jsr $1AA9  ; Red/pink heart while both OKs stay hidden.
        ldx #$06  ; 24 frames total: four visible six-frame color transitions.
intro_fake_joy_pause:
        jsr intro_term_pause
        dex
        bne intro_fake_joy_pause
        jsr $1AAC  ; Restore the original OK OK; heart solid red.
        jsr $1A40  ; Start existing IEC heartbeat; no IEC test changes.
        jsr intro_term_pause
        jsr intro_term_pause
        jsr intro_term_pause
        jsr $1900   ; IEC ACK test on 8-11; detection logic unchanged.
        jsr intro_term_pause
        jsr intro_term_pause
        jsr intro_term_pause
        jsr $1A43  ; IEC finished: freeze its heart solid red.
        jsr $1A17  ; Draw real 08/09/10/11 flags in both art screen pages.
        ; RAM tests execute beneath BASIC ROM ($A000-$BFFF).
        ; Temporarily clear LORAM, then restore exact original CPU port.
        lda $01
        pha
        and #$FE
        sta $01
        jsr $BFF0  ; Same RAM heart start; tail-jumps to unchanged test $BC60.
        pla
        sta $01
        ; Cosmetic-only COLOR RAM heart. No new test and no result text.
        ; The source artwork already contains this heart at column 38, row 18.
        lda #$0B
        sta $1FF6  ; Only new frame-handler state: COLOR RAM.
        lda #$00
        sta $1FF7
        lda #$02
        sta $DACD  ; Visible heart red; label and color sample unchanged.
        ldx #$06  ; 6 * 4 frames = 24, same fake animation as JOYSTICK.
intro_fake_color_heart_pause:
        jsr intro_term_pause
        dex
        bne intro_fake_color_heart_pause
        lda #$00
        sta $1FF6
        lda #$02
        sta $DACD  ; Stop color heartbeat, hold red.
        ; Cosmetic-only CHAR ROM heart, no ROM read and no OK/FAIL text.
        lda #$0C
        sta $1FF6
        lda #$00
        sta $1FF7
        lda #$02
        sta $DAF5  ; Row 19, column 38.
        ldx #$06
intro_fake_char_heart_pause:
        jsr intro_term_pause
        dex
        bne intro_fake_char_heart_pause
        lda #$00
        sta $1FF6
        lda #$02
        sta $DAF5  ; Stop char heartbeat, hold red.
        jmp intro_terminal_finished
        ; ---------------------------------------------------------
        ; Mark an existing diagnostic row.
        ; X = zero-based screen row.
        ; A = 0 -> NO (red), nonzero -> ON (green).
        ; Status is written in columns 38-39.
        ; Uses screen_lo/screen_hi lookup tables.
        ; ---------------------------------------------------------
intro_mark_status:
        ; FIX47D: DUAL SID adds one extra real history line.
        ; Rows VIDEO..SECOND SID therefore move up by one.
        ; No UCI row; other status placement logic is unchanged.
        cpx #$17
        beq intro_mark_status_row_ready
        ldy hardware_profile
        beq intro_mark_status_row_ready
        dex
intro_mark_status_row_ready:
        sta startup_intro_frame_counter
        lda $FB
        pha
        lda $FC
        pha
        lda screen_lo,x
        clc
        adc #$25
        sta $FB
        lda screen_hi,x
        adc #$00
        sta $FC
        lda startup_intro_frame_counter
        beq intro_mark_no
intro_mark_ok:
        ; FIX48: positive diagnostic state is displayed as ON.
        ldy #$00
        lda #$0F
        sta ($FB),y
        iny
        lda #$0E
        sta ($FB),y
        lda #$01
        bne intro_mark_color
intro_mark_no:
        ldy #$00
        lda #$0E
        sta ($FB),y
        iny
        lda #$0F
        sta ($FB),y
        lda #$01
intro_mark_color:
        sta startup_intro_frame_counter
        ; Same low byte; color RAM is screen RAM + $D400.
        lda $FC
        clc
        adc #$08
        sta $FC
        ldy #$00
        lda startup_intro_frame_counter
        sta ($FB),y
        iny
        sta ($FB),y
        pla
        sta $FC
        pla
        sta $FB
        rts
        ; ---------------------------------------------------------
        ; Espera de un frame fisico. No usa IRQ.
        ; ---------------------------------------------------------
intro_term_wait_frame:
intro_term_wait_hit:
        lda $D012
        cmp #251
        bne intro_term_wait_hit
intro_term_wait_leave:
        lda $D012
        cmp #251
        beq intro_term_wait_leave
        ; RUN/STOP durante el test: salida real a BASIC.
        ; Salva A y puertos CIA; no cambia X/Y ni los tests.
        jsr intro_check_runstop
        jsr intro_fake_color_char_heart_tick
        rts
        ; Dispatch original heartbeat unchanged for all original states (0..10).
        ; Only states 11/12 use the two new cosmetic heart positions.
        ; Preserve A. All callers overwrite processor flags after frame wait.
        ; No PHP/PLP: unsupported by this OrgAsm build and unnecessary here.
intro_fake_color_char_heart_tick:
        pha
        lda $1FF6
        cmp #$0B
        bcc intro_fake_color_char_original_tick
        cmp #$0D
        bcs intro_fake_color_char_original_tick
        inc $1FF7
        lda $1FF7
        cmp #$06
        bcc intro_fake_color_char_tick_done
        lda #$00
        sta $1FF7
        lda $1FF6
        cmp #$0B
        bne intro_fake_char_heart_flip
        lda $DACD
        eor #$08  ; VIC palette: red 2 <-> pink 10 (same as existing hearts).
        sta $DACD
        jmp intro_fake_color_char_tick_done
intro_fake_char_heart_flip:
        lda $DAF5
        eor #$08
        sta $DAF5
intro_fake_color_char_tick_done:
        pla
        rts
intro_fake_color_char_original_tick:
        pla
        jmp $1B68  ; Existing CPU/VIC/RAM/SID/IEC dispatch unchanged.
        ; Pausa corta entre lineas.
intro_term_pause:
        ; FIX24: pausa corta para meter muchos tests en ~10 segundos.
        ldy #4
intro_term_pause_loop:
        jsr intro_term_wait_frame
        dey
        bne intro_term_pause_loop
        rts
        ; FIX27B: filas 1..24 historial, fila 25 escritura.
intro_term_scroll:
        ; Rows 2..25 -> rows 1..24. Total: 960 bytes.
        ldx #$00
intro_term_scroll_pages:
        lda $0428,x
        sta $0400,x
        lda $0528,x
        sta $0500,x
        lda $0628,x
        sta $0600,x
        lda $0C28,x
        sta $0C00,x
        lda $0D28,x
        sta $0D00,x
        lda $0E28,x
        sta $0E00,x
        inx
        bne intro_term_scroll_pages
        ; Ultimos 192 bytes.
        ldx #$00
intro_term_scroll_tail:
        lda $0728,x
        sta $0700,x
        lda $0F28,x
        sta $0F00,x
        inx
        cpx #$C0
        bne intro_term_scroll_tail
        ; Limpiar fila 25.
intro_term_clear_row25:
        lda #$20
        ldx #$00
intro_term_clear_last:
        sta $07C0,x
        inx
        cpx #40
        bne intro_term_clear_last
        lda #$01
        ldx #$00
intro_term_clear_last_color:
        sta $0FC0,x
        inx
        cpx #40
        bne intro_term_clear_last_color
        rts
intro_terminal_finished:
        ; Row 22 key prompt stays hidden until the first sea frame runs.
        ; Row 23 remains blank; rows 24-25 are reserved for the animated sea.
        jsr intro_term_pause
        jsr $1C00  ; Restore art/color in screen $0400 before starting the approved sea.
        lda detected_machine
        jsr $1D00  ; Restore selected machine row after default artwork reload.
        jsr $1E0C  ; Preserve real LFSR/ENV3 FAIL on final artwork.
        jsr $1BC6  ; Preserve dynamically detected SID1 model on final $0400 art.
        jsr $18C7  ; Final art loader restores default heart colors: re-hide pending.
        jsr $CFF1  ; Same original completed hearts + basic results after reload.
        jsr $17E8  ; SID2 test finished too: preserve solid red on final reload.
        jsr $1AB2  ; Restore red DUAL and JOY hearts after artwork reload.
        lda hardware_profile
        jsr $3BAE  ; Restore SID2 actual address on final $0400 artwork.
        lda hardware_profile
        jsr $C3DD  ; Redraw model and MONO/STEREO after final art reload.
        jsr $1A17  ; Art reloaded: restore all four real IEC status values.
        jsr $1A43  ; Restore completed IEC heart in red after pending-heart reset.
        ; Loader hides pending hearts again: restore only these two finished
        ; cosmetic markers. No text / color sample / ROM sample is modified.
        lda #$02
        sta $DACD  ; COLOR RAM heart.
        sta $DAF5  ; CHAR ROM heart.
        jsr $1DF1  ; Hide row 22 again BEFORE switching to the reloaded art.
        lda #$1A
        sta $D018  ; $0400 screen + hybrid charset $2800 (same as approved version).
        ; Portada lista: el mensaje sigue oculto hasta completar todos los tests.
intro_press_key_setup:
        ; ---------------------------------------------------------
        ; FIX37: continuous dual-SID sea noise while waiting.
        ; The previous diagnostic results have already been marked,
        ; so these two bytes are now free to preserve $FB/$FC.
        ; ---------------------------------------------------------
        lda $FB
        sta startup_intro_seconds
        lda $FC
        sta startup_intro_second_counter
        lda #$00
        sta startup_intro_fps
        sta sid_ramp_frame_counter  ; Sea-only divider; demo resets it later.
        sta $3B46  ; Intro-only charset animation divider.
        sta $3B9E  ; Intro-only horizontal position divider.
        sta $3B9F  ; Intro-only subpixel offset (0..7).
        lda #$13  ; Initial column of the 2x2 sample.
        sta $3BA0  ; Intro-only horizontal position.
        ; SID1 wave: soft attack ($9), full sustain, release A.
        ; Stereo handoff is via envelopes, not $D418 (avoids volume clicks).
        lda #$90
        sta $D413
        lda #$FA
        sta $D414
        lda #$0F
        sta $D418
        lda #$81
        sta $D412
        ; If SID 2 was confirmed, point $FB/$FC at its real base.
        ; Compact lookup saves MAIN space before the fixed SID at $8C00.
        ldx hardware_profile
        beq intro_sea_setup_done
        lda intro_sid2_base_lo,x
        sta $FB
        lda intro_sid2_base_hi,x
        sta $FC
intro_sea_setup_sid2:
        ldy #$13
        lda #$90
        sta ($FB),y
        iny
        lda #$FA
        sta ($FB),y
        ldy #$18
        lda #$0F
        sta ($FB),y
        ; SID2 starts off; joins at phase $60, releases at $F0.
        ldy #$12
        lda #$80
        sta ($FB),y
intro_sea_setup_done:
        ; Set up low noise beds; initial frequency is updated by helper.
        ; X still contains hardware_profile and $FB/$FC points to SID2 if found.
        jsr $3A64
        ; Solo INTRO: preparar la entrada desde silencio, capas y filtro.
        ldx hardware_profile
        jsr $8400
        ; Save CIA1 configuration after sea setup.
        lda $DC00
        pha
        lda $DC02
        pha
        lda $DC03
        pha
        ; Port A salida / Port B entrada para scan de teclado.
        lda #$FF
        sta $DC02
        lda #$00
        sta $DC03
        ; Todos los tests YA terminaron. Mostrar el primer frame del mar y
        ; revelar AHORA PRESS A KEY, antes de aceptar cualquier pulsacion.
        jsr intro_sea_tick
        jsr intro_term_wait_frame
        jsr $3B8A  ; Restaura la fila original desde $1348 a $0748.
        jsr intro_sprite_window_init  ; Six sprites, overlay ONLY original 16-char sample.
        jsr intro_palette_scroll_init ; COLOR RAM row above: temporary palette 00..15.
        ; No aceptar la tecla con la que se lanzo el programa: soltar primero.
intro_press_key_wait_release_1:
        jsr intro_keyboard_any
        bne intro_press_key_wait_release_1
        ; Una sola lectura espuria ya NO puede iniciar la demo.
        ; Confirmar tecla pulsada en dos frames distintos.
intro_press_key_wait_press:
        jsr intro_keyboard_any
        beq intro_press_key_no_press
        jsr intro_term_wait_frame
        jsr intro_keyboard_any
        bne intro_press_key_got_press
intro_press_key_no_press:
        jsr intro_sea_tick
        jsr intro_sprite_window_tick  ; Sprite animation reads current charset bitmap.
        jsr intro_palette_scroll_tick ; Rotate 16 COLOR RAM cells LEFT; no sprite conflict.
        jsr intro_term_wait_frame
        jmp intro_press_key_wait_press
intro_press_key_got_press:
        jsr intro_prompt_s_source_scan ; Referencia simbolica: fuerza incluir el bloque $1A2E.
        jsr intro_sprite_window_stop  ; Disable sprites, restore the 16 original codes.
        ; FIX39: stop modulation and blank the screen immediately.
        lda #$0B
        sta $D011
        lda #$00
        sta $D020
        sta $D021
        ; El fade se realiza con los GATE encendidos; apagarlos SOLO en volumen 0.
        jsr intro_sea_handoff
        ; Mar ya silenciado: esperar a que se suelte la tecla.
intro_press_key_wait_release_2:
        jsr intro_keyboard_any
        beq intro_press_key_restore
        jsr intro_term_wait_frame
        jmp intro_press_key_wait_release_2
intro_press_key_restore:
        pla
        sta $DC03
        pla
        sta $DC02
        pla
        sta $DC00
        ; Restore original zero-page pointer for the real demo.
        lda startup_intro_seconds
        sta $FB
        lda startup_intro_second_counter
        sta $FC
        jmp intro_prompt_s_source_dispatch ; Referencia simbolica: fuerza incluir el bloque $1A94.
        ; ---------------------------------------------------------
        ; FIX37: one frame of dual-SID sea modulation.
        ; startup_intro_fps = phase.
        ; hardware_profile  = 0 none, 1 DE00, 2 D420, 3 D500.
        ; If SID2 exists, $FB/$FC already point to its base.
        ; ---------------------------------------------------------
intro_sea_tick:
        ; SOLO INTRO: sostener cada cresta 5 s ADICIONALES en PAL/NTSC.
        ; Mantener la MISMA fase para audio y caracteres; no adelantar la
        ; siguiente ola durante el rompimiento. Contador en BIN $8409.
        lda startup_intro_fps
        and #$7F
        cmp #$60               ; crestas globales $60 y $E0.
        bne intro_sea_tick_step
        ldx detected_machine   ; 0..2 PAL, 3..4 NTSC.
        jsr $8409
        beq intro_sea_hold_phase
        ; Termino la espera: salir de la cresta de una vez.
        inc startup_intro_fps
        lda #$08               ; conservar alineacion de fases 16/8 cuadros.
        sta sid_ramp_frame_counter
        jmp intro_sea_hold_phase
intro_sea_tick_step:
        ; Calma larga que ya gustaba: $10-$1F y $90-$9F.
        inc sid_ramp_frame_counter
        lda startup_intro_fps
        and #$7F
        cmp #$10
        bcc intro_sea_step_normal
        cmp #$20
        bcs intro_sea_step_normal
        lda sid_ramp_frame_counter
        and #$0F
        bne intro_sea_hold_phase
        jmp intro_sea_step_advance
intro_sea_step_normal:
        ; SOLO ASCENSO: $20-$5F / $A0-$DF pasan de 6 a 4 frames.
        ; $00-$0F, calma $10-$1F, cresta y retirada: sin cambios.
        lda startup_intro_fps
        and #$7F
        cmp #$20
        bcc intro_sea_step_eight
        cmp #$60
        bcs intro_sea_step_eight
        lda sid_ramp_frame_counter
        and #$07               ; acepta el contador al entrar desde la calma
        cmp #$04
        bne intro_sea_hold_phase
        lda #$00
        sta sid_ramp_frame_counter
        jmp intro_sea_step_advance
intro_sea_step_eight:
        lda sid_ramp_frame_counter
        and #$07
        bne intro_sea_hold_phase
intro_sea_step_advance:
        inc startup_intro_fps
intro_sea_hold_phase:
        ; No new per-frame variables or changes to the SID player.
        lda startup_intro_fps
        ldx hardware_profile
        jsr $3ABC
        ; Solo INTRO: fade de volumen, filtro de cresta y deriva por ola.
        lda startup_intro_fps
        ldx hardware_profile
        jsr $8403
        lda startup_intro_fps
        ldx hardware_profile
        jsr $1800  ; Intro-only smooth screen movement.
        rts
        ; ---------------------------------------------------------
        ; INTRO EXIT: fade completo ANTES del GATE OFF (SID1 y SID2).
        ; Prueba: fade largo de 80 cuadros fisicos (1.6 s PAL).
        ; $8871/$8872 son fade_volume/fade_divider del BIN de INTRO:
        ; accesos a RAM, NUNCA lecturas de registros SID write-only.
        ; ---------------------------------------------------------
intro_sea_handoff:
intro_sea_handoff_pause:
        ldx #$50
intro_black_pause_loop:
        ; Techo = floor(3 * cuadros_restantes / 16): 15..0 en 80 cuadros.
        ; Misma longitud de codigo: LSR en vez de ASL; evita mover direcciones.
        ; Nunca subir el techo anterior: permite salir tambien durante fade-in.
        txa
        lsr
        sta startup_intro_frame_counter
        txa
        clc
        adc startup_intro_frame_counter
        lsr
        lsr
        lsr
        cmp $8871
        bcs intro_exit_cap_ready
        sta $8871
intro_exit_cap_ready:
        ; El TICK normal aumenta el fade-in cada 12 cuadros; bloquearlo
        ; exclusivamente mientras dura esta salida.
        lda #$00
        sta $8872
        txa
        pha
        ; Fase congelada: misma ola/filtro/espuma, ningun nuevo comienzo.
        ; El tick recalcula los DOS volumenes con el techo descendente.
        lda startup_intro_fps
        ldx hardware_profile
        jsr $8403
        pla
        tax
        jsr intro_term_wait_frame
        dex
        bne intro_black_pause_loop
        ; El ultimo TICK dejo volumen 0 en ambos chips. Ahora si:
        ; mantener volumen en 0, soltar las voces y desactivar el filtro.
        ; NO llamar $8406: ese cleanup restablecia volumen $0F y
        ; volvia audible la cola de release durante el cambio a VICIOS.
        lda #$00
        sta $D418
        ldx hardware_profile
        beq intro_exit_sid2_muted
        ldy #$18
        sta ($FB),y
intro_exit_sid2_muted:
        ldx hardware_profile
        jsr $3AA7
        lda #$00
        sta $D417
        ldx hardware_profile
        beq intro_exit_cleanup_done
        ldy #$17
        sta ($FB),y
intro_exit_cleanup_done:
        rts
        ; ---------------------------------------------------------
        ; A != 0 si hay alguna tecla del teclado pulsada.
        ; Con PA=$FF obtenemos el estado base de PB (incluye joystick 1).
        ; Con PA=$00 activamos todas las columnas del teclado.
        ; AND con la base filtra bits de joystick mantenidos.
        ; ---------------------------------------------------------
intro_keyboard_any:
        lda #$FF
        sta $DC00
        lda $DC01
        sta startup_intro_frame_counter
        lda #$00
        sta $DC00
        lda $DC01
        eor #$FF
        and startup_intro_frame_counter
        ; Tambien acepta RUN/STOP en el prompt final (incluso en wait_release).
        jsr intro_check_runstop
        rts
        ; Escanear SOLO PA7/PB7 y restaurar exactamente puertos CIA1.
        ; Con salida a BASIC, la rutina existente restablece CIA/KERNAL.
intro_check_runstop:
        pha
        lda $DC00
        pha
        lda $DC02
        pha
        lda $DC03
        pha
        lda #$FF
        sta $DC02
        lda #$00
        sta $DC03
        lda #$7F
        sta $DC00
        lda $DC01
        and #$80
        beq intro_runstop_to_basic
        pla
        sta $DC03
        pla
        sta $DC02
        pla
        sta $DC00
        pla
        rts
intro_runstop_to_basic:
        jmp _vote_basic_exit_common
        ; ---------------------------------------------------------
        ; EXPERIMENTAL 16-CELL VERTICAL CHARSET WINDOW. Intro ONLY.
        ; - Char sample: screen $06E4..$06F3, row 19, columns 21..36.
        ; - Six MONO sprites: x=184..304, y=194; original sample is white.
        ; - Sprite data: $3000..$317F (screen B, idle until demo init).
        ; - Original charset $2800..$2FFF remains READ-ONLY, including
        ;   all live custom/animated glyphs. No VIC fine-scroll changes.
        ; - All 16 columns scroll UP as a single group, 1 pixel per step.
        ; - Next group is +16 glyphs, wraps $F0..$FF => $00..$0F.
        ; - Six sprite Y-rows 8..20 remain zero: no drawing in next row.
        ; - The demo's RenderizarBinarios clears screen B AFTER intro.
        ; ---------------------------------------------------------
intro_sprite_window_init:
        pha
        txa
        pha
        tya
        pha
        lda #$00
        sta intro_sprite_group
        sta intro_sprite_phase
        sta intro_sprite_divider
        sta intro_sprite_row
        lda #$28
        sta intro_sprite_hold  ; Mantener grupo 40 cuadros, sincronizado al mar lento.
        ; Preserve X-high register, and discard original screen-B data
        ; only after EVERY test, when screen $0400 is the visible artwork.
        lda $D010
        sta intro_sprite_saved_xhi
        lda #$00
        ldx #$3F
intro_sprite_window_clear:
        sta $3000,x
        sta $3040,x
        sta $3080,x
        sta $30C0,x
        sta $3100,x
        sta $3140,x
        dex
        bpl intro_sprite_window_clear
        ; Blank ONLY the 16 characters beneath sprite pixels. The blank
        ; glyph 32 is already 00 00 ... in the existing charset.
        lda #$20
        ldx #$00
intro_sprite_window_blank:
        sta $06E4,x
        inx
        cpx #$10
        bne intro_sprite_window_blank
        ; Screen $0400 sprite pointers $07F8..$07FD => $3000..$3140.
        lda #$C0
        ldx #$00
intro_sprite_window_pointers:
        sta $07F8,x
        clc
        adc #$01
        inx
        cpx #$06
        bne intro_sprite_window_pointers
        ; Use six independent 24px-wide sprites to cover 128px total.
        ; The 6th sprite has only one used byte per scanline.
        lda #$38
        sta $D010  ; Sprite indices 3,4,5 have X >=256.
        lda #$00
        sta $D017  ; Disable Y-expansion.
        sta $D01D  ; Disable X-expansion.
        sta $D01C  ; Monochrome sprites, exact original 1-bit bitmap.
        sta $D01B  ; Foreground priority over blank sample cells.
        lda #$01  ; Sample's ORIGINAL WHITE color.
        sta $D027
        sta $D028
        sta $D029
        sta $D02A
        sta $D02B
        sta $D02C
        lda #$C2  ; Sprite top matches screen row 18 (0-based): 50+18*8.
        sta $D001
        sta $D003
        sta $D005
        sta $D007
        sta $D009
        sta $D00B
        lda #$B8  ; X=184, 208, 232, 256, 280, 304.
        sta $D000
        lda #$D0
        sta $D002
        lda #$E8
        sta $D004
        lda #$00
        sta $D006
        lda #$18
        sta $D008
        lda #$30
        sta $D00A
        jsr intro_sprite_window_render
        lda #$3F
        sta $D015  ; Enable only sprites 0..5, after initial bitmap built.
        pla
        tay
        pla
        tax
        pla
        rts
intro_sprite_window_tick:
        pha
        txa
        pha
        tya
        pha
        lda intro_sprite_hold
        beq intro_sprite_window_advance
        dec intro_sprite_hold
        jmp intro_sprite_window_redraw
intro_sprite_window_advance:
        inc intro_sprite_divider
        lda intro_sprite_divider
        cmp #$08  ; Un pixel cada 8 cuadros; acompana ciclo del mar.
        bcc intro_sprite_window_redraw
        lda #$00
        sta intro_sprite_divider
        inc intro_sprite_phase
        lda intro_sprite_phase
        cmp #$08
        bcc intro_sprite_window_redraw
        lda #$00
        sta intro_sprite_phase
        inc intro_sprite_group
        lda intro_sprite_group
        and #$0F
        sta intro_sprite_group
        lda #$28
        sta intro_sprite_hold
intro_sprite_window_redraw:
        ; Render on every idle frame: animated custom glyphs continue moving.
        jsr intro_sprite_window_render
        pla
        tay
        pla
        tax
        pla
        rts
intro_sprite_window_stop:
        pha
        txa
        pha
        lda #$00
        sta $D015  ; Stop overlay before returning to original demo.
        lda intro_sprite_saved_xhi
        sta $D010
        ldx #$00
intro_sprite_window_restore:
        txa
        sta $06E4,x  ; Restore EXACT original screen codes $00..$0F.
        inx
        cpx #$10
        bne intro_sprite_window_restore
        pla
        tax
        pla
        rts
intro_sprite_window_render:
        ; Preserve ZP $22/$23 (also used later by demo char engine).
        pha
        txa
        pha
        tya
        pha
        lda $22
        pha
        lda $23
        pha
        ; Group start character = group * 16; charset base = $2800+group*128.
        lda intro_sprite_group
        lsr
        clc
        adc #$28
        sta intro_sprite_old_hi
        lda intro_sprite_group
        and #$01
        beq intro_sprite_window_old_low_zero
        lda #$80
intro_sprite_window_old_low_ready:
        sta intro_sprite_old_lo
        jmp intro_sprite_window_next_group
intro_sprite_window_old_low_zero:
        lda #$00
        jmp intro_sprite_window_old_low_ready
intro_sprite_window_next_group:
        lda intro_sprite_group
        clc
        adc #$01
        and #$0F
        pha
        lsr
        clc
        adc #$28
        sta intro_sprite_next_hi
        pla
        and #$01
        beq intro_sprite_window_next_low_zero
        lda #$80
intro_sprite_window_next_low_ready:
        sta intro_sprite_next_lo
        jmp intro_sprite_window_rows_begin
intro_sprite_window_next_low_zero:
        lda #$00
        jmp intro_sprite_window_next_low_ready
intro_sprite_window_rows_begin:
        lda #$00
        sta intro_sprite_row
        ldx #$00  ; 3 bytes per scanline in sprite bitmap.
intro_sprite_window_row_loop:
        lda intro_sprite_row
        clc
        adc intro_sprite_phase
        cmp #$08
        bcc intro_sprite_window_source_old
        ; New group enters from bottom: glyph row = r+phase-8.
        sbc #$08
        ora intro_sprite_next_lo  ; 128-byte aligned source groups.
        sta $22
        lda intro_sprite_next_hi
        sta $23
        jmp intro_sprite_window_source_ready
intro_sprite_window_source_old:
        ora intro_sprite_old_lo
        sta $22
        lda intro_sprite_old_hi
        sta $23
intro_sprite_window_source_ready:
        ; Unrolled 16 char reads; source offset 8*character_index.
        ; 6 sprite strips = [3+3+3+3+3+1] characters per row.
        ldy #$00
        lda ($22),y
        sta $3000,x
        ldy #$08
        lda ($22),y
        sta $3001,x
        ldy #$10
        lda ($22),y
        sta $3002,x
        ldy #$18
        lda ($22),y
        sta $3040,x
        ldy #$20
        lda ($22),y
        sta $3041,x
        ldy #$28
        lda ($22),y
        sta $3042,x
        ldy #$30
        lda ($22),y
        sta $3080,x
        ldy #$38
        lda ($22),y
        sta $3081,x
        ldy #$40
        lda ($22),y
        sta $3082,x
        ldy #$48
        lda ($22),y
        sta $30C0,x
        ldy #$50
        lda ($22),y
        sta $30C1,x
        ldy #$58
        lda ($22),y
        sta $30C2,x
        ldy #$60
        lda ($22),y
        sta $3100,x
        ldy #$68
        lda ($22),y
        sta $3101,x
        ldy #$70
        lda ($22),y
        sta $3102,x
        ldy #$78
        lda ($22),y
        sta $3140,x
        inc intro_sprite_row
        inx
        inx
        inx
        cpx #$18
        beq intro_sprite_window_render_done
        jmp intro_sprite_window_row_loop
intro_sprite_window_render_done:
        pla
        sta $23
        pla
        sta $22
        pla
        tay
        pla
        tax
        pla
        rts
        ; ---------------------------------------------------------
        ; COLOR RAM SAMPLE: independent 16-CELL LEFTWARD COLOR CYCLE.
        ; ORIGINAL artwork has one blank cell ($06BC), then 15 filled
        ; cells ($06BD..$06CB). Use precisely these 16 positions.
        ; Display original hardware colors 0..15: color zero is BLACK,
        ; intentionally invisible against black background. The existing
        ; $A0 charset glyph is a filled 8x8 block; charset is untouched.
        ; Color RAM palette ONLY: $DABC..$DACB, gap $DACC and heart $DACD untouched,
        ; grey label, border, charset, SID, or sprite registers.
        ; ONE 8-pixel cell left every 8 idle frames. Hardware cannot
        ; blend 16 arbitrary colors at subcell steps via COLOR RAM only.
        ; Animation stops and restores exact BIN artwork when key pressed.
        ; ---------------------------------------------------------
intro_palette_scroll_init:
        pha
        txa
        pha
        lda #$00
        sta intro_palette_divider
        ldx #$00
intro_palette_scroll_init_loop:
        txa                       ; Color code x: 0..15.
        sta $DABC,x
        inx
        cpx #$10
        bne intro_palette_scroll_init_loop
        lda #$A0                  ; First slot was originally blank.
        sta $06BC                ; First SAMPLE cell; keep the blank gap at $06CC.
        pla
        tax
        pla
        rts
intro_palette_scroll_tick:
        pha
        txa
        pha
        inc intro_palette_divider
        lda intro_palette_divider
        cmp #$08                 ; One COLOR CELL every 8 idle frames.
        bcc intro_palette_scroll_tick_done
        lda #$00
        sta intro_palette_divider
        lda $DABC               ; Keep exact outgoing color (including 0).
        pha
        ldx #$00
intro_palette_scroll_shift:
        lda $DABD,x
        sta $DABC,x
        inx
        cpx #$0F
        bne intro_palette_scroll_shift
        pla
        sta $DACB               ; Wrap first color to last cell.
intro_palette_scroll_tick_done:
        pla
        tax
        pla
        rts
intro_palette_scroll_stop:
        pha
        txa
        pha
        ldx #$00
intro_palette_scroll_restore:
        txa                       ; x=1..15 => original colors 1..15.
        cpx #$00
        bne intro_palette_scroll_restore_write
        lda #$03                  ; Original color of blank cell col20.
intro_palette_scroll_restore_write:
        sta $DABC,x
        inx
        cpx #$10
        bne intro_palette_scroll_restore
        lda #$20
        sta $06BC               ; Restore original empty FIRST cell; gap remains untouched.
        pla
        tax
        pla
        rts
intro_press_key_done:
    
	rts
end_procedure_MostrarPantallaDeteccion
	
; // VIC bank 0, Screen $0400, charset ROM $1000.
; // FIX29B: viejo detector REAL/EMU retirado.
; // Terminal tipo DOS: escribir caracter por caracter en la ultima fila
; // y subir una fila completa entre pruebas.
; // EXIT: fade de 40 cuadros y GATE OFF a volumen 0; musica inicializa su propio SID.
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarDegradeLineal
	;    Procedure type : User-defined procedure
AplicarDegradeLineal
        pha
        txa
        pha
        tya
        pha
        lda linear_subdivision
        bne linear_sub_not_zero
        lda #1
        sta linear_subdivision
linear_sub_not_zero:
        lda linear_subdivision
        cmp #9
        bcc linear_sub_valid
        lda #8
        sta linear_subdivision
linear_sub_valid:
        lda #9
        sec
        sbc linear_subdivision
        sta linear_band_rows
        lda #0
        sta linear_phase
        sta linear_repeat
        sta linear_row
linear_row_loop:
        lda linear_mirror
        beq linear_target_normal
        lda #24
        sec
        sbc linear_row
        tax
        jmp linear_target_ready
linear_target_normal:
        ldx linear_row
linear_target_ready:
        lda color_lo,x
        sta $FC
        lda color_hi,x
        sta $FD
        lda linear_phase
        asl
        tax
        lda color_degrade,x
        ldy #39
linear_cell_loop:
        sta ($FC),y
        dey
        bpl linear_cell_loop
        inc linear_repeat
        lda linear_repeat
        cmp linear_band_rows
        bcc linear_phase_done
        lda #0
        sta linear_repeat
        inc linear_phase
        lda linear_phase
        cmp #6
        bcc linear_phase_done
        lda #0
        sta linear_phase
linear_phase_done:
        inc linear_row
        lda linear_row
        cmp #25
        beq linear_done
        jmp linear_row_loop
linear_done:
        pla
        tay
        pla
        tax
        pla
    
	rts
end_procedure_AplicarDegradeLineal
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarDegradeVertical
	;    Procedure type : User-defined procedure
AplicarDegradeVertical
        pha
        txa
        pha
        tya
        pha
        lda vertical_subdivision
        bne vertical_geo_sub_not_zero
        lda #1
        sta vertical_subdivision
vertical_geo_sub_not_zero:
        lda vertical_subdivision
        cmp #5
        bcc vertical_geo_sub_valid
        lda #4
        sta vertical_subdivision
vertical_geo_sub_valid:
        lda vertical_subdivision
        sec
        sbc #1
        sta vertical_table_base
        asl
        sta vertical_row
        asl
        clc
        adc vertical_row
        sta vertical_table_base
        lda #0
        sta vertical_phase
        sta vertical_repeat
        sta vertical_col
vertical_geo_col_loop:
        lda vertical_table_base
        clc
        adc vertical_phase
        tax
        lda vertical_phase_width_table,x
        sta vertical_band_cols
        lda vertical_phase
        asl
        tax
        lda color_degrade,x
        sta vertical_current_color
        lda vertical_mirror
        beq vertical_geo_target_normal
        lda #39
        sec
        sbc vertical_col
        jmp vertical_geo_target_ready
vertical_geo_target_normal:
        lda vertical_col
vertical_geo_target_ready:
        clc
        adc vertical_scroll_offset
        cmp #40
        bcc vertical_geo_target_ok
        sbc #40
vertical_geo_target_ok:
        tax
        lda vertical_current_color
        sta $D800,x
        sta $D828,x
        sta $D850,x
        sta $D878,x
        sta $D8A0,x
        sta $D8C8,x
        sta $D8F0,x
        sta $D918,x
        sta $D940,x
        sta $D968,x
        sta $D990,x
        sta $D9B8,x
        sta $D9E0,x
        sta $DA08,x
        sta $DA30,x
        sta $DA58,x
        sta $DA80,x
        sta $DAA8,x
        sta $DAD0,x
        sta $DAF8,x
        sta $DB20,x
        sta $DB48,x
        sta $DB70,x
        sta $DB98,x
        sta $DBC0,x
        inc vertical_repeat
        lda vertical_repeat
        cmp vertical_band_cols
        bcc vertical_geo_phase_done
        lda #0
        sta vertical_repeat
        inc vertical_phase
        lda vertical_phase
        cmp #6
        bcc vertical_geo_phase_done
        lda #0
        sta vertical_phase
vertical_geo_phase_done:
        inc vertical_col
        lda vertical_col
        cmp #40
        beq vertical_geo_done
        jmp vertical_geo_col_loop
vertical_geo_done:
        pla
        tay
        pla
        tax
        pla
    
	rts
end_procedure_AplicarDegradeVertical
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarScrollDegradeVertical
	;    Procedure type : User-defined procedure
ActualizarScrollDegradeVertical
	; Binary clause Simplified: EQUALS
	lda vertical_scroll_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarScrollDegradeVertical_localfailed277
	jmp ActualizarScrollDegradeVertical_ctb16
ActualizarScrollDegradeVertical_localfailed277
	jmp ActualizarScrollDegradeVertical_edblock18
ActualizarScrollDegradeVertical_ctb16: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda vertical_scroll_speed
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs ActualizarScrollDegradeVertical_edblock282
ActualizarScrollDegradeVertical_ctb280: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta vertical_scroll_speed
ActualizarScrollDegradeVertical_edblock282
	; Binary clause Simplified: LESS
	lda vertical_scroll_counter
	; Compare with pure num / var optimization
	cmp vertical_scroll_speed;keep
	bcs ActualizarScrollDegradeVertical_edblock287
ActualizarScrollDegradeVertical_ctb285: ;Main true block ;keep 
	; Test Inc dec D
	inc vertical_scroll_counter
ActualizarScrollDegradeVertical_edblock287
	; Binary clause Simplified: GREATEREQUAL
	lda vertical_scroll_counter
	; Compare with pure num / var optimization
	cmp vertical_scroll_speed;keep
	bcc ActualizarScrollDegradeVertical_localfailed293
	jmp ActualizarScrollDegradeVertical_ctb290
ActualizarScrollDegradeVertical_localfailed293
	jmp ActualizarScrollDegradeVertical_edblock292
ActualizarScrollDegradeVertical_ctb290: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda scroll_coarse_event
	; cmp #$00 ignored
	bne ActualizarScrollDegradeVertical_localfailed299
	jmp ActualizarScrollDegradeVertical_ctb296
ActualizarScrollDegradeVertical_localfailed299
	jmp ActualizarScrollDegradeVertical_edblock298
ActualizarScrollDegradeVertical_ctb296: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_counter
	; Binary clause Simplified: EQUALS
	clc
	lda vertical_scroll_motion
	; cmp #$00 ignored
	bne ActualizarScrollDegradeVertical_eblock303
ActualizarScrollDegradeVertical_ctb302: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda vertical_scroll_direction
	; cmp #$00 ignored
	bne ActualizarScrollDegradeVertical_eblock308
ActualizarScrollDegradeVertical_ctb307: ;Main true block ;keep 
	; Test Inc dec D
	inc vertical_scroll_offset
	; Binary clause Simplified: GREATEREQUAL
	lda vertical_scroll_offset
	; Compare with pure num / var optimization
	cmp #$28;keep
	bcc ActualizarScrollDegradeVertical_edblock314
ActualizarScrollDegradeVertical_ctb312: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_offset
ActualizarScrollDegradeVertical_edblock314
	jmp ActualizarScrollDegradeVertical_edblock309
ActualizarScrollDegradeVertical_eblock308
	; Binary clause Simplified: EQUALS
	clc
	lda vertical_scroll_offset
	; cmp #$00 ignored
	bne ActualizarScrollDegradeVertical_eblock319
ActualizarScrollDegradeVertical_ctb318: ;Main true block ;keep 
	lda #$27
	; Calling storevariable on generic assign expression
	sta vertical_scroll_offset
	jmp ActualizarScrollDegradeVertical_edblock320
ActualizarScrollDegradeVertical_eblock319
	; Test Inc dec D
	dec vertical_scroll_offset
ActualizarScrollDegradeVertical_edblock320
ActualizarScrollDegradeVertical_edblock309
	jmp ActualizarScrollDegradeVertical_edblock304
ActualizarScrollDegradeVertical_eblock303
	; Binary clause Simplified: EQUALS
	clc
	lda vertical_scroll_direction
	; cmp #$00 ignored
	bne ActualizarScrollDegradeVertical_eblock326
ActualizarScrollDegradeVertical_ctb325: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda vertical_scroll_offset
	; Compare with pure num / var optimization
	cmp #$27;keep
	bcc ActualizarScrollDegradeVertical_eblock331
ActualizarScrollDegradeVertical_ctb330: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta vertical_scroll_direction
	; Binary clause Simplified: GREATEREQUAL
	lda vertical_scroll_offset
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcc ActualizarScrollDegradeVertical_edblock337
ActualizarScrollDegradeVertical_ctb335: ;Main true block ;keep 
	; Test Inc dec D
	dec vertical_scroll_offset
ActualizarScrollDegradeVertical_edblock337
	jmp ActualizarScrollDegradeVertical_edblock332
ActualizarScrollDegradeVertical_eblock331
	; Test Inc dec D
	inc vertical_scroll_offset
ActualizarScrollDegradeVertical_edblock332
	jmp ActualizarScrollDegradeVertical_edblock327
ActualizarScrollDegradeVertical_eblock326
	; Binary clause Simplified: EQUALS
	clc
	lda vertical_scroll_offset
	; cmp #$00 ignored
	bne ActualizarScrollDegradeVertical_eblock343
ActualizarScrollDegradeVertical_ctb342: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_direction
	; Test Inc dec D
	inc vertical_scroll_offset
	jmp ActualizarScrollDegradeVertical_edblock344
ActualizarScrollDegradeVertical_eblock343
	; Test Inc dec D
	dec vertical_scroll_offset
ActualizarScrollDegradeVertical_edblock344
ActualizarScrollDegradeVertical_edblock327
ActualizarScrollDegradeVertical_edblock304
	jsr AplicarDegradeVertical
ActualizarScrollDegradeVertical_edblock298
ActualizarScrollDegradeVertical_edblock292
ActualizarScrollDegradeVertical_edblock18
	rts
end_procedure_ActualizarScrollDegradeVertical
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarDegradeRadialSlice
	;    Procedure type : User-defined procedure
AplicarDegradeRadialSlice
        pha
        txa
        pha
        tya
        pha
        lda radial_subdivision
        bne radial_sub_not_zero
        lda #1
        sta radial_subdivision
radial_sub_not_zero:
        cmp #5
        bcc radial_sub_valid
        lda #4
        sta radial_subdivision
radial_sub_valid:
        sec
        sbc #1
        asl
        asl
        asl
        asl
        asl
        asl
        sta radial_lut_base
        lda radial_anchor
        cmp #9
        bcc radial_anchor_valid
        lda #0
        sta radial_anchor
radial_anchor_valid:
        lda radial_slice
        beq radial_slice_0
        cmp #1
        beq radial_slice_1
        cmp #2
        beq radial_slice_2
radial_slice_3:
        lda #19
        sta radial_row
        lda #6
        sta radial_rows_left
        jmp radial_slice_setup
radial_slice_0:
        lda #0
        sta radial_row
        lda #7
        sta radial_rows_left
        jmp radial_slice_setup
radial_slice_1:
        lda #7
        sta radial_row
        lda #6
        sta radial_rows_left
        jmp radial_slice_setup
radial_slice_2:
        lda #13
        sta radial_row
        lda #6
        sta radial_rows_left
radial_slice_setup:
        ldx radial_anchor
        lda radial_anchor_lo,x
        sta $FA
        lda radial_anchor_hi,x
        sta $FB
        ldx radial_row
        clc
        lda $FA
        adc radial_row_offset_lo,x
        sta $FA
        lda $FB
        adc radial_row_offset_hi,x
        sta $FB
        lda color_lo,x
        sta $FC
        lda color_hi,x
        sta $FD
radial_slice_rows:
        ldy #39
radial_cell_loop:
        lda ($FA),y
        ora radial_lut_base
        tax
        lda radial_phase_lut,x
        clc
        adc radial_phase
        cmp #6
        bcc radial_phase_ok
        sbc #6
radial_phase_ok:
        tax
        lda radial_palette,x
        sta ($FC),y
        dey
        bpl radial_cell_loop
        clc
        lda $FA
        adc #40
        sta $FA
        bcc radial_map_no_carry
        inc $FB
radial_map_no_carry:
        clc
        lda $FC
        adc #40
        sta $FC
        bcc radial_color_no_carry
        inc $FD
radial_color_no_carry:
        dec radial_rows_left
        bne radial_slice_rows
        pla
        tay
        pla
        tax
        pla
    
	rts
end_procedure_AplicarDegradeRadialSlice
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarDegradeRadialCompleto
	;    Procedure type : User-defined procedure
AplicarDegradeRadialCompleto
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_slice
	jsr AplicarDegradeRadialSlice
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_slice
	jsr AplicarDegradeRadialSlice
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_slice
	jsr AplicarDegradeRadialSlice
	lda #$3
	; Calling storevariable on generic assign expression
	sta radial_slice
	jsr AplicarDegradeRadialSlice
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_slice
	; Calling storevariable on generic assign expression
	sta radial_update_active
	rts
end_procedure_AplicarDegradeRadialCompleto
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarDegradeRadial
	;    Procedure type : User-defined procedure
ActualizarDegradeRadial
	; Binary clause Simplified: EQUALS
	lda radial_scroll_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarDegradeRadial_localfailed668
	jmp ActualizarDegradeRadial_ctb351
ActualizarDegradeRadial_localfailed668
	jmp ActualizarDegradeRadial_edblock353
ActualizarDegradeRadial_ctb351: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda radial_scroll_speed
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs ActualizarDegradeRadial_edblock673
ActualizarDegradeRadial_ctb671: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
ActualizarDegradeRadial_edblock673
	; Binary clause Simplified: EQUALS
	lda radial_update_active
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarDegradeRadial_localfailed679
	jmp ActualizarDegradeRadial_ctb676
ActualizarDegradeRadial_localfailed679
	jmp ActualizarDegradeRadial_eblock677
ActualizarDegradeRadial_ctb676: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda scroll_coarse_event
	; cmp #$00 ignored
	bne ActualizarDegradeRadial_localfailed685
	jmp ActualizarDegradeRadial_ctb682
ActualizarDegradeRadial_localfailed685
	jmp ActualizarDegradeRadial_edblock684
ActualizarDegradeRadial_ctb682: ;Main true block ;keep 
	jsr AplicarDegradeRadialSlice
	; Test Inc dec D
	inc radial_slice
	; Binary clause Simplified: GREATEREQUAL
	lda radial_slice
	; Compare with pure num / var optimization
	cmp #$4;keep
	bcc ActualizarDegradeRadial_edblock690
ActualizarDegradeRadial_ctb688: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_slice
	; Calling storevariable on generic assign expression
	sta radial_update_active
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Binary clause Simplified: EQUALS
	lda radial_anchor_motion_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarDegradeRadial_edblock695
ActualizarDegradeRadial_ctb693: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda radial_anchor_motion_period
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs ActualizarDegradeRadial_edblock700
ActualizarDegradeRadial_ctb698: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_period
ActualizarDegradeRadial_edblock700
	; Test Inc dec D
	inc radial_anchor_motion_counter
	; Binary clause Simplified: GREATEREQUAL
	lda radial_anchor_motion_counter
	; Compare with pure num / var optimization
	cmp radial_anchor_motion_period;keep
	bcc ActualizarDegradeRadial_edblock705
ActualizarDegradeRadial_ctb703: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_counter
	; Binary clause Simplified: EQUALS
	clc
	lda radial_anchor_motion_direction
	; cmp #$00 ignored
	bne ActualizarDegradeRadial_eblock709
ActualizarDegradeRadial_ctb708: ;Main true block ;keep 
	; Test Inc dec D
	inc radial_anchor_motion_index
	; Binary clause Simplified: GREATEREQUAL
	lda radial_anchor_motion_index
	; Compare with pure num / var optimization
	cmp #$8;keep
	bcc ActualizarDegradeRadial_edblock715
ActualizarDegradeRadial_ctb713: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_index
ActualizarDegradeRadial_edblock715
	jmp ActualizarDegradeRadial_edblock710
ActualizarDegradeRadial_eblock709
	; Binary clause Simplified: EQUALS
	clc
	lda radial_anchor_motion_index
	; cmp #$00 ignored
	bne ActualizarDegradeRadial_eblock720
ActualizarDegradeRadial_ctb719: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_index
	jmp ActualizarDegradeRadial_edblock721
ActualizarDegradeRadial_eblock720
	; Test Inc dec D
	dec radial_anchor_motion_index
ActualizarDegradeRadial_edblock721
ActualizarDegradeRadial_edblock710
	; Load Byte array
	; CAST type NADA
	ldx radial_anchor_motion_index
	lda radial_anchor_path,x 
	; Calling storevariable on generic assign expression
	sta radial_anchor
ActualizarDegradeRadial_edblock705
ActualizarDegradeRadial_edblock695
ActualizarDegradeRadial_edblock690
ActualizarDegradeRadial_edblock684
	jmp ActualizarDegradeRadial_edblock678
ActualizarDegradeRadial_eblock677
	; Test Inc dec D
	inc radial_scroll_counter
	; Binary clause Simplified: GREATEREQUAL
	lda radial_scroll_counter
	; Compare with pure num / var optimization
	cmp radial_scroll_speed;keep
	bcc ActualizarDegradeRadial_edblock728
ActualizarDegradeRadial_ctb726: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Binary clause Simplified: EQUALS
	clc
	lda radial_direction
	; cmp #$00 ignored
	bne ActualizarDegradeRadial_eblock732
ActualizarDegradeRadial_ctb731: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda radial_phase
	; cmp #$00 ignored
	bne ActualizarDegradeRadial_eblock737
ActualizarDegradeRadial_ctb736: ;Main true block ;keep 
	lda #$5
	; Calling storevariable on generic assign expression
	sta radial_phase
	jmp ActualizarDegradeRadial_edblock738
ActualizarDegradeRadial_eblock737
	; Test Inc dec D
	dec radial_phase
ActualizarDegradeRadial_edblock738
	jmp ActualizarDegradeRadial_edblock733
ActualizarDegradeRadial_eblock732
	; Test Inc dec D
	inc radial_phase
	; Binary clause Simplified: GREATEREQUAL
	lda radial_phase
	; Compare with pure num / var optimization
	cmp #$6;keep
	bcc ActualizarDegradeRadial_edblock745
ActualizarDegradeRadial_ctb743: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
ActualizarDegradeRadial_edblock745
ActualizarDegradeRadial_edblock733
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_slice
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_update_active
ActualizarDegradeRadial_edblock728
ActualizarDegradeRadial_edblock678
ActualizarDegradeRadial_edblock353
	rts
end_procedure_ActualizarDegradeRadial
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarDegradePeriodico
	;    Procedure type : User-defined procedure
AplicarDegradePeriodico
        pha
        txa
        pha
        tya
        pha
        lda cross_row_period
        bne cross_period_ok
        lda #1
        sta cross_row_period
cross_period_ok:
        lda cross_subdivision
        bne cross_sub_not_zero
        lda #1
        sta cross_subdivision
cross_sub_not_zero:
        lda cross_subdivision
        cmp #9
        bcc cross_sub_valid
        lda #8
        sta cross_subdivision
cross_sub_valid:
        lda cross_mirror
        beq cross_mirror_valid
        lda #1
        sta cross_mirror
cross_mirror_valid:
        lda cross_subdivision
        cmp #1
        bne cross_width_2
        lda #10
        jmp cross_width_store
cross_width_2:
        cmp #2
        bne cross_width_3
        lda #8
        jmp cross_width_store
cross_width_3:
        cmp #3
        bne cross_width_4
        lda #6
        jmp cross_width_store
cross_width_4:
        cmp #4
        bne cross_width_5
        lda #5
        jmp cross_width_store
cross_width_5:
        cmp #5
        bne cross_width_6
        lda #4
        jmp cross_width_store
cross_width_6:
        cmp #6
        bne cross_width_7
        lda #3
        jmp cross_width_store
cross_width_7:
        cmp #7
        bne cross_width_8
        lda #2
        jmp cross_width_store
cross_width_8:
        lda #1
cross_width_store:
        sta cross_band_width
        lda #0
        sta cross_phase
        sta cross_repeat
        sta cross_row
cross_row_loop:
        ldx cross_row
        lda color_lo,x
        sta $FC
        lda color_hi,x
        sta $FD
        lda cross_phase
        sta cross_idx
        lda cross_mirror
        bne cross_fill_mirror
        ldy #0
cross_band_next:
        ldx cross_idx
        lda color_degrade,x
        sta cross_current_color
        lda cross_band_width
        sta cross_band_remaining
cross_pixel_loop:
        lda cross_current_color
        sta ($FC),y
        iny
        cpy #40
        beq cross_row_complete
        dec cross_band_remaining
        bne cross_pixel_loop
        lda cross_idx
        clc
        adc #2
        cmp #25
        bcc cross_idx_store
        sbc #25
cross_idx_store:
        sta cross_idx
        jmp cross_band_next
cross_fill_mirror:
        ldy #39
cross_band_next_mirror:
        ldx cross_idx
        lda color_degrade,x
        sta cross_current_color
        lda cross_band_width
        sta cross_band_remaining
cross_pixel_loop_mirror:
        lda cross_current_color
        sta ($FC),y
        dey
        cpy #$FF
        beq cross_row_complete
        dec cross_band_remaining
        bne cross_pixel_loop_mirror
        lda cross_idx
        clc
        adc #2
        cmp #25
        bcc cross_idx_store_mirror
        sbc #25
cross_idx_store_mirror:
        sta cross_idx
        jmp cross_band_next_mirror
cross_row_complete:
        inc cross_repeat
        lda cross_repeat
        cmp cross_row_period
        bcc cross_phase_done
        lda #0
        sta cross_repeat
        lda cross_phase
        clc
        adc #2
        cmp #25
        bcc cross_phase_store
        sbc #25
cross_phase_store:
        sta cross_phase
cross_phase_done:
        inc cross_row
        lda cross_row
        cmp #25
        beq cross_done
        jmp cross_row_loop
cross_done:
        pla
        tay
        pla
        tax
        pla
    
	rts
end_procedure_AplicarDegradePeriodico
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarBlinkGlobal
	;    Procedure type : User-defined procedure
AplicarBlinkGlobal
	; Binary clause Simplified: EQUALS
	lda blink_global_black
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarBlinkGlobal_eblock751
AplicarBlinkGlobal_ctb750: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda blink_global_phase
	; Compare with pure num / var optimization
	cmp #$9;keep
	bcc AplicarBlinkGlobal_edblock771
AplicarBlinkGlobal_ctb769: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta blink_global_phase
AplicarBlinkGlobal_edblock771
	; Load Byte array
	; CAST type NADA
	ldx blink_global_phase
	lda blink_sequence_black,x 
	; Calling storevariable on generic assign expression
	sta col_val
	jmp AplicarBlinkGlobal_edblock752
AplicarBlinkGlobal_eblock751
	; Binary clause Simplified: GREATEREQUAL
	lda blink_global_phase
	; Compare with pure num / var optimization
	cmp #$6;keep
	bcc AplicarBlinkGlobal_edblock777
AplicarBlinkGlobal_ctb775: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta blink_global_phase
AplicarBlinkGlobal_edblock777
	; Load Byte array
	; CAST type NADA
	ldx blink_global_phase
	lda blink_sequence_gray,x 
	; Calling storevariable on generic assign expression
	sta col_val
AplicarBlinkGlobal_edblock752
        pha
        txa
        pha
        lda col_val
        ldx #$00
fill_color_ram:
        sta $D800,x
        sta $D900,x
        sta $DA00,x
        inx
        bne fill_color_ram
        ldx #$00
fill_remaining:
        sta $DB00,x
        inx
        cpx #$E8
        bne fill_remaining
        pla
        tax
        pla
    
	rts
end_procedure_AplicarBlinkGlobal
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarBlinkGlobal
	;    Procedure type : User-defined procedure
ActualizarBlinkGlobal
	; Test Inc dec D
	inc blink_global_counter
	; Binary clause Simplified: GREATEREQUAL
	lda blink_global_counter
	; Compare with pure num / var optimization
	cmp blink_global_speed;keep
	bcc ActualizarBlinkGlobal_edblock783
ActualizarBlinkGlobal_ctb781: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta blink_global_counter
	; Test Inc dec D
	inc blink_global_phase
	; Binary clause Simplified: EQUALS
	lda blink_global_black
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarBlinkGlobal_eblock818
ActualizarBlinkGlobal_ctb817: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda blink_global_phase
	; Compare with pure num / var optimization
	cmp #$9;keep
	bcc ActualizarBlinkGlobal_edblock824
ActualizarBlinkGlobal_ctb822: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta blink_global_phase
ActualizarBlinkGlobal_edblock824
	jmp ActualizarBlinkGlobal_edblock819
ActualizarBlinkGlobal_eblock818
	; Binary clause Simplified: GREATEREQUAL
	lda blink_global_phase
	; Compare with pure num / var optimization
	cmp #$6;keep
	bcc ActualizarBlinkGlobal_edblock830
ActualizarBlinkGlobal_ctb828: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta blink_global_phase
ActualizarBlinkGlobal_edblock830
ActualizarBlinkGlobal_edblock819
	jsr AplicarBlinkGlobal
ActualizarBlinkGlobal_edblock783
	rts
end_procedure_ActualizarBlinkGlobal
	
; // | >>> STAGE 13 :: BLINK CONSTANTE                                             |
; // | El ghost scroll controla solamente la duracion total del Stage 13.          |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarBlinkStage13Constante
	;    Procedure type : User-defined procedure
ActualizarBlinkStage13Constante
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$d;keep
	bne ActualizarBlinkStage13Constante_edblock836
ActualizarBlinkStage13Constante_ctb834: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda stage13_static_active
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarBlinkStage13Constante_edblock848
ActualizarBlinkStage13Constante_ctb846: ;Main true block ;keep 
	
; // Blink constante durante todo Stage 13.
	lda stage13_blink_speed
	; Calling storevariable on generic assign expression
	sta blink_global_speed
ActualizarBlinkStage13Constante_edblock848
ActualizarBlinkStage13Constante_edblock836
	rts
end_procedure_ActualizarBlinkStage13Constante
	
; // | Rotacion de Stages 11/12:                                                    |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarMapaRotatorioBin
	;    Procedure type : User-defined procedure
AplicarMapaRotatorioBin
        pha
        txa
        pha
        tya
        pha
        lda #0
        sta rotating_bin_mirror
        lda rotating_lines_step
        cmp #1
        beq rot_bin_step1
        cmp #2
        beq rot_bin_step2
        cmp #3
        beq rot_bin_step3
        cmp #5
        beq rot_bin_step5
        cmp #6
        beq rot_bin_step6
rot_bin_step7:
        lda #$60            ; frame0, ultima fila: $B460
        sta $FA
        lda #$B4
        sta $FB
        lda #1
        sta rotating_bin_mirror
        jmp rot_bin_source_ready
rot_bin_step6:
        lda #$48            ; frame1, ultima fila: $B848
        sta $FA
        lda #$B8
        sta $FB
        lda #1
        sta rotating_bin_mirror
        jmp rot_bin_source_ready
rot_bin_step5:
        lda #$30            ; frame2, ultima fila: $BC30
        sta $FA
        lda #$BC
        sta $FB
        lda #1
        sta rotating_bin_mirror
        jmp rot_bin_source_ready
rot_bin_step3:
        lda #$70            ; frame2: $B870
        sta $FA
        lda #$B8
        sta $FB
        jmp rot_bin_source_ready
rot_bin_step2:
        lda #$88            ; frame1: $B488
        sta $FA
        lda #$B4
        sta $FB
        jmp rot_bin_source_ready
rot_bin_step1:
        lda #$A0            ; frame0: $B0A0
        sta $FA
        lda #$B0
        sta $FB
rot_bin_source_ready:
        lda rotating_bin_mirror
        bne rot_bin_copy_mirror
        ldy #0
rot_bin_copy_d8:
        lda ($FA),y
        sta $D800,y
        iny
        bne rot_bin_copy_d8
        inc $FB
        ldy #0
rot_bin_copy_d9:
        lda ($FA),y
        sta $D900,y
        iny
        bne rot_bin_copy_d9
        inc $FB
        ldy #0
rot_bin_copy_da:
        lda ($FA),y
        sta $DA00,y
        iny
        bne rot_bin_copy_da
        inc $FB
        ldy #0
rot_bin_copy_db:
        lda ($FA),y
        sta $DB00,y
        iny
        cpy #$E8
        bne rot_bin_copy_db
        jmp rot_bin_done
rot_bin_copy_mirror:
        lda #$00
        sta $FC
        lda #$D8
        sta $FD
        lda #25
        sta rotating_bin_rows_left
rot_bin_mirror_row:
        ldy #0
rot_bin_mirror_cell:
        lda ($FA),y
        sta ($FC),y
        iny
        cpy #40
        bne rot_bin_mirror_cell
        sec
        lda $FA
        sbc #40
        sta $FA
        lda $FB
        sbc #0
        sta $FB
        clc
        lda $FC
        adc #40
        sta $FC
        bcc rot_bin_dest_ok
        inc $FD
rot_bin_dest_ok:
        dec rotating_bin_rows_left
        bne rot_bin_mirror_row
rot_bin_done:
        pla
        tay
        pla
        tax
        pla
    
	rts
end_procedure_AplicarMapaRotatorioBin
	
; // | Se usa SOLO en Stage 13.                                                     |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarMapaRotatorioBinMovido
	;    Procedure type : User-defined procedure
AplicarMapaRotatorioBinMovido
        pha
        txa
        pha
        tya
        pha
        lda #0
        sta rotating_bin_mirror
        lda rotating_lines_step
        cmp #1
        beq rot_move_step1
        cmp #2
        beq rot_move_step2
        cmp #3
        beq rot_move_step3
        cmp #5
        beq rot_move_step5
        cmp #6
        beq rot_move_step6
rot_move_step7:
        lda #$60
        sta $FA
        lda #$B4
        sta $FB
        lda #1
        sta rotating_bin_mirror
        jmp rot_move_source_ready
rot_move_step6:
        lda #$48
        sta $FA
        lda #$B8
        sta $FB
        lda #1
        sta rotating_bin_mirror
        jmp rot_move_source_ready
rot_move_step5:
        lda #$30
        sta $FA
        lda #$BC
        sta $FB
        lda #1
        sta rotating_bin_mirror
        jmp rot_move_source_ready
rot_move_step3:
        lda #$70
        sta $FA
        lda #$B8
        sta $FB
        jmp rot_move_source_ready
rot_move_step2:
        lda #$88
        sta $FA
        lda #$B4
        sta $FB
        jmp rot_move_source_ready
rot_move_step1:
        lda #$A0
        sta $FA
        lda #$B0
        sta $FB
rot_move_source_ready:
        lda #$00
        sta $FC
        lda #$D8
        sta $FD
        lda #25
        sta rotating_bin_rows_left
rot_move_row:
        lda rotating_move_offset
        beq rot_move_row_no_offset
        lda $FC
        sta $F8
        lda $FD
        sta $F9
        sec
        lda $FC
        sbc rotating_move_offset
        sta $FC
        lda $FD
        sbc #0
        sta $FD
        ldy rotating_move_offset
rot_move_chunk_a:
        lda ($FA),y
        sta ($FC),y
        iny
        cpy #40
        bne rot_move_chunk_a
        lda $F8
        sta $FC
        lda $F9
        sta $FD
        lda #40
        sec
        sbc rotating_move_offset
        sta $F7
        clc
        lda $FC
        adc $F7
        sta $FC
        lda $FD
        adc #0
        sta $FD
        ldy #0
rot_move_chunk_b:
        cpy rotating_move_offset
        beq rot_move_chunk_b_done
        lda ($FA),y
        sta ($FC),y
        iny
rot_move_chunk_b_done:
        sec
        lda $FC
        sbc $F7
        sta $FC
        lda $FD
        sbc #0
        sta $FD
        jmp rot_move_row_done
rot_move_row_no_offset:
        ldy #0
rot_move_row_plain:
        lda ($FA),y
        sta ($FC),y
        iny
        cpy #40
        bne rot_move_row_plain
rot_move_row_done:
        lda rotating_bin_mirror
        bne rot_move_source_back
        clc
        lda $FA
        adc #40
        sta $FA
        bcc rot_move_source_done
        inc $FB
        jmp rot_move_source_done
rot_move_source_back:
        sec
        lda $FA
        sbc #40
        sta $FA
        lda $FB
        sbc #0
        sta $FB
rot_move_source_done:
        clc
        lda $FC
        adc #40
        sta $FC
        bcc rot_move_dest_done
        inc $FD
rot_move_dest_done:
        dec rotating_bin_rows_left
        beq rot_move_all_done
        jmp rot_move_row
rot_move_all_done:
        pla
        tay
        pla
        tax
        pla
    
	rts
end_procedure_AplicarMapaRotatorioBinMovido
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarLineasRotatorias
	;    Procedure type : User-defined procedure
AplicarLineasRotatorias
	; Binary clause Simplified: EQUALS
	clc
	lda rotating_lines_step
	; cmp #$00 ignored
	bne AplicarLineasRotatorias_edblock856
AplicarLineasRotatorias_ctb854: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta linear_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta linear_mirror
	jsr AplicarDegradeLineal
AplicarLineasRotatorias_edblock856
	; Binary clause Simplified: EQUALS
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_edblock862
AplicarLineasRotatorias_ctb860: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_eblock875
AplicarLineasRotatorias_ctb874: ;Main true block ;keep 
	
; // Stage 11/12 = centrado. Stage 13 = desplazado.
	jsr AplicarMapaRotatorioBinMovido
	jmp AplicarLineasRotatorias_edblock876
AplicarLineasRotatorias_eblock875
	jsr AplicarMapaRotatorioBin
AplicarLineasRotatorias_edblock876
AplicarLineasRotatorias_edblock862
	; Binary clause Simplified: EQUALS
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$2;keep
	bne AplicarLineasRotatorias_edblock882
AplicarLineasRotatorias_ctb880: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_eblock895
AplicarLineasRotatorias_ctb894: ;Main true block ;keep 
	jsr AplicarMapaRotatorioBinMovido
	jmp AplicarLineasRotatorias_edblock896
AplicarLineasRotatorias_eblock895
	jsr AplicarMapaRotatorioBin
AplicarLineasRotatorias_edblock896
AplicarLineasRotatorias_edblock882
	; Binary clause Simplified: EQUALS
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$3;keep
	bne AplicarLineasRotatorias_edblock902
AplicarLineasRotatorias_ctb900: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_eblock915
AplicarLineasRotatorias_ctb914: ;Main true block ;keep 
	jsr AplicarMapaRotatorioBinMovido
	jmp AplicarLineasRotatorias_edblock916
AplicarLineasRotatorias_eblock915
	jsr AplicarMapaRotatorioBin
AplicarLineasRotatorias_edblock916
AplicarLineasRotatorias_edblock902
	; Binary clause Simplified: EQUALS
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$4;keep
	bne AplicarLineasRotatorias_edblock922
AplicarLineasRotatorias_ctb920: ;Main true block ;keep 
	lda #$3
	; Calling storevariable on generic assign expression
	sta vertical_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_mirror
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_eblock935
AplicarLineasRotatorias_ctb934: ;Main true block ;keep 
	lda rotating_move_offset
	; Calling storevariable on generic assign expression
	sta vertical_scroll_offset
	jmp AplicarLineasRotatorias_edblock936
AplicarLineasRotatorias_eblock935
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_offset
AplicarLineasRotatorias_edblock936
	jsr AplicarDegradeVertical
AplicarLineasRotatorias_edblock922
	; Binary clause Simplified: EQUALS
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$5;keep
	bne AplicarLineasRotatorias_edblock942
AplicarLineasRotatorias_ctb940: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_eblock955
AplicarLineasRotatorias_ctb954: ;Main true block ;keep 
	jsr AplicarMapaRotatorioBinMovido
	jmp AplicarLineasRotatorias_edblock956
AplicarLineasRotatorias_eblock955
	jsr AplicarMapaRotatorioBin
AplicarLineasRotatorias_edblock956
AplicarLineasRotatorias_edblock942
	; Binary clause Simplified: EQUALS
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$6;keep
	bne AplicarLineasRotatorias_edblock962
AplicarLineasRotatorias_ctb960: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_eblock975
AplicarLineasRotatorias_ctb974: ;Main true block ;keep 
	jsr AplicarMapaRotatorioBinMovido
	jmp AplicarLineasRotatorias_edblock976
AplicarLineasRotatorias_eblock975
	jsr AplicarMapaRotatorioBin
AplicarLineasRotatorias_edblock976
AplicarLineasRotatorias_edblock962
	; Binary clause Simplified: EQUALS
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$7;keep
	bne AplicarLineasRotatorias_edblock982
AplicarLineasRotatorias_ctb980: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarLineasRotatorias_eblock995
AplicarLineasRotatorias_ctb994: ;Main true block ;keep 
	jsr AplicarMapaRotatorioBinMovido
	jmp AplicarLineasRotatorias_edblock996
AplicarLineasRotatorias_eblock995
	jsr AplicarMapaRotatorioBin
AplicarLineasRotatorias_edblock996
AplicarLineasRotatorias_edblock982
	rts
end_procedure_AplicarLineasRotatorias
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarLineasRotatorias
	;    Procedure type : User-defined procedure
ActualizarLineasRotatorias
	
; // Motor rotatorio usado solo por Stages 11/12.
	lda rotating_lines_speed
	; Calling storevariable on generic assign expression
	sta rotating_speed_current
	; Binary clause Simplified: LESS
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs ActualizarLineasRotatorias_edblock1003
ActualizarLineasRotatorias_ctb1001: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta rotating_speed_current
ActualizarLineasRotatorias_edblock1003
	; Binary clause Simplified: LESS
	lda rotating_lines_counter
	; Compare with pure num / var optimization
	cmp rotating_speed_current;keep
	bcs ActualizarLineasRotatorias_edblock1009
ActualizarLineasRotatorias_ctb1007: ;Main true block ;keep 
	; Test Inc dec D
	inc rotating_lines_counter
ActualizarLineasRotatorias_edblock1009
	; Binary clause Simplified: GREATEREQUAL
	lda rotating_lines_counter
	; Compare with pure num / var optimization
	cmp rotating_speed_current;keep
	bcc ActualizarLineasRotatorias_localfailed1157
	jmp ActualizarLineasRotatorias_ctb1013
ActualizarLineasRotatorias_localfailed1157
	jmp ActualizarLineasRotatorias_edblock1015
ActualizarLineasRotatorias_ctb1013: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda scroll_coarse_event
	; cmp #$00 ignored
	bne ActualizarLineasRotatorias_localfailed1163
	jmp ActualizarLineasRotatorias_ctb1160
ActualizarLineasRotatorias_localfailed1163
	jmp ActualizarLineasRotatorias_edblock1162
ActualizarLineasRotatorias_ctb1160: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_lines_counter
	; Binary clause Simplified: EQUALS
	clc
	lda rotating_lines_direction
	; cmp #$00 ignored
	bne ActualizarLineasRotatorias_eblock1167
ActualizarLineasRotatorias_ctb1166: ;Main true block ;keep 
	; Test Inc dec D
	inc rotating_lines_step
	; Binary clause Simplified: GREATEREQUAL
	lda rotating_lines_step
	; Compare with pure num / var optimization
	cmp #$8;keep
	bcc ActualizarLineasRotatorias_edblock1173
ActualizarLineasRotatorias_ctb1171: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_lines_step
ActualizarLineasRotatorias_edblock1173
	jmp ActualizarLineasRotatorias_edblock1168
ActualizarLineasRotatorias_eblock1167
	; Binary clause Simplified: EQUALS
	clc
	lda rotating_lines_step
	; cmp #$00 ignored
	bne ActualizarLineasRotatorias_eblock1178
ActualizarLineasRotatorias_ctb1177: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta rotating_lines_step
	jmp ActualizarLineasRotatorias_edblock1179
ActualizarLineasRotatorias_eblock1178
	; Test Inc dec D
	dec rotating_lines_step
ActualizarLineasRotatorias_edblock1179
ActualizarLineasRotatorias_edblock1168
	; Binary clause Simplified: EQUALS
	lda rotating_move_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarLineasRotatorias_edblock1185
ActualizarLineasRotatorias_ctb1183: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda rotating_move_direction
	; cmp #$00 ignored
	bne ActualizarLineasRotatorias_eblock1189
ActualizarLineasRotatorias_ctb1188: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	; 8 bit binop
	; Add/sub where right value is constant number
	lda rotating_move_offset
	clc
	adc rotating_move_step
	 ; end add / sub var with constant
	; Compare with pure num / var optimization
	cmp rotating_move_max;keep
	bcc ActualizarLineasRotatorias_eblock1194
ActualizarLineasRotatorias_ctb1193: ;Main true block ;keep 
	
; // STAGE 13: DERIVA ESPACIAL CON REBOTE.
	lda rotating_move_max
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
	lda #$1
	; Calling storevariable on generic assign expression
	sta rotating_move_direction
	jmp ActualizarLineasRotatorias_edblock1195
ActualizarLineasRotatorias_eblock1194
	; 8 bit binop
	; Add/sub where right value is constant number
	lda rotating_move_offset
	clc
	adc rotating_move_step
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
ActualizarLineasRotatorias_edblock1195
	jmp ActualizarLineasRotatorias_edblock1190
ActualizarLineasRotatorias_eblock1189
	; Binary clause Simplified: LESSEQUAL
	lda rotating_move_offset
	; Compare with pure num / var optimization
	cmp rotating_move_step;keep
	beq ActualizarLineasRotatorias_ctb1200
	bcs ActualizarLineasRotatorias_eblock1201
ActualizarLineasRotatorias_ctb1200: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
	; Calling storevariable on generic assign expression
	sta rotating_move_direction
	jmp ActualizarLineasRotatorias_edblock1202
ActualizarLineasRotatorias_eblock1201
	
; // Stage 13 completo 0 -> max -> 0.
; // el retorno 0->max->0 NO dispara animacion de charset.
	; 8 bit binop
	; Add/sub where right value is constant number
	lda rotating_move_offset
	sec
	sbc rotating_move_step
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
ActualizarLineasRotatorias_edblock1202
ActualizarLineasRotatorias_edblock1190
ActualizarLineasRotatorias_edblock1185
	jsr AplicarLineasRotatorias
ActualizarLineasRotatorias_edblock1162
ActualizarLineasRotatorias_edblock1015
	rts
end_procedure_ActualizarLineasRotatorias
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarHorizontalCompletoBlancoNegro
	;    Procedure type : User-defined procedure
AplicarHorizontalCompletoBlancoNegro
	lda #$0
	; Calling storevariable on generic assign expression
	sta linear_row
AplicarHorizontalCompletoBlancoNegro_while1206
AplicarHorizontalCompletoBlancoNegro_loopstart1210
	; Binary clause Simplified: LESS
	lda linear_row
	; Compare with pure num / var optimization
	cmp #$19;keep
	bcs AplicarHorizontalCompletoBlancoNegro_edblock1209
AplicarHorizontalCompletoBlancoNegro_ctb1207: ;Main true block ;keep 
            ldx linear_row
            lda color_lo,x
            sta $FC
            lda color_hi,x
            sta $FD
            lda horizontal_full_gradient,x
            ldy #39
stage5_full_gradient_row:
            sta ($FC),y
            dey
            bpl stage5_full_gradient_row
        
	; Test Inc dec D
	inc linear_row
	jmp AplicarHorizontalCompletoBlancoNegro_while1206
AplicarHorizontalCompletoBlancoNegro_edblock1209
AplicarHorizontalCompletoBlancoNegro_loopend1211
	rts
end_procedure_AplicarHorizontalCompletoBlancoNegro
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarColorActual
	;    Procedure type : User-defined procedure
AplicarColorActual
	; Binary clause Simplified: EQUALS
	clc
	lda color_mode
	; cmp #$00 ignored
	bne AplicarColorActual_edblock1218
AplicarColorActual_ctb1216: ;Main true block ;keep 
	jsr AplicarDegradeLineal
AplicarColorActual_edblock1218
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarColorActual_edblock1224
AplicarColorActual_ctb1222: ;Main true block ;keep 
	jsr AplicarBlinkGlobal
AplicarColorActual_edblock1224
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$2;keep
	bne AplicarColorActual_edblock1230
AplicarColorActual_ctb1228: ;Main true block ;keep 
            pha
            txa
            pha
            lda flat_color
            ldx #$00
fill_flat:
            sta $D800,x
            sta $D900,x
            sta $DA00,x
            inx
            bne fill_flat
            ldx #$00
fill_flat_rem:
            sta $DB00,x
            inx
            cpx #$E8
            bne fill_flat_rem
            pla
            tax
            pla
        
AplicarColorActual_edblock1230
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$5;keep
	bne AplicarColorActual_edblock1236
AplicarColorActual_ctb1234: ;Main true block ;keep 
	jsr AplicarDegradePeriodico
AplicarColorActual_edblock1236
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$6;keep
	bne AplicarColorActual_edblock1242
AplicarColorActual_ctb1240: ;Main true block ;keep 
	jsr AplicarDegradeVertical
AplicarColorActual_edblock1242
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$7;keep
	bne AplicarColorActual_edblock1248
AplicarColorActual_ctb1246: ;Main true block ;keep 
	jsr AplicarDegradeRadialCompleto
AplicarColorActual_edblock1248
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$8;keep
	bne AplicarColorActual_edblock1254
AplicarColorActual_ctb1252: ;Main true block ;keep 
	jsr AplicarLineasRotatorias
AplicarColorActual_edblock1254
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$9;keep
	bne AplicarColorActual_edblock1260
AplicarColorActual_ctb1258: ;Main true block ;keep 
	jsr AplicarHorizontalCompletoBlancoNegro
AplicarColorActual_edblock1260
	rts
end_procedure_AplicarColorActual
	; NodeProcedureDecl 51
	; ***********  Defining procedure : RenderizarStage13Centro
	;    Procedure type : User-defined procedure
RenderizarStage13Centro
	jsr RenderizarBinarios
	lda #$0
	; Calling storevariable on generic assign expression
	sta map_idx
	lda stage13_center_src_top
	; Calling storevariable on generic assign expression
	sta src_idx
RenderizarStage13Centro_while1264
RenderizarStage13Centro_loopstart1268
	; Binary clause Simplified: LESS
	lda map_idx
	; Compare with pure num / var optimization
	cmp #$19;keep
	bcs RenderizarStage13Centro_edblock1267
RenderizarStage13Centro_ctb1265: ;Main true block ;keep 
            ldx src_idx
            lda src_char_lo,x
            sta $22
            lda src_char_hi,x
            sta $23
            ldx map_idx
            lda screen_lo,x
            sta $24
            lda screen_hi,x
            sta $25
            lda screen_lo,x
            sta $FB
            lda screen_hi_b,x
            sta $FC
            ldy #39
stage13_center_copy_line:
            lda ($22),y
            sta ($24),y
            sta ($FB),y
            dey
            bpl stage13_center_copy_line
        
	; Test Inc dec D
	inc map_idx
	; Test Inc dec D
	inc src_idx
	jmp RenderizarStage13Centro_while1264
RenderizarStage13Centro_edblock1267
RenderizarStage13Centro_loopend1269
	rts
end_procedure_RenderizarStage13Centro
	
; // | >>> STAGE 13 :: SALIDA MANUAL                                               |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : SalirStage13Centro
	;    Procedure type : User-defined procedure
SalirStage13Centro
	lda #$0
	; Calling storevariable on generic assign expression
	sta stage13_static_active
	; Calling storevariable on generic assign expression
	sta anim_active
	jsr RenderizarBinarios
	lda #$0
	; Calling storevariable on generic assign expression
	sta screen_active
	lda #$18
	; Calling storevariable on generic assign expression
	sta screen_d018_real
	lda #$1a
	; Calling storevariable on generic assign expression
	sta screen_d018_mask
	lda screen_d018_real
	; Calling storevariable on generic assign expression
	sta vic_d018
	lda #$2a
	; Calling storevariable on generic assign expression
	sta next_line
	lda #$1
	; Calling storevariable on generic assign expression
	sta direction
	lda #$7
	; Calling storevariable on generic assign expression
	sta fine_scroll
	lda #$17
	; Calling storevariable on generic assign expression
	sta vic_d011
	lda #$0
	; Calling storevariable on generic assign expression
	sta speed_counter
	; Calling storevariable on generic assign expression
	sta scroll_phase
	; Calling storevariable on generic assign expression
	sta scroll_update_now
	; Calling storevariable on generic assign expression
	sta scroll_coarse_event
	jsr PrepararBufferArriba
	lda #$e
	; Calling storevariable on generic assign expression
	sta show_stage
	jsr AplicarStageVisual
	jsr ActualizarAnimacionEnNegro
	rts
end_procedure_SalirStage13Centro
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AplicarStageVisual
	;    Procedure type : User-defined procedure
AplicarStageVisual
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_enabled
	; Calling storevariable on generic assign expression
	sta vertical_scroll_motion
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_enabled
	; Calling storevariable on generic assign expression
	sta rotating_move_enabled
	; Binary clause Simplified: EQUALS
	clc
	lda show_stage
	; cmp #$00 ignored
	bne AplicarStageVisual_edblock1277
AplicarStageVisual_ctb1275: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$1
	; Calling storevariable on generic assign expression
	sta flat_color
AplicarStageVisual_edblock1277
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarStageVisual_edblock1283
AplicarStageVisual_ctb1281: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$f
	; Calling storevariable on generic assign expression
	sta flat_color
AplicarStageVisual_edblock1283
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne AplicarStageVisual_edblock1289
AplicarStageVisual_ctb1287: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$1
	; Calling storevariable on generic assign expression
	sta linear_subdivision
	; Calling storevariable on generic assign expression
	sta linear_mirror
AplicarStageVisual_edblock1289
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$2;keep
	bne AplicarStageVisual_edblock1295
AplicarStageVisual_ctb1293: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$1
	; Calling storevariable on generic assign expression
	sta linear_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta linear_mirror
AplicarStageVisual_edblock1295
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$3;keep
	bne AplicarStageVisual_edblock1301
AplicarStageVisual_ctb1299: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$7
	; Calling storevariable on generic assign expression
	sta linear_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta linear_mirror
AplicarStageVisual_edblock1301
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$4;keep
	bne AplicarStageVisual_edblock1307
AplicarStageVisual_ctb1305: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$7
	; Calling storevariable on generic assign expression
	sta linear_subdivision
	lda #$1
	; Calling storevariable on generic assign expression
	sta linear_mirror
AplicarStageVisual_edblock1307
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$5;keep
	bne AplicarStageVisual_edblock1313
AplicarStageVisual_ctb1311: ;Main true block ;keep 
	lda #$9
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$0
	; Calling storevariable on generic assign expression
	sta stage5_scroll_phase
AplicarStageVisual_edblock1313
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$6;keep
	bne AplicarStageVisual_edblock1319
AplicarStageVisual_ctb1317: ;Main true block ;keep 
	lda #$6
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$4
	; Calling storevariable on generic assign expression
	sta vertical_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_mirror
	lda #$1
	; Calling storevariable on generic assign expression
	sta vertical_scroll_enabled
	lda #$4
	; Calling storevariable on generic assign expression
	sta vertical_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_motion
	; Calling storevariable on generic assign expression
	sta vertical_scroll_offset
	; Calling storevariable on generic assign expression
	sta vertical_scroll_counter
	; Calling storevariable on generic assign expression
	sta vertical_scroll_direction
AplicarStageVisual_edblock1319
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$7;keep
	bne AplicarStageVisual_edblock1325
AplicarStageVisual_ctb1323: ;Main true block ;keep 
	lda #$6
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$4
	; Calling storevariable on generic assign expression
	sta vertical_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_mirror
	lda #$1
	; Calling storevariable on generic assign expression
	sta vertical_scroll_enabled
	lda #$4
	; Calling storevariable on generic assign expression
	sta vertical_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_motion
	; Calling storevariable on generic assign expression
	sta vertical_scroll_offset
	; Calling storevariable on generic assign expression
	sta vertical_scroll_counter
	lda #$1
	; Calling storevariable on generic assign expression
	sta vertical_scroll_direction
AplicarStageVisual_edblock1325
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$8;keep
	bne AplicarStageVisual_edblock1331
AplicarStageVisual_ctb1329: ;Main true block ;keep 
	lda #$5
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$1
	; Calling storevariable on generic assign expression
	sta cross_subdivision
	lda #$4
	; Calling storevariable on generic assign expression
	sta cross_row_period
	lda #$1
	; Calling storevariable on generic assign expression
	sta cross_mirror
AplicarStageVisual_edblock1331
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$9;keep
	bne AplicarStageVisual_edblock1337
AplicarStageVisual_ctb1335: ;Main true block ;keep 
	lda #$5
	; Calling storevariable on generic assign expression
	sta color_mode
	; Calling storevariable on generic assign expression
	sta cross_subdivision
	lda #$2
	; Calling storevariable on generic assign expression
	sta cross_row_period
	lda #$0
	; Calling storevariable on generic assign expression
	sta cross_mirror
AplicarStageVisual_edblock1337
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$a;keep
	bne AplicarStageVisual_edblock1343
AplicarStageVisual_ctb1341: ;Main true block ;keep 
	lda #$5
	; Calling storevariable on generic assign expression
	sta color_mode
	; Calling storevariable on generic assign expression
	sta cross_subdivision
	lda #$2
	; Calling storevariable on generic assign expression
	sta cross_row_period
	lda #$1
	; Calling storevariable on generic assign expression
	sta cross_mirror
AplicarStageVisual_edblock1343
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$b;keep
	bne AplicarStageVisual_edblock1349
AplicarStageVisual_ctb1347: ;Main true block ;keep 
	lda #$8
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_lines_counter
	; Calling storevariable on generic assign expression
	sta rotating_lines_step
	; Calling storevariable on generic assign expression
	sta rotating_scroll_phase
	; Calling storevariable on generic assign expression
	sta rotating_lines_direction
	; Calling storevariable on generic assign expression
	sta rotating_move_enabled
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
AplicarStageVisual_edblock1349
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$c;keep
	bne AplicarStageVisual_edblock1355
AplicarStageVisual_ctb1353: ;Main true block ;keep 
	lda #$8
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_lines_counter
	; Calling storevariable on generic assign expression
	sta rotating_lines_step
	; Calling storevariable on generic assign expression
	sta rotating_scroll_phase
	lda #$1
	; Calling storevariable on generic assign expression
	sta rotating_lines_direction
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_move_enabled
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
AplicarStageVisual_edblock1355
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$d;keep
	bne AplicarStageVisual_edblock1361
AplicarStageVisual_ctb1359: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$0
	; Calling storevariable on generic assign expression
	sta blink_global_counter
	; Calling storevariable on generic assign expression
	sta blink_global_phase
	lda #$1
	; Calling storevariable on generic assign expression
	sta blink_global_black
	lda stage13_blink_speed
	; Calling storevariable on generic assign expression
	sta blink_global_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_lines_counter
	; Calling storevariable on generic assign expression
	sta rotating_lines_step
	; Calling storevariable on generic assign expression
	sta rotating_scroll_phase
	; Calling storevariable on generic assign expression
	sta rotating_move_enabled
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
	lda #$1
	; Calling storevariable on generic assign expression
	sta stage13_static_active
	; Optimizer: a = a +/- b
	; Load16bitvariable : limit_down
	lda limit_down
	clc
	adc #$9
	sta stage13_ghost_next_line
	lda #$5
	; Calling storevariable on generic assign expression
	sta stage13_ghost_fine_scroll
	lda #$0
	; Calling storevariable on generic assign expression
	sta stage13_consumed_update
	
; // Stage 13: posicion simetrica aprobada (fuente 16, VIC fine scroll 3).
	lda #$13
	; Calling storevariable on generic assign expression
	sta vic_d011
	jsr RenderizarStage13Centro
AplicarStageVisual_edblock1361
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$e;keep
	bne AplicarStageVisual_edblock1367
AplicarStageVisual_ctb1365: ;Main true block ;keep 
	
; // - STAGE 14 = PRIMER RADIAL. PETSCII ya puede venir activo desde Stage 13.
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_anchor
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_direction
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
AplicarStageVisual_edblock1367
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$f;keep
	bne AplicarStageVisual_edblock1373
AplicarStageVisual_ctb1371: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$3
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_direction
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
AplicarStageVisual_edblock1373
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$10;keep
	bne AplicarStageVisual_edblock1379
AplicarStageVisual_ctb1377: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$4
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_direction
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
AplicarStageVisual_edblock1379
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$11;keep
	bne AplicarStageVisual_edblock1385
AplicarStageVisual_ctb1383: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$5
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_direction
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
AplicarStageVisual_edblock1385
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$12;keep
	bne AplicarStageVisual_edblock1391
AplicarStageVisual_ctb1389: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$8
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_direction
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
AplicarStageVisual_edblock1391
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$13;keep
	bne AplicarStageVisual_edblock1397
AplicarStageVisual_ctb1395: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$6
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_direction
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
AplicarStageVisual_edblock1397
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$14;keep
	bne AplicarStageVisual_edblock1403
AplicarStageVisual_ctb1401: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_direction
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
AplicarStageVisual_edblock1403
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$15;keep
	bne AplicarStageVisual_edblock1409
AplicarStageVisual_ctb1407: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_direction
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_enabled
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_direction
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_index
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_counter
	; Load Byte array
	; CAST type NADA
	lda radial_anchor_path +$0 ; array with const index optimization 
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
	; Calling storevariable on generic assign expression
	sta radial_slice
AplicarStageVisual_edblock1409
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$16;keep
	bne AplicarStageVisual_edblock1415
AplicarStageVisual_ctb1413: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_direction
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_enabled
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_direction
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_index
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_counter
	; Load Byte array
	; CAST type NADA
	lda radial_anchor_path +$0 ; array with const index optimization 
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
	; Calling storevariable on generic assign expression
	sta radial_slice
AplicarStageVisual_edblock1415
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$17;keep
	bne AplicarStageVisual_edblock1421
AplicarStageVisual_ctb1419: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
	; Calling storevariable on generic assign expression
	sta radial_slice
	; Calling storevariable on generic assign expression
	sta final23_scroll_phase
AplicarStageVisual_edblock1421
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$18;keep
	bne AplicarStageVisual_edblock1427
AplicarStageVisual_ctb1425: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_direction
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
	; Calling storevariable on generic assign expression
	sta final24_scroll_phase
AplicarStageVisual_edblock1427
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$19;keep
	bne AplicarStageVisual_edblock1433
AplicarStageVisual_ctb1431: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_direction
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta final25_scroll_phase
AplicarStageVisual_edblock1433
	jsr AplicarColorActual
	rts
end_procedure_AplicarStageVisual
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AvanzarSecuenciaVisual
	;    Procedure type : User-defined procedure
AvanzarSecuenciaVisual
	; Binary clause Simplified: LESS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$19;keep
	bcs AvanzarSecuenciaVisual_edblock1440
AvanzarSecuenciaVisual_ctb1438: ;Main true block ;keep 
	; Test Inc dec D
	inc show_stage
AvanzarSecuenciaVisual_edblock1440
	jsr AplicarStageVisual
	rts
end_procedure_AvanzarSecuenciaVisual
	; NodeProcedureDecl 51
	; ***********  Defining procedure : RevisarFinalCentrado
	;    Procedure type : User-defined procedure
RevisarFinalCentrado
	; Binary clause Simplified: EQUALS
	lda final_center_hold_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne RevisarFinalCentrado_edblock1447
RevisarFinalCentrado_ctb1445: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda final_center_hold_active
	; cmp #$00 ignored
	bne RevisarFinalCentrado_edblock1564
RevisarFinalCentrado_ctb1562: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$1a;keep
	bne RevisarFinalCentrado_edblock1569
RevisarFinalCentrado_ctb1567: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda scroll_end_armed
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne RevisarFinalCentrado_edblock1574
RevisarFinalCentrado_ctb1572: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda direction
	; Compare with pure num / var optimization
	cmp final_center_direction;keep
	bne RevisarFinalCentrado_edblock1579
RevisarFinalCentrado_ctb1577: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda next_line
	; Compare with pure num / var optimization
	cmp final_center_next_line;keep
	bne RevisarFinalCentrado_edblock1584
RevisarFinalCentrado_ctb1582: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda fine_scroll
	; Compare with pure num / var optimization
	cmp final_center_fine_scroll;keep
	bne RevisarFinalCentrado_edblock1589
RevisarFinalCentrado_ctb1587: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	; Calling storevariable on generic assign expression
	sta vertical_scroll_enabled
	; Calling storevariable on generic assign expression
	sta anim_active
	lda #$1
	; Calling storevariable on generic assign expression
	sta final_center_hold_active
	; Calling storevariable on generic assign expression
	sta demo_finished
RevisarFinalCentrado_edblock1589
RevisarFinalCentrado_edblock1584
RevisarFinalCentrado_edblock1579
RevisarFinalCentrado_edblock1574
RevisarFinalCentrado_edblock1569
RevisarFinalCentrado_edblock1564
RevisarFinalCentrado_edblock1447
	rts
end_procedure_RevisarFinalCentrado
	
; // | >>> PETSCII BASE LIMPIA / BACKUP DE LOS 4 CHARS                            |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : GuardarCharsOriginales
	;    Procedure type : User-defined procedure
GuardarCharsOriginales
        ldx #7
_char_backup_loop:
        lda $2678,x
        sta char_original_207,x
        lda $2680,x
        sta char_original_208,x
        lda $2660,x
        sta char_original_204,x
        lda $27D0,x
        sta char_original_250,x
        dex
        bpl _char_backup_loop
    
	rts
end_procedure_GuardarCharsOriginales
	; NodeProcedureDecl 51
	; ***********  Defining procedure : RestaurarCharsOriginales
	;    Procedure type : User-defined procedure
RestaurarCharsOriginales
        ldx #7
_char_restore_loop:
        lda char_original_207,x
        sta $2678,x
        lda char_original_208,x
        sta $2680,x
        lda char_original_204,x
        sta $2660,x
        lda char_original_250,x
        sta $27D0,x
        dex
        bpl _char_restore_loop
    
	rts
end_procedure_RestaurarCharsOriginales
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ConfigurarAnimacionCombo
	;    Procedure type : User-defined procedure
ConfigurarAnimacionCombo
	lda #$0
	; Calling storevariable on generic assign expression
	sta n_izq
	; Calling storevariable on generic assign expression
	sta n_der
	; Calling storevariable on generic assign expression
	sta n_arriba
	; Calling storevariable on generic assign expression
	sta n_abajo
	; Binary clause Simplified: EQUALS
	clc
	lda anim_combo_stage
	; cmp #$00 ignored
	bne ConfigurarAnimacionCombo_edblock1597
ConfigurarAnimacionCombo_ctb1595: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta n_izq
	; Calling storevariable on generic assign expression
	sta n_der
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_izq+$0
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_izq+$1
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_der+$1
ConfigurarAnimacionCombo_edblock1597
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ConfigurarAnimacionCombo_edblock1603
ConfigurarAnimacionCombo_ctb1601: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta n_der
	lda #$3
	; Calling storevariable on generic assign expression
	sta n_izq
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_izq+$0
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_izq+$1
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_izq+$2
ConfigurarAnimacionCombo_edblock1603
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$2;keep
	bne ConfigurarAnimacionCombo_edblock1609
ConfigurarAnimacionCombo_ctb1607: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta n_der
	; Calling storevariable on generic assign expression
	sta n_izq
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_der+$1
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_izq+$0
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_izq+$1
ConfigurarAnimacionCombo_edblock1609
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$3;keep
	bne ConfigurarAnimacionCombo_edblock1615
ConfigurarAnimacionCombo_ctb1613: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta n_der
	; Calling storevariable on generic assign expression
	sta n_izq
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_der+$1
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_izq+$0
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_izq+$1
ConfigurarAnimacionCombo_edblock1615
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$4;keep
	bne ConfigurarAnimacionCombo_edblock1621
ConfigurarAnimacionCombo_ctb1619: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta n_der
	; Calling storevariable on generic assign expression
	sta n_izq
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_der+$1
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_izq+$0
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_izq+$1
ConfigurarAnimacionCombo_edblock1621
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$5;keep
	bne ConfigurarAnimacionCombo_edblock1627
ConfigurarAnimacionCombo_ctb1625: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta n_der
	lda #$1
	; Calling storevariable on generic assign expression
	sta n_arriba
	; Calling storevariable on generic assign expression
	sta n_abajo
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_der+$1
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_arriba+$0
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_abajo+$0
ConfigurarAnimacionCombo_edblock1627
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$6;keep
	bne ConfigurarAnimacionCombo_edblock1633
ConfigurarAnimacionCombo_ctb1631: ;Main true block ;keep 
	lda #$4
	; Calling storevariable on generic assign expression
	sta n_abajo
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_abajo+$0
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_abajo+$1
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_abajo+$2
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_abajo+$3
ConfigurarAnimacionCombo_edblock1633
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$7;keep
	bne ConfigurarAnimacionCombo_edblock1639
ConfigurarAnimacionCombo_ctb1637: ;Main true block ;keep 
	lda #$4
	; Calling storevariable on generic assign expression
	sta n_arriba
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_arriba+$0
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_arriba+$1
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_arriba+$2
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_arriba+$3
ConfigurarAnimacionCombo_edblock1639
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$8;keep
	bne ConfigurarAnimacionCombo_edblock1645
ConfigurarAnimacionCombo_ctb1643: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta n_der
	lda #$1
	; Calling storevariable on generic assign expression
	sta n_arriba
	; Calling storevariable on generic assign expression
	sta n_abajo
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_der+$1
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_abajo+$0
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_arriba+$0
ConfigurarAnimacionCombo_edblock1645
	; Binary clause Simplified: EQUALS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$9;keep
	bne ConfigurarAnimacionCombo_edblock1651
ConfigurarAnimacionCombo_ctb1649: ;Main true block ;keep 
	lda #$4
	; Calling storevariable on generic assign expression
	sta n_izq
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_izq+$0
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_izq+$1
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_izq+$2
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_izq+$3
ConfigurarAnimacionCombo_edblock1651
	rts
end_procedure_ConfigurarAnimacionCombo
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarAnimacionEnNegro
	;    Procedure type : User-defined procedure
ActualizarAnimacionEnNegro
	; Binary clause Simplified: EQUALS
	clc
	lda anim_sequence_started
	; cmp #$00 ignored
	bne ActualizarAnimacionEnNegro_localfailed1726
	jmp ActualizarAnimacionEnNegro_ctb1656
ActualizarAnimacionEnNegro_localfailed1726
	jmp ActualizarAnimacionEnNegro_eblock1657
ActualizarAnimacionEnNegro_ctb1656: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda anim_start_pending
	; cmp #$00 ignored
	bne ActualizarAnimacionEnNegro_edblock1731
ActualizarAnimacionEnNegro_ctb1729: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda show_stage
	; Compare with pure num / var optimization
	cmp anim_start_show_stage;keep
	bcc ActualizarAnimacionEnNegro_edblock1736
ActualizarAnimacionEnNegro_ctb1734: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta anim_start_pending
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_start_delay_counter
ActualizarAnimacionEnNegro_edblock1736
ActualizarAnimacionEnNegro_edblock1731
	jmp ActualizarAnimacionEnNegro_edblock1658
ActualizarAnimacionEnNegro_eblock1657
	; Binary clause Simplified: EQUALS
	lda anim_active
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarAnimacionEnNegro_edblock1742
ActualizarAnimacionEnNegro_ctb1740: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda anim_combo_black_period
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs ActualizarAnimacionEnNegro_edblock1747
ActualizarAnimacionEnNegro_ctb1745: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta anim_combo_black_period
ActualizarAnimacionEnNegro_edblock1747
	; Test Inc dec D
	inc anim_combo_period_counter
	; Binary clause Simplified: GREATEREQUAL
	lda anim_combo_period_counter
	; Compare with pure num / var optimization
	cmp anim_combo_black_period;keep
	bcc ActualizarAnimacionEnNegro_edblock1752
ActualizarAnimacionEnNegro_ctb1750: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_combo_period_counter
	; Binary clause Simplified: LESS
	lda anim_combo_stage
	; Compare with pure num / var optimization
	cmp #$9;keep
	bcs ActualizarAnimacionEnNegro_eblock1756
ActualizarAnimacionEnNegro_ctb1755: ;Main true block ;keep 
	jsr RestaurarCharsOriginales
	; Test Inc dec D
	inc anim_combo_stage
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_counter
	jsr ConfigurarAnimacionCombo
	jmp ActualizarAnimacionEnNegro_edblock1757
ActualizarAnimacionEnNegro_eblock1756
	jsr RestaurarCharsOriginales
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_active
	; Calling storevariable on generic assign expression
	sta anim_counter
	; Calling storevariable on generic assign expression
	sta n_izq
	; Calling storevariable on generic assign expression
	sta n_der
	; Calling storevariable on generic assign expression
	sta n_arriba
	; Calling storevariable on generic assign expression
	sta n_abajo
ActualizarAnimacionEnNegro_edblock1757
ActualizarAnimacionEnNegro_edblock1752
ActualizarAnimacionEnNegro_edblock1742
ActualizarAnimacionEnNegro_edblock1658
	rts
end_procedure_ActualizarAnimacionEnNegro
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarInicioAnimacionPETSCII
	;    Procedure type : User-defined procedure
ActualizarInicioAnimacionPETSCII
	; Binary clause Simplified: EQUALS
	clc
	lda anim_sequence_started
	; cmp #$00 ignored
	bne ActualizarInicioAnimacionPETSCII_edblock1764
ActualizarInicioAnimacionPETSCII_ctb1762: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda anim_start_pending
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ActualizarInicioAnimacionPETSCII_edblock1806
ActualizarInicioAnimacionPETSCII_ctb1804: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda anim_start_delay_frames
	; cmp #$00 ignored
	bne ActualizarInicioAnimacionPETSCII_eblock1810
ActualizarInicioAnimacionPETSCII_ctb1809: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta anim_sequence_started
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_start_pending
	; Calling storevariable on generic assign expression
	sta anim_combo_stage
	; Calling storevariable on generic assign expression
	sta anim_combo_period_counter
	; Calling storevariable on generic assign expression
	sta anim_counter
	jsr GuardarCharsOriginales
	jsr RestaurarCharsOriginales
	jsr ConfigurarAnimacionCombo
	lda #$1
	; Calling storevariable on generic assign expression
	sta anim_active
	jmp ActualizarInicioAnimacionPETSCII_edblock1811
ActualizarInicioAnimacionPETSCII_eblock1810
	; Test Inc dec D
	inc anim_start_delay_counter
	; Binary clause Simplified: GREATEREQUAL
	lda anim_start_delay_counter
	; Compare with pure num / var optimization
	cmp anim_start_delay_frames;keep
	bcc ActualizarInicioAnimacionPETSCII_edblock1817
ActualizarInicioAnimacionPETSCII_ctb1815: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta anim_sequence_started
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_start_pending
	; Calling storevariable on generic assign expression
	sta anim_start_delay_counter
	; Calling storevariable on generic assign expression
	sta anim_combo_stage
	; Calling storevariable on generic assign expression
	sta anim_combo_period_counter
	; Calling storevariable on generic assign expression
	sta anim_counter
	jsr GuardarCharsOriginales
	jsr RestaurarCharsOriginales
	jsr ConfigurarAnimacionCombo
	lda #$1
	; Calling storevariable on generic assign expression
	sta anim_active
ActualizarInicioAnimacionPETSCII_edblock1817
ActualizarInicioAnimacionPETSCII_edblock1811
ActualizarInicioAnimacionPETSCII_edblock1806
ActualizarInicioAnimacionPETSCII_edblock1764
	rts
end_procedure_ActualizarInicioAnimacionPETSCII
	; NodeProcedureDecl 51
	; ***********  Defining procedure : EventoPantallaNegra
	;    Procedure type : User-defined procedure
EventoPantallaNegra
	jsr AvanzarSecuenciaVisual
	jsr ActualizarAnimacionEnNegro
	rts
end_procedure_EventoPantallaNegra
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AnimarCaracterIndependiente
	;    Procedure type : User-defined procedure
AnimarCaracterIndependiente
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_i
AnimarCaracterIndependiente_while1821
AnimarCaracterIndependiente_loopstart1825
	; Binary clause Simplified: LESS
	lda anim_i
	; Compare with pure num / var optimization
	cmp n_izq;keep
	bcs AnimarCaracterIndependiente_edblock1824
AnimarCaracterIndependiente_ctb1822: ;Main true block ;keep 
	; Load Byte array
	; CAST type NADA
	ldx anim_i
	lda chars_izq,x 
	; Calling storevariable on generic assign expression
	sta anim_idx
            sta $22
            lda #0
            sta $23
            asl $22
            rol $23
            asl $22
            rol $23
            asl $22
            rol $23
            clc
            lda $23
            adc #$20
            sta $23
            ldy #0
_char_izq_loop:
            lda ($22),y
            asl
            bcc _char_izq_store
            ora #$01
_char_izq_store:
            sta ($22),y
            iny
            cpy #8
            bne _char_izq_loop
        
	; Test Inc dec D
	inc anim_i
	jmp AnimarCaracterIndependiente_while1821
AnimarCaracterIndependiente_edblock1824
AnimarCaracterIndependiente_loopend1826
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_i
AnimarCaracterIndependiente_while1829
AnimarCaracterIndependiente_loopstart1833
	; Binary clause Simplified: LESS
	lda anim_i
	; Compare with pure num / var optimization
	cmp n_der;keep
	bcs AnimarCaracterIndependiente_edblock1832
AnimarCaracterIndependiente_ctb1830: ;Main true block ;keep 
	; Load Byte array
	; CAST type NADA
	ldx anim_i
	lda chars_der,x 
	; Calling storevariable on generic assign expression
	sta anim_idx
            sta $22
            lda #0
            sta $23
            asl $22
            rol $23
            asl $22
            rol $23
            asl $22
            rol $23
            clc
            lda $23
            adc #$20
            sta $23
            ldy #0
_char_der_loop:
            lda ($22),y
            lsr
            bcc _char_der_store
            ora #$80
_char_der_store:
            sta ($22),y
            iny
            cpy #8
            bne _char_der_loop
        
	; Test Inc dec D
	inc anim_i
	jmp AnimarCaracterIndependiente_while1829
AnimarCaracterIndependiente_edblock1832
AnimarCaracterIndependiente_loopend1834
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_i
AnimarCaracterIndependiente_while1837
AnimarCaracterIndependiente_loopstart1841
	; Binary clause Simplified: LESS
	lda anim_i
	; Compare with pure num / var optimization
	cmp n_arriba;keep
	bcs AnimarCaracterIndependiente_edblock1840
AnimarCaracterIndependiente_ctb1838: ;Main true block ;keep 
	; Load Byte array
	; CAST type NADA
	ldx anim_i
	lda chars_arriba,x 
	; Calling storevariable on generic assign expression
	sta anim_idx
            sta $22
            lda #0
            sta $23
            asl $22
            rol $23
            asl $22
            rol $23
            asl $22
            rol $23
            clc
            lda $23
            adc #$20
            sta $23
            ldy #0
            lda ($22),y
            pha
            ldy #1
_char_arriba_loop:
            lda ($22),y
            dey
            sta ($22),y
            iny
            iny
            cpy #8
            bne _char_arriba_loop
            ldy #7
            pla
            sta ($22),y
        
	; Test Inc dec D
	inc anim_i
	jmp AnimarCaracterIndependiente_while1837
AnimarCaracterIndependiente_edblock1840
AnimarCaracterIndependiente_loopend1842
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_i
AnimarCaracterIndependiente_while1845
AnimarCaracterIndependiente_loopstart1849
	; Binary clause Simplified: LESS
	lda anim_i
	; Compare with pure num / var optimization
	cmp n_abajo;keep
	bcs AnimarCaracterIndependiente_edblock1848
AnimarCaracterIndependiente_ctb1846: ;Main true block ;keep 
	; Load Byte array
	; CAST type NADA
	ldx anim_i
	lda chars_abajo,x 
	; Calling storevariable on generic assign expression
	sta anim_idx
            sta $22
            lda #0
            sta $23
            asl $22
            rol $23
            asl $22
            rol $23
            asl $22
            rol $23
            clc
            lda $23
            adc #$20
            sta $23
            ldy #7
            lda ($22),y
            pha
            ldy #6
_char_abajo_loop:
            lda ($22),y
            iny
            sta ($22),y
            dey
            dey
            bpl _char_abajo_loop
            ldy #0
            pla
            sta ($22),y
        
	; Test Inc dec D
	inc anim_i
	jmp AnimarCaracterIndependiente_while1845
AnimarCaracterIndependiente_edblock1848
AnimarCaracterIndependiente_loopend1850
	rts
end_procedure_AnimarCaracterIndependiente
	; NodeProcedureDecl 51
	; ***********  Defining procedure : InicializarMascaraSuperior
	;    Procedure type : User-defined procedure
InicializarMascaraSuperior
        lda #$00
        ldx #$00
top_mask_charset_loop:
        sta $2800,x
        sta $2900,x
        sta $2A00,x
        sta $2B00,x
        sta $2C00,x
        sta $2D00,x
        sta $2E00,x
        sta $2F00,x
        inx
        bne top_mask_charset_loop
    
	rts
end_procedure_InicializarMascaraSuperior
	; NodeProcedureDecl 51
	; ***********  Defining procedure : RenderizarBinarios
	;    Procedure type : User-defined procedure
RenderizarBinarios
	lda #$0
	; Calling storevariable on generic assign expression
	sta vic_sprites
        ldx #0
loop_limpiar_a:
        lda screen_lo,x
        sta $FB
        lda screen_hi,x
        sta $FC
        ldy #39
loop_espacios_a:
        lda #$20
        sta ($FB),y
        dey
        bpl loop_espacios_a
        inx
        cpx #25
        bne loop_limpiar_a
        lda #$20
        ldx #$00
clear_screen_b_pages:
        sta $3000,x
        sta $3100,x
        sta $3200,x
        inx
        bne clear_screen_b_pages
        ldx #$00
clear_screen_b_tail:
        sta $3300,x
        inx
        cpx #$E8
        bne clear_screen_b_tail
    
	jsr AplicarColorActual
	rts
end_procedure_RenderizarBinarios
	; NodeProcedureDecl 51
	; ***********  Defining procedure : CambiarBufferPantalla
	;    Procedure type : User-defined procedure
CambiarBufferPantalla
        lda screen_active
        beq switch_screen_to_b
        lda #$00
        sta screen_active
        lda #$18
        sta screen_d018_real
        lda #$1A
        sta screen_d018_mask
        jmp switch_screen_apply
switch_screen_to_b:
        lda #$01
        sta screen_active
        lda #$C8
        sta screen_d018_real
        lda #$CA
        sta screen_d018_mask
switch_screen_apply:
        lda screen_d018_real
        ; NTSC: preserve the masked top row during a buffer change.
        ; Same three-byte instruction footprint as the original STA.
        jsr $8B70
    
	rts
end_procedure_CambiarBufferPantalla
	; NodeProcedureDecl 51
	; ***********  Defining procedure : PrepararBufferArriba
	;    Procedure type : User-defined procedure
PrepararBufferArriba
	lda #$ff
	; Calling storevariable on generic assign expression
	sta src_idx
	lda next_line
	; Calling storevariable on generic assign expression
	sta map_idx
	; Binary clause Simplified: GREATEREQUAL
	; Compare with pure num / var optimization
	cmp #$1e;keep
	bcc PrepararBufferArriba_edblock1860
PrepararBufferArriba_ctb1858: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda map_idx
	; Compare with pure num / var optimization
	cmp #$5a;keep
	bcs PrepararBufferArriba_edblock1872
PrepararBufferArriba_ctb1870: ;Main true block ;keep 
	; Optimizer: a = a +/- b
	; Load16bitvariable : map_idx
	lda map_idx
	sec
	sbc #$1e
	sta src_idx
PrepararBufferArriba_edblock1872
PrepararBufferArriba_edblock1860
        lda screen_active
        beq prep_up_a_to_b
        jmp prep_up_b_to_a
prep_up_a_to_b:
        ldy #$00
prep_up_ab_0:
        lda $0428,y
        sta $3000,y
        iny
        bne prep_up_ab_0
        ldy #$00
prep_up_ab_1:
        lda $0528,y
        sta $3100,y
        iny
        bne prep_up_ab_1
        ldy #$00
prep_up_ab_2:
        lda $0628,y
        sta $3200,y
        iny
        bne prep_up_ab_2
        ldy #$00
prep_up_ab_3:
        lda $0728,y
        sta $3300,y
        iny
        cpy #192
        bne prep_up_ab_3
        lda #$C0
        sta $FB
        lda #$33
        sta $FC
        jmp prep_up_copy_done
prep_up_b_to_a:
        ldy #$00
prep_up_ba_0:
        lda $3028,y
        sta $0400,y
        iny
        bne prep_up_ba_0
        ldy #$00
prep_up_ba_1:
        lda $3128,y
        sta $0500,y
        iny
        bne prep_up_ba_1
        ldy #$00
prep_up_ba_2:
        lda $3228,y
        sta $0600,y
        iny
        bne prep_up_ba_2
        ldy #$00
prep_up_ba_3:
        lda $3328,y
        sta $0700,y
        iny
        cpy #192
        bne prep_up_ba_3
        lda #$C0
        sta $FB
        lda #$07
        sta $FC
prep_up_copy_done:
    
	; Binary clause Simplified: LESS
	lda src_idx
	; Compare with pure num / var optimization
	cmp #$3c;keep
	bcs PrepararBufferArriba_eblock1876
PrepararBufferArriba_ctb1875: ;Main true block ;keep 
            ldx src_idx
            lda src_char_lo,x
            sta $22
            lda src_char_hi,x
            sta $23
            ldy #39
prep_up_inject_real:
            lda ($22),y
            sta ($FB),y
            dey
            bpl prep_up_inject_real
        
	jmp PrepararBufferArriba_edblock1877
PrepararBufferArriba_eblock1876
            lda #$20
            ldy #39
prep_up_inject_space:
            sta ($FB),y
            dey
            bpl prep_up_inject_space
        
PrepararBufferArriba_edblock1877
	rts
end_procedure_PrepararBufferArriba
	; NodeProcedureDecl 51
	; ***********  Defining procedure : PrepararBufferAbajo
	;    Procedure type : User-defined procedure
PrepararBufferAbajo
	lda next_line
	; Calling storevariable on generic assign expression
	sta map_idx
	; Optimization: replacing a > N with a >= N+1
	; Binary clause Simplified: GREATEREQUAL
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcc PrepararBufferAbajo_edblock1886
PrepararBufferAbajo_ctb1884: ;Main true block ;keep 
	; Test Inc dec D
	dec map_idx
PrepararBufferAbajo_edblock1886
	lda #$ff
	; Calling storevariable on generic assign expression
	sta src_idx
	; Binary clause Simplified: GREATEREQUAL
	lda map_idx
	; Compare with pure num / var optimization
	cmp #$19;keep
	bcc PrepararBufferAbajo_edblock1892
PrepararBufferAbajo_ctb1890: ;Main true block ;keep 
	; Optimizer: a = a +/- b
	; Load16bitvariable : map_idx
	lda map_idx
	sec
	sbc #$19
	sta map_idx
	; Binary clause Simplified: GREATEREQUAL
	; Compare with pure num / var optimization
	cmp #$1e;keep
	bcc PrepararBufferAbajo_edblock1915
PrepararBufferAbajo_ctb1913: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda map_idx
	; Compare with pure num / var optimization
	cmp #$5a;keep
	bcs PrepararBufferAbajo_edblock1920
PrepararBufferAbajo_ctb1918: ;Main true block ;keep 
	; Optimizer: a = a +/- b
	; Load16bitvariable : map_idx
	lda map_idx
	sec
	sbc #$1e
	sta src_idx
PrepararBufferAbajo_edblock1920
PrepararBufferAbajo_edblock1915
PrepararBufferAbajo_edblock1892
        lda screen_active
        beq prep_down_a_to_b
        jmp prep_down_b_to_a
prep_down_a_to_b:
        ldy #$00
prep_down_ab_0:
        lda $0400,y
        sta $3028,y
        iny
        bne prep_down_ab_0
        ldy #$00
prep_down_ab_1:
        lda $0500,y
        sta $3128,y
        iny
        bne prep_down_ab_1
        ldy #$00
prep_down_ab_2:
        lda $0600,y
        sta $3228,y
        iny
        bne prep_down_ab_2
        ldy #$00
prep_down_ab_3:
        lda $0700,y
        sta $3328,y
        iny
        cpy #192
        bne prep_down_ab_3
        lda #$00
        sta $FB
        lda #$30
        sta $FC
        jmp prep_down_copy_done
prep_down_b_to_a:
        ldy #$00
prep_down_ba_0:
        lda $3000,y
        sta $0428,y
        iny
        bne prep_down_ba_0
        ldy #$00
prep_down_ba_1:
        lda $3100,y
        sta $0528,y
        iny
        bne prep_down_ba_1
        ldy #$00
prep_down_ba_2:
        lda $3200,y
        sta $0628,y
        iny
        bne prep_down_ba_2
        ldy #$00
prep_down_ba_3:
        lda $3300,y
        sta $0728,y
        iny
        cpy #192
        bne prep_down_ba_3
        lda #$00
        sta $FB
        lda #$04
        sta $FC
prep_down_copy_done:
    
	; Binary clause Simplified: LESS
	lda src_idx
	; Compare with pure num / var optimization
	cmp #$3c;keep
	bcs PrepararBufferAbajo_eblock1924
PrepararBufferAbajo_ctb1923: ;Main true block ;keep 
            ldx src_idx
            lda src_char_lo,x
            sta $22
            lda src_char_hi,x
            sta $23
            ldy #39
prep_down_inject_real:
            lda ($22),y
            sta ($FB),y
            dey
            bpl prep_down_inject_real
        
	jmp PrepararBufferAbajo_edblock1925
PrepararBufferAbajo_eblock1924
            lda #$20
            ldy #39
prep_down_inject_space:
            sta ($FB),y
            dey
            bpl prep_down_inject_space
        
PrepararBufferAbajo_edblock1925
	rts
end_procedure_PrepararBufferAbajo
	; NodeProcedureDecl 51
	; ***********  Defining procedure : DesplazarArriba
	;    Procedure type : User-defined procedure
DesplazarArriba
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_coarse_event
	; Binary clause Simplified: EQUALS
	lda next_line
	; Compare with pure num / var optimization
	cmp #$1e;keep
	bne DesplazarArriba_edblock1934
DesplazarArriba_ctb1932: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda sid_start_on_first_content
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne DesplazarArriba_edblock1957
DesplazarArriba_ctb1955: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda sid_first_content_triggered
	; cmp #$00 ignored
	bne DesplazarArriba_edblock1962
DesplazarArriba_ctb1960: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta sid_first_content_triggered
	lda sid_ramp_enabled
	; Calling storevariable on generic assign expression
	sta sid_ramp_active
	lda #$0
	; Calling storevariable on generic assign expression
	sta sid_ramp_frame_counter
	; Calling storevariable on generic assign expression
	sta sid_ramp_block_counter
DesplazarArriba_edblock1962
DesplazarArriba_edblock1957
DesplazarArriba_edblock1934
	jsr CambiarBufferPantalla
	; Test Inc dec D
	inc next_line
	jsr PrepararBufferArriba
	rts
end_procedure_DesplazarArriba
	; NodeProcedureDecl 51
	; ***********  Defining procedure : DesplazarAbajo
	;    Procedure type : User-defined procedure
DesplazarAbajo
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_coarse_event
	jsr CambiarBufferPantalla
	; Optimization: replacing a > N with a >= N+1
	; Binary clause Simplified: GREATEREQUAL
	lda next_line
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcc DesplazarAbajo_edblock1968
DesplazarAbajo_ctb1966: ;Main true block ;keep 
	; Test Inc dec D
	dec next_line
DesplazarAbajo_edblock1968
	jsr PrepararBufferAbajo
	rts
end_procedure_DesplazarAbajo
	; NodeProcedureDecl 51
	; ***********  Defining procedure : SidRasterIRQ
	;    Procedure type : User-defined procedure
SidRasterIRQ
	; StartIRQ
	pha
	txa
	pha
	tya
	pha
	asl $d019
        lda top_mask_enabled
        beq sid_irq_mask_disabled
        lda top_mask_phase
        beq sid_irq_mask_begin
        lda fine_scroll
        and #$07
        cmp #$04
        beq top_mask_restore_charset
        nop
        nop
        nop
        nop
        nop
top_mask_restore_charset:
        lda screen_d018_real
        sta $D018
        lda #$00
        sta top_mask_phase
        sta $D012
        jmp sid_irq_done
sid_irq_mask_begin:
        lda screen_d018_mask
        sta $D018
        lda #$01
        sta top_mask_phase
        lda top_mask_restore_raster
        sec
        sbc #$01
        ; PRUEBA NTSC: fijar fin de la primera fila al raster 63.
        ; Los PAL conservan exactamente el raster 60 original.
        jsr $8BA0
        jmp sid_irq_music_entry
sid_irq_mask_disabled:
        lda screen_d018_real
        sta $D018
        lda #$00
        sta top_mask_phase
        sta $D012
sid_irq_music_entry:
        ; ------------------------------------------------------------
        ; FIX14 - RELOJ LOGICO COMUN PAL / NTSC / DREAN PAL-N
        ;
        ; detected_machine:
        ; 1 = NTSC OLD 262x64  -> 37 ticks cada 45 frames
        ; 2 = NTSC NEW 263x65  -> 31 ticks cada 37 frames
        ; 3 = PAL-B            -> tick cada frame
        ; 4 = DREAN PAL-N      -> tick cada frame
        ;
        ; IMPORTANTE: solo regulamos CUANDO se llama al player.
        ; NO tocamos frecuencias SID, por lo que cada maquina mantiene
        ; su afinacion natural.
        ; ------------------------------------------------------------
        lda detected_machine
        cmp #1
        beq sid_logic_ntsc_old
        cmp #2
        beq sid_logic_ntsc_new
sid_logic_pal_family:
        lda #1
        sta demo_logic_tick
        jmp sid_logic_tick_ready
sid_logic_ntsc_old:
        lda demo_tick_accum
        clc
        adc #37
        cmp #45
        bcc sid_logic_skip_frame
        sbc #45
        sta demo_tick_accum
        ; FIX18: acumular tick visual sin frenar SID.
        lda demo_logic_tick
        cmp #$FF
        beq sid_logic_ntsc_old_tick_queued
        inc demo_logic_tick
sid_logic_ntsc_old_tick_queued:
        jmp sid_logic_tick_ready
sid_logic_ntsc_new:
        lda demo_tick_accum
        clc
        adc #31
        cmp #37
        bcc sid_logic_skip_frame
        sbc #37
        sta demo_tick_accum
        ; FIX18: acumular tick visual sin frenar SID.
        lda demo_logic_tick
        cmp #$FF
        beq sid_logic_ntsc_new_tick_queued
        inc demo_logic_tick
sid_logic_ntsc_new_tick_queued:
        jmp sid_logic_tick_ready
sid_logic_skip_frame:
        sta demo_tick_accum
        ; FIX18: NO borrar demo_logic_tick. Puede haber trabajo visual pendiente.
        jmp sid_irq_done
sid_logic_tick_ready:
        lda sid_end_state
        beq sid_irq_normal_mode
        cmp #1
        beq sid_irq_tail_mode
        jmp sid_irq_done
sid_irq_tail_mode:
        inc sid_tail_counter
        lda sid_tail_counter
        cmp sid_tail_frames
        bcs sid_irq_tail_finish
        jmp sid_irq_done
sid_irq_tail_finish:
        lda $D418
        and #$F0
        sta $D418
        lda #$00
        sta $D404
        sta $D40B
        sta $D412
        lda #2
        sta sid_end_state
        jmp sid_irq_done
sid_irq_normal_mode:
        lda sid_ramp_active
        beq sid_ramp_finished
        inc sid_ramp_frame_counter
        lda sid_ramp_frame_counter
        cmp #8
        bcc sid_ramp_finished
        lda #$00
        sta sid_ramp_frame_counter
        lda sid_gradient
        bne sid_gradient_not_zero
        lda #1
sid_gradient_not_zero:
        cmp #11
        bcc sid_gradient_valid
        lda #10
sid_gradient_valid:
        tax
        dex
        lda sid_gradient_table,x
        sta sid_gradient_blocks
        inc sid_ramp_block_counter
        lda sid_ramp_block_counter
        cmp sid_gradient_blocks
        bcc sid_ramp_finished
        lda #$00
        sta sid_ramp_block_counter
        lda sid_rate
        cmp sid_ramp_target_rate
        beq sid_ramp_finished
        bcc sid_ramp_up
sid_ramp_down:
        sec
        sbc #1
        sta sid_rate
        jmp sid_ramp_finished
sid_ramp_up:
        clc
        adc #1
        sta sid_rate
sid_ramp_finished:
        lda scroll_sid_link
        bne sid_scroll_link_active
        jmp sid_scroll_manual
sid_scroll_link_active:
        lda sid_rate
        cmp scroll_rate_fast
        bcc sid_scroll_not_fast
        jmp sid_scroll_fast
sid_scroll_not_fast:
        cmp scroll_rate_mid2
        bcs sid_scroll_smooth_transition
        cmp scroll_rate_mid1
        bcs sid_scroll_mid1
sid_scroll_slow:
        lda scroll_speed_slow
        sta scroll_speed
        lda #128
        sta scroll_phase_step
        lda #0
        sta scroll_fullspeed
        sta scroll_turbo_base_extra
        sta scroll_turbo_frac_step
        jmp sid_scroll_finished
sid_scroll_mid1:
        lda scroll_speed_mid1
        sta scroll_speed
        lda #128
        sta scroll_phase_step
        lda #0
        sta scroll_fullspeed
        sta scroll_turbo_base_extra
        sta scroll_turbo_frac_step
        jmp sid_scroll_finished
sid_scroll_smooth_transition:
        lda scroll_speed_mid2
        sta scroll_speed
        lda sid_rate
        sec
        sbc scroll_rate_mid2
        cmp #10
        bcc sid_scroll_smooth_index_ok
        lda #9
sid_scroll_smooth_index_ok:
        tax
        lda scroll_smooth_table,x
        sta scroll_phase_step
        lda #0
        sta scroll_fullspeed
        sta scroll_turbo_base_extra
        sta scroll_turbo_frac_step
        jmp sid_scroll_finished
sid_scroll_fast:
        lda scroll_speed_fast
        sta scroll_speed
        lda #1
        sta scroll_fullspeed
        lda #0
        sta scroll_turbo_base_extra
        sta scroll_turbo_frac_step
        lda scroll_turbo_enabled
        beq sid_scroll_finished
        lda scroll_turbo_active
        beq sid_scroll_finished
        lda scroll_turbo_stage
        cmp #11
        bcc sid_scroll_turbo_stage_ok
        lda #10
sid_scroll_turbo_stage_ok:
        tax
        lda scroll_turbo_base_table,x
        sta scroll_turbo_base_extra
        lda scroll_turbo_frac_table,x
        sta scroll_turbo_frac_step
        jmp sid_scroll_finished
sid_scroll_manual:
        lda scroll_speed_manual
        sta scroll_speed
        lda #0
        sta scroll_fullspeed
        sta scroll_turbo_base_extra
        sta scroll_turbo_frac_step
sid_scroll_finished:
        lda sid_accum
        clc
        adc sid_rate
        cmp #50
        bcs sid_irq_do_play
        sta sid_accum
        jmp sid_irq_done
sid_irq_do_play:
        sbc #50
        sta sid_accum
        jsr $9003
        ; ---------------------------------------------------------
        ; FIX40: click-safe music fade-in.
        ; VICIOS writes desired D418 to shadow $33F0.
        ; Real D418 receives min(tune volume, fade ceiling).
        ; ---------------------------------------------------------
        lda $33F0
        and #$0F
        sta startup_intro_seconds
        lda startup_intro_fps
        cmp startup_intro_seconds
        bcc fix40_use_ceiling
        lda startup_intro_seconds
        jmp fix40_volume_ready
fix40_use_ceiling:
        lda startup_intro_fps
fix40_volume_ready:
        sta startup_intro_seconds
        lda $33F0
        and #$F0
        ora startup_intro_seconds
        sta $D418
        ; FIX46: identical final master volume on confirmed SID2.
        pha
        lda hardware_profile
        beq fix46_volume_done
        pla
        jsr $CEE2
        jmp fix46_volume_after
fix46_volume_done:
        pla
fix46_volume_after:
        ; Softer ramp: one volume step every 10 PLAY calls.
        ; 15 steps x 10 PLAYs = 150 PLAYs ≈ 3.0 s at 50 Hz.
        lda startup_intro_fps
        cmp #$0F
        bcs fix40_music_fade_done
        inc startup_intro_frame_counter
        lda startup_intro_frame_counter
        cmp #$0A
        bcc fix40_music_fade_done
        lda #$00
        sta startup_intro_frame_counter
        inc startup_intro_fps
fix40_music_fade_done:
        inc sid_play_count_lo
        bne sid_play_count_ready
        inc sid_play_count_hi
sid_play_count_ready:
        lda scroll_turbo_enabled
        beq sid_turbo_trigger_done
        lda scroll_turbo_active
        bne sid_turbo_progress
        lda sid_play_count_hi
        cmp scroll_turbo_trigger_hi
        bcc sid_turbo_trigger_done
        bne sid_turbo_begin
        lda sid_play_count_lo
        cmp scroll_turbo_trigger_lo
        bcc sid_turbo_trigger_done
sid_turbo_begin:
        lda #1
        sta scroll_turbo_active
        lda #0
        sta scroll_turbo_stage
        sta scroll_turbo_stage_counter
        jmp sid_turbo_trigger_done
sid_turbo_progress:
        lda scroll_turbo_stage
        cmp #10
        bcs sid_turbo_trigger_done
        inc scroll_turbo_stage_counter
        lda scroll_turbo_stage_counter
        cmp scroll_turbo_stage_plays
        bcc sid_turbo_trigger_done
        lda #0
        sta scroll_turbo_stage_counter
        inc scroll_turbo_stage
sid_turbo_trigger_done:
        lda sid_end_enabled
        bne sid_end_check
        jmp sid_irq_done
sid_end_check:
        lda sid_play_count_hi
        cmp sid_end_play_hi
        bcs sid_end_hi_reached
        jmp sid_irq_done
sid_end_hi_reached:
        bne sid_begin_end
        lda sid_play_count_lo
        cmp sid_end_play_lo
        bcs sid_begin_end
        jmp sid_irq_done
sid_begin_end:
        ; FIX19: congelar el SID exactamente en el ultimo PLAY valido.
        ; No GATE OFF, no volumen 0, no tocar voces.
        ; Estado 2 evita cualquier PLAY posterior.
        lda #2
        sta sid_end_state
        ; NTSC: stop the SID at the original PLAY count but let the final
        ; upward PETSCII sequence (stage 24) finish before blacking the screen.
        ; PAL-B / PAL-N: exact original end behavior.
        lda detected_machine
        cmp #3
        bcc sid_end_ntsc_visual_pending
        lda #1
        sta demo_finished
sid_end_ntsc_visual_pending:
        lda #0
        sta sid_tail_counter
        sta sid_ramp_active
sid_irq_done:
    
	; CloseIRQ
	pla
	tay
	pla
	tax
	pla
	rti
end_procedure_SidRasterIRQ
	
; // |                    >>> RETORNO LIMPIO A BASIC <<<                            |
; // |              >>> BASIC REAL ACTIVO / ESTETICA EPYX TOOLKIT <<<              |
; // | - restaura KERNAL y BASIC reales                                             |
; // |                 >>> VOTE RICO? / Y-N FINAL <<<                              |
; // | Y = salir al BASIC real                                                     |
; // |              >>> SALIDA INMEDIATA AL BASIC REAL <<<                         |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : SalirABasicReal
	;    Procedure type : User-defined procedure
SalirABasicReal
_vote_basic_exit_common:
        sei
        cld
        ; Restaurar VIC solo desde outro; silenciar SID2 en TODA salida.
        ; RUN/STOP durante DEMO (incluso despues de N) tambien apaga SID2.
        lda basic_return_counter
        cmp #$FF
        bne outro_ocean_basic_mute_sid2
        lda #$1B               ; VIC normal al salir, aunque V lo oculto.
        sta $D011
outro_ocean_basic_mute_sid2:
        ldx hardware_profile
        beq outro_ocean_basic_no_sid2
        lda intro_sid2_base_lo,x
        sta $FB
        lda intro_sid2_base_hi,x
        sta $FC
        lda #$00
        ldy #$04
        sta ($FB),y
        ldy #$0B
        sta ($FB),y
        ldy #$12
        sta ($FB),y
        ldy #$18
        sta ($FB),y
outro_ocean_basic_no_sid2:
        ldx #$FF
        txs
        lda #$00
        sta $D01A
        lda #$0F
        sta $D019
        lda #$00
        sta $D404
        sta $D40B
        sta $D412
        sta $D418
        lda #$37
        sta $01
        jsr $FF84             ; IOINIT
        jsr $FF87             ; RAMTAS
        jsr $FF8A             ; RESTOR
        jsr $FF81             ; CINT
        jsr $E453             ; vectores BASIC
        jsr $E3BF             ; workspace / CHRGET
        jsr $E422             ; punteros / startup
        jsr $FFCC             ; CLRCHN
        cli
        jmp $A474             ; READY.
    
	rts
end_procedure_SalirABasicReal
	
; // |  >>> N: DEMO DIRECTA / S: REPETIR SYSINFO 64 Y DESPUES DEMO <<<          |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ReiniciarDemoDesdeOutro
	;    Procedure type : User-defined procedure
ReiniciarDemoDesdeOutro
restart_s_irq_safe_entry:
        sei
        ; Tras detectar S, este punto se alcanza sin CLI intermedio.
        ; El loader del outro dejó la musica y raster IRQ detenidos.
        ; Asegurar estado silencioso, sin tocar la deteccion ya efectuada.
        lda #$00
        sta $D01A
        sta $D015
        sta $D404
        sta $D40B
        sta $D412
        sta $D418
        lda #$0F
        sta $D019
        ; Apagar tambien SID2, si SYSINFO lo habia detectado.
        ldx hardware_profile
        beq restart_no_sid2
        lda intro_sid2_base_lo,x
        sta $FB
        lda intro_sid2_base_hi,x
        sta $FC
        lda #$00
        ldy #$04
        sta ($FB),y
        ldy #$0B
        sta ($FB),y
        ldy #$12
        sta ($FB),y
        ldy #$18
        sta ($FB),y
restart_no_sid2:
        lda #$35               ; RAM visible bajo KERNAL
        sta $01
        ; N y S vuelven a la escala MASTER sin modificar los BIN de disco.
        jsr $F6DE              ; restaurar gris Y desactivar ciclo 0..9, RAM visible $35.
        jsr $8000              ; restaurar charset original (23 glifos)
        lda #$1B               ; restaurar DEN al reiniciar con N.
        sta $D011
        ; El contador FF significaba outro. El test debe empezar limpio.
        lda #$00
        sta basic_return_counter
        ; S=3: volver a SYSINFO; N=2: saltarlo como antes.
        lda escape_requested
        cmp #$03
        beq restart_full_sysinfo
        lda #$02
        bne restart_store_entry_mode
restart_full_sysinfo:
        ; S: recuperar banking del inicio y entrar DIRECTAMENTE al test.
        ; Se evita pasar por el condicional del reinicio general, que en
        ; la prueba anterior siguio saltando SYSINFO.
        lda #$37
        sta $01
        lda #$03
        sta startup_intro_done
        ldx #$FF
        txs
        jmp demo_sysinfo_force_entry
restart_store_entry_mode:
        sta startup_intro_done
        ldx #$FF
        txs                    ; descartar pila del loop anterior
        jmp demo_restart_entry ; N: reset sin test (comportamiento aprobado)
    
	rts
end_procedure_ReiniciarDemoDesdeOutro
	
; // |          >>> ESC EMULADOR / RUN-STOP C64 / POLL DIRECTO <<<                |
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ChequearEscape
	;    Procedure type : User-defined procedure
ChequearEscape
	lda #$0
	; Calling storevariable on generic assign expression
	sta escape_requested
        sei
        lda $DC00
        pha
        lda $DC02
        pha
        lda $DC03
        pha
        lda #$FF
        sta $DC02
        lda #$00
        sta $DC03
        lda #$7F
        sta $DC00
        ; RUN/STOP (PA7, PB7): salida a BASIC en cualquier momento.
        lda $DC01
        and #$80
        bne _outro_keyboard_gate
        jmp _escape_pressed
_outro_keyboard_gate:
        ; S tambien funciona en la DEMO (este polling corre tras WaitVBlank).
        ; Y/N/V siguen siendo exclusivas del outro y conservan prioridad.
        lda basic_return_counter
        cmp #$FF
        beq _outro_keyboard_scan
        jmp _check_restart_sysinfo
_outro_keyboard_scan:
        ; Antes de Y, descartar falso PB1 por joystick 1 hacia abajo.
        lda #$FF
        sta $DC00
        lda $DC01
        and #$02
        beq _check_vote_no
        ; Y: PA3=$F7, PB1=$02 (prioridad sobre N y V).
        lda #$F7
        sta $DC00
        lda $DC01
        and #$02
        bne _check_vote_no
        jmp _escape_pressed
_check_vote_no:
        ; N: PA4=$EF, PB7=$80. Reinicio sin SYSINFO ya probado.
        lda #$EF
        sta $DC00
        lda $DC01
        and #$80
        bne _check_restart_sysinfo
        lda #$02
        sta escape_requested
        jmp _escape_not_pressed
_check_restart_sysinfo:
        ; S: PA1=$FD, PB5=$20. Disponible en DEMO y en OUTRO.
        ; Latch: una sola solicitud por pulsacion, hasta soltar S.
        lda #$FD
        sta $DC00
        lda $DC01
        and #$20
        bne _s_key_released
        lda demo_s_key_latch
        beq _s_key_new_press
        jmp _escape_not_pressed
_s_key_new_press:
        lda #$01
        sta demo_s_key_latch
        lda #$03
        sta escape_requested
        jmp _escape_not_pressed
_s_key_released:
        lda #$00
        sta demo_s_key_latch
        ; OUTRO: V intacta. DEMO: scan matricial 0..9 en modulo $811E.
        lda basic_return_counter
        cmp #$FF
        beq _check_toggle_v
        lda demo_finished
        bne _escape_not_pressed
        jsr demo_o_outro_probe ; O -> demo_finished; otra -> paleta $811E.
        jmp _escape_not_pressed
_check_toggle_v:
        ; V: PA3=$F7, PB7=$80. Un cambio por PULSACION.
        lda #$F7
        sta $DC00
        lda $DC01
        and #$80
        beq _v_key_down
        ; Al soltar V se habilita la siguiente pulsacion.
        lda #$00
        sta outro_v_key_latch
        jmp _escape_not_pressed
_v_key_down:
        lda outro_v_key_latch
        beq _v_new_press
        jmp _escape_not_pressed
_v_new_press:
        lda #$01
        sta outro_v_key_latch
        ; OUTRO siempre configura D011=$1B y borde negro.
        ; DEN bit4=0 => imagen oculta ($0B); bit4=1 => imagen ($1B).
        ; No escribir de vuelta el bit7 leido de D011 (raster MSB).
        lda $D011
        and #$10
        beq _v_show_display
        lda #$0B
        jmp _v_write_display
_v_show_display:
        lda #$1B
_v_write_display:
        sta $D011
        jmp _escape_not_pressed
_escape_pressed:
        lda #$01
        sta escape_requested
_escape_not_pressed:
        pla
        sta $DC03
        pla
        sta $DC02
        pla
        sta $DC00
        ; S: con IRQ aun enmascaradas, saltar al reinicio completo.
        ; En DEMO habia una ventana CLI -> llamada Pascal -> SEI que
        ; no existe en OUTRO. Y/N/V/RUNSTOP conservan su flujo previo.
        lda escape_requested
        cmp #$03
        bne _escape_restore_irq
        jmp restart_s_irq_safe_entry
_escape_restore_irq:
        cli
    
	; Binary clause Simplified: EQUALS
	lda escape_requested
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne ChequearEscape_edblock1978
ChequearEscape_ctb1976: ;Main true block ;keep 
	jsr SalirABasicReal
ChequearEscape_edblock1978
	; Binary clause Simplified: EQUALS
	lda escape_requested
	; Compare with pure num / var optimization
	cmp #$2;keep
	bne ChequearEscape_edblock1984
ChequearEscape_ctb1982: ;Main true block ;keep 
	jsr ReiniciarDemoDesdeOutro
ChequearEscape_edblock1984
	; Binary clause Simplified: EQUALS
	lda escape_requested
	; Compare with pure num / var optimization
	cmp #$3;keep
	bne ChequearEscape_edblock1990
ChequearEscape_ctb1988: ;Main true block ;keep 
	jsr ReiniciarDemoDesdeOutro
ChequearEscape_edblock1990
	rts
end_procedure_ChequearEscape
	
; // PALETAS 0..9: detector original intacto; aplicacion diferida en BIN $811E.
; // Cada llamada hace como maximo 64 bytes y permite un ultimo pedido en cola.
; // En el reinicio N/S, $81CE termina la cola y restaura gris con IRQ detenidas.
	; NodeProcedureDecl 51
	; ***********  Defining procedure : AlternarPaletasDemo
	;    Procedure type : User-defined procedure
AlternarPaletasDemo
        jsr $F660  ; RAM bajo KERNAL ya visible por SetMemoryConfig(1,0,0).
    
	rts
end_procedure_AlternarPaletasDemo
	
; // OUTRO: audio EXACTO de INTRO ($3A64 init, $8400 init, $3A00+ $8403 tick,
; // $8409 hold), con reloj propio; la animacion de filas divididas sigue intacta.
; // VISUAL ORIGINAL: fase cada 4 cuadros; pixels y caracteres cada 8 cuadros.
; // Arriba 207/208 opuesto a abajo 204/250; direccion se invierte con el
; // paneo del SID2 exactamente en el intervalo de fases de la intro.
; // Las olas pasan a gris oscuro ($0B); linea 25: texto gris claro ($0F).
	; NodeProcedureDecl 51
	; ***********  Defining procedure : InicializarOutroMar
	;    Procedure type : User-defined procedure
InicializarOutroMar
	
; // V solo en el outro: cada entrada empieza con la tecla liberada.
	lda #$0
	; Calling storevariable on generic assign expression
	sta outro_v_key_latch
	lda #$2
	; Calling storevariable on generic assign expression
	sta n_izq
	; Calling storevariable on generic assign expression
	sta n_der
	lda #$0
	; Calling storevariable on generic assign expression
	sta n_arriba
	; Calling storevariable on generic assign expression
	sta n_abajo
	lda #$cf
	; Calling storevariable on generic assign expression
	sta chars_izq+$0
	lda #$d0
	; Calling storevariable on generic assign expression
	sta chars_izq+$1
	lda #$cc
	; Calling storevariable on generic assign expression
	sta chars_der+$0
	lda #$fa
	; Calling storevariable on generic assign expression
	sta chars_der+$1
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_counter
        ldx #$00
outro_sea_white_page0:
        lda $0400,x
        cmp #$CC
        beq outro_sea_white_0
        cmp #$CF
        beq outro_sea_white_0
        cmp #$D0
        beq outro_sea_white_0
        cmp #$FA
        bne outro_sea_white_page1_check
outro_sea_white_0:
        lda #$0B
        sta $D800,x
outro_sea_white_page1_check:
        lda $0500,x
        cmp #$CC
        beq outro_sea_white_1
        cmp #$CF
        beq outro_sea_white_1
        cmp #$D0
        beq outro_sea_white_1
        cmp #$FA
        bne outro_sea_white_page2_check
outro_sea_white_1:
        lda #$0B
        sta $D900,x
outro_sea_white_page2_check:
        lda $0600,x
        cmp #$CC
        beq outro_sea_white_2
        cmp #$CF
        beq outro_sea_white_2
        cmp #$D0
        beq outro_sea_white_2
        cmp #$FA
        bne outro_sea_white_page3_check
outro_sea_white_2:
        lda #$0B
        sta $DA00,x
outro_sea_white_page3_check:
        cpx #$E8
        bcs outro_sea_white_next
        lda $0700,x
        cmp #$CC
        beq outro_sea_white_3
        cmp #$CF
        beq outro_sea_white_3
        cmp #$D0
        beq outro_sea_white_3
        cmp #$FA
        bne outro_sea_white_next
outro_sea_white_3:
        lda #$0B
        sta $DB00,x
outro_sea_white_next:
        inx
        beq outro_sea_white_done
        jmp outro_sea_white_page0
outro_sea_white_done:
        ; Iniciar EXACTAMENTE el motor de audio probado de la intro, una vez
        ; cargados mapa, colores y charset. El MUSIC IRQ esta detenido.
        ; No ejecutar el antiguo helper grafico $3ABC: animaria $2800, no
        ; el charset $2000 que ahora usa la pantalla de la outro.
        lda #$00
        sta startup_intro_fps
        sta sid_ramp_frame_counter
        sta outro_audio_phase   ; audio clonado parte de fase 0
        sta outro_audio_divider ; independiente del reloj visual original
        sta $3B46              ; mismo divisor de animacion que la intro.
        sta $3B9E              ; misma cadencia de paneo del helper $1800.
        sta $3B9F              ; desplazamiento de 0 a 15 pixeles.
        sta $D417             ; quitar ruteo de filtro residual de VICIOS.
        sta $D404
        sta $D40B
        sta $D412
        lda #$90
        sta $D413
        lda #$FA
        sta $D414
        lda #$0F
        sta $D418
        lda #$81
        sta $D412
        ; SID2 opcional: solo la direccion realmente detectada por RicOS.
        ldx hardware_profile
        beq outro_ocean_sid_ready
        lda intro_sid2_base_lo,x
        sta $FB
        lda intro_sid2_base_hi,x
        sta $FC
        lda #$00
        ldy #$04
        sta ($FB),y
        ldy #$0B
        sta ($FB),y
        ldy #$12
        sta ($FB),y
        ldy #$17
        sta ($FB),y
        ldy #$13
        lda #$90
        sta ($FB),y
        iny
        lda #$FA
        sta ($FB),y
        ldy #$18
        lda #$0F
        sta ($FB),y
        ldy #$12
        lda #$80
        sta ($FB),y
outro_ocean_sid_ready:
        ; Mismo arranque sonoro completo que la INTRO: lecho y voces,
        ; generador de ruido, cutoff -$20, volumen aprobado y fade-in.
        ; El audio original de OUTRO queda sustituido, no mezclado.
        jsr $3A64
        ldx hardware_profile
        jsr $F900
        jsr $8B07             ; OUTRO: iniciar linea 25 y adelantar fade del mar al nivel 2.
        lda #$00
        sta outro_text_speed10_counter
    
	rts
end_procedure_InicializarOutroMar
	; NodeProcedureDecl 51
	; ***********  Defining procedure : ActualizarOutroMar
	;    Procedure type : User-defined procedure
ActualizarOutroMar
        inc sid_ramp_frame_counter
        lda sid_ramp_frame_counter
        and #$03
        bne outro_ocean_keep_phase
        inc startup_intro_fps
outro_ocean_keep_phase:
        ; MOTOR SONORO DE INTRO, sin tocar la fase que gobierna el dibujo.
        ; La rutina visual de abajo conserva startup_intro_fps y $F100.
        lda outro_audio_phase
        and #$7F
        cmp #$60              ; quiebre global $60/$E0
        bne outro_audio_step
        ldx detected_machine
        jsr $8409             ; mismo hold de espuma que INTRO
        beq outro_audio_render
        inc outro_audio_phase
        lda #$08
        sta outro_audio_divider
        jmp outro_audio_render
outro_audio_step:
        inc outro_audio_divider
        lda outro_audio_phase
        and #$7F
        cmp #$10
        bcc outro_audio_normal
        cmp #$20
        bcs outro_audio_normal
        lda outro_audio_divider
        and #$0F              ; calma: 16 cuadros por paso
        bne outro_audio_render
        jmp outro_audio_advance
outro_audio_normal:
        lda outro_audio_phase
        and #$7F
        cmp #$20
        bcc outro_audio_eight
        cmp #$60
        bcs outro_audio_eight
        lda outro_audio_divider
        and #$07
        cmp #$04              ; ascenso aprobado: 4 cuadros por paso
        bne outro_audio_render
        lda #$00
        sta outro_audio_divider
        jmp outro_audio_advance
outro_audio_eight:
        lda outro_audio_divider
        and #$07              ; resto: 8 cuadros por paso
        bne outro_audio_render
outro_audio_advance:
        inc outro_audio_phase
outro_audio_render:
        ; Asegurar puntero SID2: scroll de texto/charset puede usar ZP.
        ; Con SID unico, no efectuar ningun acceso a un segundo chip.
        ldx hardware_profile
        beq outro_audio_sid_ready
        lda intro_sid2_base_lo,x
        sta $FB
        lda intro_sid2_base_hi,x
        sta $FC
outro_audio_sid_ready:
        lda outro_audio_phase
        ldx hardware_profile
        jsr $3A00             ; frecuencias y GATE identicos a INTRO
        lda outro_audio_phase
        ldx hardware_profile
        jsr $F903             ; OUTRO-only: motor aprobado + alternancia voz extra.
        ; A PARTIR DE AQUI, VISUAL DE OUTRO ORIGINAL INTACTO.
        inc $3B46
        lda $3B46
        and #$07
        sta anim_counter
    
	; Binary clause Simplified: EQUALS
	clc
	lda anim_counter
	; cmp #$00 ignored
	bne ActualizarOutroMar_edblock1999
ActualizarOutroMar_ctb1997: ;Main true block ;keep 
	
; // El bucle principal ya llama WaitVBlank. VISUAL SIN CAMBIOS:
; // fase propia cada 4 cuadros; caracteres y paneo cada 8.
; // AUDIO: fase independiente con calma, ascenso 4, quiebre retenido,
; // espuma, retirada, filtro y volumen clonados de INTRO.
; // Conservar las franjas 207/208 arriba, 204/250 abajo, charset $2000.
	jsr AnimarCaracterIndependiente
ActualizarOutroMar_edblock1999
        lda startup_intro_fps
        ldx hardware_profile
        jsr $F100
        jsr $FF34             ; esperar ~10 s desde la outro; luego scroll cada 8 cuadros.
        ; SOLO texto de linea 25: +10% de velocidad MEDIA de desplazamiento.
        ; El BIN da 1 tick/frame (1 caracter/8 ticks). Tras la espera,
        ; agregar exactamente 1 tick cada 10 frames = 11/10 ticks/frame.
        ; No acelerar la espera, el oceano, musica, animaciones ni VOTE.
        lda $FF7C             ; estado BIN: 2 = scroll activo
        cmp #$02
        bne outro_text_speed10_inactive
        inc outro_text_speed10_counter
        lda outro_text_speed10_counter
        cmp #$0A
        bcc outro_text_speed10_done
        lda #$00
        sta outro_text_speed10_counter
        jsr $F203             ; solo 1 tick de texto adicional
        jmp outro_text_speed10_done
outro_text_speed10_inactive:
        lda #$00
        sta outro_text_speed10_counter
outro_text_speed10_done:
        jsr $FF7F             ; blink solo letras VOTE, amarillo/blanco, sin invertir.
    
	rts
end_procedure_ActualizarOutroMar
	
; // Igual que la intro: desplazamiento de pixels y de codigos cada
; // ocho cuadros. Se refrescan las seis copias DESPUES de rotar los
; // cuatro caracteres originales para que formas y posiciones coincidan.
; // A=fase del oceano; X=SID2 detectado, igual que en $1800.
; // OUTRO STAGE 1: after the same black pause, mute SID2 and load the new
; // static artwork. Preserve the original immediate RUN/STOP -> BASIC procedure.
	; NodeProcedureDecl 51
	; ***********  Defining procedure : FinalizarDemoEnBasic
	;    Procedure type : User-defined procedure
FinalizarDemoEnBasic
_vote_yes:
        ; Unico punto de apagado: nunca silenciar antes de Y.
        sei
        lda hardware_profile  ; 0=no SID2, 1=DE00, 2=D420, 3=D500
        beq _vote_yes_basic
        tax
        lda intro_sid2_base_lo,x
        sta $FB
        lda intro_sid2_base_hi,x
        sta $FC
        lda #$00
        ldy #$04             ; SID2: voice 1 GATE OFF
        sta ($FB),y
        ldy #$0B             ; SID2: voice 2 GATE OFF
        sta ($FB),y
        ldy #$12             ; SID2: voice 3 GATE OFF
        sta ($FB),y
        ldy #$18             ; SID2: master volume 0
        sta ($FB),y
_vote_yes_basic:
        ; OUTRO STAGE 1: same SID2 shutdown, but load static art instead of BASIC.
        ; Map out KERNAL so the new data/code under $E000/$F000 are readable.
        lda #$35
        sta $01
        jmp $F000
    
	rts
end_procedure_FinalizarDemoEnBasic
block1
main_block_begin_
demo_restart_entry:
    
	
; // |                           >>> PROGRAMA PRINCIPAL <<<                         |
; // Entrada principal conservada sin alterar el estado de inicializacion.
	sei
	; Binary clause Simplified: NOTEQUALS
	lda startup_intro_done
	; Compare with pure num / var optimization
	cmp #$2;keep
	beq MainProgram_edblock2006
MainProgram_ctb2004: ;Main true block ;keep 
demo_sysinfo_force_entry:
        
	
; // 0=primer arranque, 2=N (sin test), 3=S (repetir test).
; // Despues de S, usar 2: NO aplicar de nuevo el parche SID2 ni D418.
; // Entrada exclusiva S: salta la DECISION, no el test.
; // Con IRQ desactivadas y pila vacia desde ReiniciarDemoDesdeOutro.
	jsr MostrarPantallaDeteccion
	; Binary clause Simplified: EQUALS
	lda startup_intro_done
	; Compare with pure num / var optimization
	cmp #$3;keep
	bne MainProgram_eblock2019
MainProgram_ctb2018: ;Main true block ;keep 
	lda #$2
	; Calling storevariable on generic assign expression
	sta startup_intro_done
	jmp MainProgram_edblock2020
MainProgram_eblock2019
	lda #$1
	; Calling storevariable on generic assign expression
	sta startup_intro_done
MainProgram_edblock2020
MainProgram_edblock2006
	
; // RESET REAL DE ESTADO EN EL ARRANQUE
	lda #$2a
	; Calling storevariable on generic assign expression
	sta next_line
	lda #$7
	; Calling storevariable on generic assign expression
	sta fine_scroll
	lda #$1
	; Calling storevariable on generic assign expression
	sta direction
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_coarse_event
	; Calling storevariable on generic assign expression
	sta escape_requested
	; Calling storevariable on generic assign expression
	sta demo_palette_request
	; Calling storevariable on generic assign expression
	sta demo_palette_latch_lo
	; Calling storevariable on generic assign expression
	sta demo_palette_latch_hi
	lda #$1
	; Calling storevariable on generic assign expression
	sta anim_combo_black_period
	lda #$0
	; Calling storevariable on generic assign expression
	sta n_izq
	lda #$4
	; Calling storevariable on generic assign expression
	sta n_der
	lda #$0
	; Calling storevariable on generic assign expression
	sta n_arriba
	; Calling storevariable on generic assign expression
	sta n_abajo
	lda #$3
	; Calling storevariable on generic assign expression
	sta blink_global_speed
	lda #$1
	; Calling storevariable on generic assign expression
	sta blink_global_black
	lda #$2
	; Calling storevariable on generic assign expression
	sta color_mode
	lda #$7
	; Calling storevariable on generic assign expression
	sta linear_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta linear_mirror
	; Calling storevariable on generic assign expression
	sta linear_row
	lda #$1
	; Calling storevariable on generic assign expression
	sta cross_subdivision
	lda #$2
	; Calling storevariable on generic assign expression
	sta cross_row_period
	lda #$0
	; Calling storevariable on generic assign expression
	sta cross_mirror
	lda #$3
	; Calling storevariable on generic assign expression
	sta vertical_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_mirror
	lda #$1
	; Calling storevariable on generic assign expression
	sta vertical_scroll_enabled
	lda #$4
	; Calling storevariable on generic assign expression
	sta vertical_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta vertical_scroll_motion
	; Calling storevariable on generic assign expression
	sta vertical_scroll_offset
	; Calling storevariable on generic assign expression
	sta vertical_scroll_counter
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_subdivision
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_direction
	lda #$1
	; Calling storevariable on generic assign expression
	sta radial_scroll_enabled
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_scroll_speed
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_direction
	lda #$2
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_period
	
; // STAGE 5
	lda #$0
	; Calling storevariable on generic assign expression
	sta stage5_scroll_phase
	
; // STAGE 13
	; Calling storevariable on generic assign expression
	sta stage13_static_active
	lda #$74
	; Calling storevariable on generic assign expression
	sta stage13_ghost_next_line
	lda #$7
	; Calling storevariable on generic assign expression
	sta stage13_ghost_fine_scroll
	lda #$0
	; Calling storevariable on generic assign expression
	sta stage13_consumed_update
	; Set Memory Config
	lda $01
	and #%11111000
	ora #%101
	sta $01
	; Disable interrupts
	ldy #$7f    ; $7f = %01111111
	sty $dc0d   ; Turn off CIAs Timer interrupts ;keep
	sty $dd0d   ; Turn off CIAs Timer interrupts ;keep
	lda $dc0d   ; cancel all CIA-IRQs in queue/unprocessed ;keep
	lda $dd0d   ; cancel all CIA-IRQs in queue/unprocessed ;keep
	lda #$0
	; Calling storevariable on generic assign expression
	sta vic_border
	; Calling storevariable on generic assign expression
	sta vic_fondo
	; Calling storevariable on generic assign expression
	sta screen_active
	lda #$18
	; Calling storevariable on generic assign expression
	sta screen_d018_real
	lda #$1a
	; Calling storevariable on generic assign expression
	sta screen_d018_mask
	lda screen_d018_real
	; Calling storevariable on generic assign expression
	sta vic_d018
	lda #$c8
	; Calling storevariable on generic assign expression
	sta vic_d016
	; 8 bit binop
	; Add/sub where right value is constant number
	lda #$10
	clc
	adc fine_scroll
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta vic_d011
	jsr RenderizarBinarios
	jsr InicializarMascaraSuperior
	lda #$0
	; Calling storevariable on generic assign expression
	sta top_mask_phase
	jsr PrepararBufferArriba
        ; ---------------------------------------------------------
        ; FIX46: live write-through mirror.
        ; No SID2 -> no patch: VICIOS remains original.
        ; SID2 -> every real D400-D417 store goes to both chips immediately.
        ; ---------------------------------------------------------
        lda startup_intro_done
        cmp #$02               ; segundo pase: musica YA parcheada
        beq fix46_no_stereo_setup
        lda hardware_profile
        beq fix46_no_stereo_setup
        jsr $CE60
fix46_no_stereo_setup:
        ; ---------------------------------------------------------
        ; FIX40: patch VICIOS STA $D418 writes to shadow $33F0.
        ; This prevents the player from fighting the fade envelope.
        ; Music area is $8C00-$A0FF; fixed radial data begins $A100.
        ; NO escanear otra vez el player ya reescrito al volver con N.
        ; ---------------------------------------------------------
        lda startup_intro_done
        cmp #$02
        beq fix40_patch_skip
        lda $FB
        pha
        lda $FC
        pha
        lda #$00
        sta $FB
        lda #$8C
        sta $FC
fix40_patch_d418_loop:
        lda $FC
        cmp #$A1
        beq fix40_patch_d418_done
        ldy #$00
        lda ($FB),y
        cmp #$8D              ; STA absolute
        bne fix40_patch_d418_next
        iny
        lda ($FB),y
        cmp #$18
        bne fix40_patch_d418_next
        iny
        lda ($FB),y
        cmp #$D4
        bne fix40_patch_d418_next
        ; STA $D418 -> STA $33F0
        dey
        lda #$F0
        sta ($FB),y
        iny
        lda #$33
        sta ($FB),y
fix40_patch_d418_next:
        inc $FB
        bne fix40_patch_d418_loop
        inc $FC
        jmp fix40_patch_d418_loop
fix40_patch_d418_done:
        pla
        sta $FC
        pla
        sta $FB
fix40_patch_skip:
        ; Real SID starts completely silent.
        lda #$00
        sta $D418
        pha
        lda hardware_profile
        beq fix46_zero_done
        pla
        jsr $CEE2
        jmp fix46_zero_after
fix46_zero_done:
        pla
fix46_zero_after:
        sta $33F0
        ; INIT now writes its desired D418 value to the shadow.
        lda #$00
        jsr $8FFE
        ; Fade ceiling and divider start at zero.
        lda #$00
        sta startup_intro_fps
        sta startup_intro_frame_counter
        sta startup_intro_seconds
    
	; Binary clause Simplified: LESS
	lda sid_speed_mode
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2026
MainProgram_ctb2024: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta sid_speed_mode
MainProgram_edblock2026
	; Optimization: replacing a > N with a >= N+1
	; Binary clause Simplified: GREATEREQUAL
	lda sid_speed_mode
	; Compare with pure num / var optimization
	cmp #$b;keep
	bcc MainProgram_edblock2032
MainProgram_ctb2030: ;Main true block ;keep 
	lda #$a
	; Calling storevariable on generic assign expression
	sta sid_speed_mode
MainProgram_edblock2032
	; Load Byte array
	; CAST type NADA
	; 8 bit binop
	; Add/sub where right value is constant number
	lda sid_speed_mode
	sec
	sbc #$1
	 ; end add / sub var with constant
	tax
	lda sid_speed_table,x 
	; Calling storevariable on generic assign expression
	sta sid_rate
	; Binary clause Simplified: LESS
	lda sid_ramp_target_rate
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2038
MainProgram_ctb2036: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta sid_ramp_target_rate
MainProgram_edblock2038
	; Optimization: replacing a > N with a >= N+1
	; Binary clause Simplified: GREATEREQUAL
	lda sid_ramp_target_rate
	; Compare with pure num / var optimization
	cmp #$33;keep
	bcc MainProgram_edblock2044
MainProgram_ctb2042: ;Main true block ;keep 
	lda #$32
	; Calling storevariable on generic assign expression
	sta sid_ramp_target_rate
MainProgram_edblock2044
	; Binary clause Simplified: LESS
	lda sid_gradient
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2050
MainProgram_ctb2048: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta sid_gradient
MainProgram_edblock2050
	; Optimization: replacing a > N with a >= N+1
	; Binary clause Simplified: GREATEREQUAL
	lda sid_gradient
	; Compare with pure num / var optimization
	cmp #$b;keep
	bcc MainProgram_edblock2056
MainProgram_ctb2054: ;Main true block ;keep 
	lda #$a
	; Calling storevariable on generic assign expression
	sta sid_gradient
MainProgram_edblock2056
	; Load Byte array
	; CAST type NADA
	; 8 bit binop
	; Add/sub where right value is constant number
	lda sid_gradient
	sec
	sbc #$1
	 ; end add / sub var with constant
	tax
	lda sid_gradient_table,x 
	; Calling storevariable on generic assign expression
	sta sid_gradient_blocks
	; Binary clause Simplified: LESS
	lda scroll_speed_manual
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2062
MainProgram_ctb2060: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_speed_manual
MainProgram_edblock2062
	; Binary clause Simplified: LESS
	lda scroll_speed_slow
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2068
MainProgram_ctb2066: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_speed_slow
MainProgram_edblock2068
	; Binary clause Simplified: LESS
	lda scroll_speed_mid1
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2074
MainProgram_ctb2072: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_speed_mid1
MainProgram_edblock2074
	; Binary clause Simplified: LESS
	lda scroll_speed_mid2
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2080
MainProgram_ctb2078: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_speed_mid2
MainProgram_edblock2080
	; Binary clause Simplified: LESS
	lda scroll_speed_fast
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2086
MainProgram_ctb2084: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_speed_fast
MainProgram_edblock2086
	; Binary clause Simplified: EQUALS
	lda sid_start_on_first_content
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_eblock2091
MainProgram_ctb2090: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta sid_ramp_active
	jmp MainProgram_edblock2092
MainProgram_eblock2091
	lda sid_ramp_enabled
	; Calling storevariable on generic assign expression
	sta sid_ramp_active
MainProgram_edblock2092
	lda #$0
	; Calling storevariable on generic assign expression
	sta sid_first_content_triggered
	; Binary clause Simplified: EQUALS
	clc
	lda scroll_sid_link
	; cmp #$00 ignored
	bne MainProgram_eblock2099
MainProgram_ctb2098: ;Main true block ;keep 
	lda scroll_speed_manual
	; Calling storevariable on generic assign expression
	sta scroll_speed
	jmp MainProgram_edblock2100
MainProgram_eblock2099
	; Binary clause Simplified: GREATEREQUAL
	lda sid_rate
	; Compare with pure num / var optimization
	cmp scroll_rate_fast;keep
	bcc MainProgram_eblock2149
MainProgram_ctb2148: ;Main true block ;keep 
	lda scroll_speed_fast
	; Calling storevariable on generic assign expression
	sta scroll_speed
	jmp MainProgram_edblock2150
MainProgram_eblock2149
	; Binary clause Simplified: GREATEREQUAL
	lda sid_rate
	; Compare with pure num / var optimization
	cmp scroll_rate_mid2;keep
	bcc MainProgram_eblock2155
MainProgram_ctb2154: ;Main true block ;keep 
	lda scroll_speed_mid2
	; Calling storevariable on generic assign expression
	sta scroll_speed
	jmp MainProgram_edblock2156
MainProgram_eblock2155
	; Binary clause Simplified: GREATEREQUAL
	lda sid_rate
	; Compare with pure num / var optimization
	cmp scroll_rate_mid1;keep
	bcc MainProgram_eblock2161
MainProgram_ctb2160: ;Main true block ;keep 
	lda scroll_speed_mid1
	; Calling storevariable on generic assign expression
	sta scroll_speed
	jmp MainProgram_edblock2162
MainProgram_eblock2161
	lda scroll_speed_slow
	; Calling storevariable on generic assign expression
	sta scroll_speed
MainProgram_edblock2162
MainProgram_edblock2156
MainProgram_edblock2150
MainProgram_edblock2100
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_phase
	
; // Reset independent visual-only fractions; SID IRQ/music remains untouched.
	; Calling storevariable on generic assign expression
	sta drean_visual_phase
	; Calling storevariable on generic assign expression
	sta ntsc_visual_phase
	; Calling storevariable on generic assign expression
	sta scroll_update_now
	; Binary clause Simplified: EQUALS
	lda scroll_sid_link
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_eblock2167
MainProgram_ctb2166: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda sid_rate
	; Compare with pure num / var optimization
	cmp scroll_rate_fast;keep
	bcc MainProgram_eblock2212
MainProgram_ctb2211: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_fullspeed
	jmp MainProgram_edblock2213
MainProgram_eblock2212
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_fullspeed
	; Binary clause Simplified: GREATEREQUAL
	lda sid_rate
	; Compare with pure num / var optimization
	cmp scroll_rate_mid2;keep
	bcc MainProgram_eblock2218
MainProgram_ctb2217: ;Main true block ;keep 
	; 8 bit binop
	; Add/sub where right value is constant number
	lda sid_rate
	sec
	sbc scroll_rate_mid2
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta map_idx
	; Binary clause Simplified: GREATEREQUAL
	; Compare with pure num / var optimization
	cmp #$a;keep
	bcc MainProgram_edblock2224
MainProgram_ctb2222: ;Main true block ;keep 
	lda #$9
	; Calling storevariable on generic assign expression
	sta map_idx
MainProgram_edblock2224
	; Load Byte array
	; CAST type NADA
	ldx map_idx
	lda scroll_smooth_table,x 
	; Calling storevariable on generic assign expression
	sta scroll_phase_step
	jmp MainProgram_edblock2219
MainProgram_eblock2218
	lda #$80
	; Calling storevariable on generic assign expression
	sta scroll_phase_step
MainProgram_edblock2219
MainProgram_edblock2213
	jmp MainProgram_edblock2168
MainProgram_eblock2167
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_fullspeed
	lda #$80
	; Calling storevariable on generic assign expression
	sta scroll_phase_step
MainProgram_edblock2168
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_turbo_base_extra
	; Calling storevariable on generic assign expression
	sta scroll_turbo_frac_step
	; Calling storevariable on generic assign expression
	sta scroll_turbo_phase
	lda scroll_step
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_turbo_active
	; Calling storevariable on generic assign expression
	sta scroll_turbo_stage
	; Calling storevariable on generic assign expression
	sta scroll_turbo_stage_counter
	; Binary clause Simplified: LESS
	lda scroll_turbo_max_step
	; Compare with pure num / var optimization
	cmp scroll_step;keep
	bcs MainProgram_edblock2231
MainProgram_ctb2229: ;Main true block ;keep 
	lda scroll_step
	; Calling storevariable on generic assign expression
	sta scroll_turbo_max_step
MainProgram_edblock2231
	; Optimization: replacing a > N with a >= N+1
	; Binary clause Simplified: GREATEREQUAL
	lda scroll_turbo_max_step
	; Compare with pure num / var optimization
	cmp #$8;keep
	bcc MainProgram_edblock2237
MainProgram_ctb2235: ;Main true block ;keep 
	lda #$7
	; Calling storevariable on generic assign expression
	sta scroll_turbo_max_step
MainProgram_edblock2237
	; Binary clause Simplified: LESS
	lda scroll_turbo_final_seconds
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2243
MainProgram_ctb2241: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_turbo_final_seconds
MainProgram_edblock2243
	; Optimization: replacing a > N with a >= N+1
	; Binary clause Simplified: GREATEREQUAL
	lda scroll_turbo_final_seconds
	; Compare with pure num / var optimization
	cmp #$33;keep
	bcc MainProgram_edblock2249
MainProgram_ctb2247: ;Main true block ;keep 
	lda #$32
	; Calling storevariable on generic assign expression
	sta scroll_turbo_final_seconds
MainProgram_edblock2249
	lda #$0
	; Calling storevariable on generic assign expression
	sta sid_accum
	; Binary clause Simplified: LESS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$3;keep
	bcs MainProgram_eblock2254
MainProgram_ctb2253: ;Main true block ;keep 
	
; // Reiniciar fase del reloj multisistema.
	lda #$0
	; Calling storevariable on generic assign expression
	sta demo_logic_tick
	jmp MainProgram_edblock2255
MainProgram_eblock2254
	lda #$1
	; Calling storevariable on generic assign expression
	sta demo_logic_tick
MainProgram_edblock2255
	lda #$0
	; Calling storevariable on generic assign expression
	sta demo_visual_do_tick
	; Binary clause Simplified: EQUALS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_eblock2262
MainProgram_ctb2261: ;Main true block ;keep 
	
; // 45 - 37 = 8: fuerza tick en el primer frame.
	lda #$8
	; Calling storevariable on generic assign expression
	sta demo_tick_accum
	jmp MainProgram_edblock2263
MainProgram_eblock2262
	; Binary clause Simplified: EQUALS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$2;keep
	bne MainProgram_eblock2278
MainProgram_ctb2277: ;Main true block ;keep 
	
; // 37 - 31 = 6: fuerza tick en el primer frame.
	lda #$6
	; Calling storevariable on generic assign expression
	sta demo_tick_accum
	jmp MainProgram_edblock2279
MainProgram_eblock2278
	lda #$0
	; Calling storevariable on generic assign expression
	sta demo_tick_accum
MainProgram_edblock2279
MainProgram_edblock2263
	lda #$0
	; Calling storevariable on generic assign expression
	sta sid_ramp_frame_counter
	; Calling storevariable on generic assign expression
	sta sid_ramp_block_counter
	; Calling storevariable on generic assign expression
	sta speed_counter
	; Calling storevariable on generic assign expression
	sta blink_global_counter
	; Calling storevariable on generic assign expression
	sta blink_global_phase
	lda vertical_scroll_start_direction
	; Calling storevariable on generic assign expression
	sta vertical_scroll_direction
	lda #$0
	; Calling storevariable on generic assign expression
	sta show_stage
	lda #$1
	; Calling storevariable on generic assign expression
	sta flat_color
	lda #$0
	; Calling storevariable on generic assign expression
	sta radial_anchor
	; Calling storevariable on generic assign expression
	sta radial_phase
	; Calling storevariable on generic assign expression
	sta radial_scroll_counter
	; Calling storevariable on generic assign expression
	sta radial_update_active
	; Calling storevariable on generic assign expression
	sta radial_slice
	; Calling storevariable on generic assign expression
	sta rotating_lines_counter
	; Calling storevariable on generic assign expression
	sta rotating_lines_step
	; Calling storevariable on generic assign expression
	sta rotating_lines_direction
	lda rotating_lines_speed
	; Calling storevariable on generic assign expression
	sta rotating_speed_current
	lda #$0
	; Calling storevariable on generic assign expression
	sta rotating_move_enabled
	; Calling storevariable on generic assign expression
	sta rotating_move_offset
	; Calling storevariable on generic assign expression
	sta rotating_move_direction
	; Calling storevariable on generic assign expression
	sta rotating_scroll_phase
	; Calling storevariable on generic assign expression
	sta final23_scroll_phase
	; Calling storevariable on generic assign expression
	sta final24_scroll_phase
	; Calling storevariable on generic assign expression
	sta final25_scroll_phase
	; Calling storevariable on generic assign expression
	sta rotating_bin_rows_left
	; Calling storevariable on generic assign expression
	sta rotating_bin_mirror
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_index
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_counter
	; Calling storevariable on generic assign expression
	sta radial_anchor_motion_enabled
	; Calling storevariable on generic assign expression
	sta anim_sequence_started
	; Calling storevariable on generic assign expression
	sta anim_active
	; Calling storevariable on generic assign expression
	sta anim_start_pending
	; Calling storevariable on generic assign expression
	sta anim_start_delay_counter
	; Calling storevariable on generic assign expression
	sta anim_combo_stage
	; Calling storevariable on generic assign expression
	sta anim_combo_period_counter
	; Calling storevariable on generic assign expression
	sta anim_counter
	; Calling storevariable on generic assign expression
	sta anim_active
	
; // RESET DEL FINAL AUTOMATICO
	; Calling storevariable on generic assign expression
	sta sid_play_count_lo
	; Calling storevariable on generic assign expression
	sta sid_play_count_hi
	; Calling storevariable on generic assign expression
	sta sid_end_state
	; Calling storevariable on generic assign expression
	sta sid_tail_counter
	; Calling storevariable on generic assign expression
	sta demo_finished
	; Calling storevariable on generic assign expression
	sta basic_return_counter
	; Calling storevariable on generic assign expression
	sta scroll_end_armed
	; Calling storevariable on generic assign expression
	sta final_center_hold_active
	; Binary clause Simplified: LESS
	lda sid_tail_frames
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock2285
MainProgram_ctb2283: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta sid_tail_frames
MainProgram_edblock2285
	lda sid_end_play_lo
	; Calling storevariable on generic assign expression
	sta scroll_end_trigger_lo
	lda sid_end_play_hi
	; Calling storevariable on generic assign expression
	sta scroll_end_trigger_hi
        lda scroll_end_trigger_lo
        sec
        sbc scroll_end_advance_lo
        sta scroll_end_trigger_lo
        lda scroll_end_trigger_hi
        sbc scroll_end_advance_hi
        sta scroll_end_trigger_hi
    
	lda scroll_end_trigger_lo
	; Calling storevariable on generic assign expression
	sta scroll_turbo_trigger_lo
	lda scroll_end_trigger_hi
	; Calling storevariable on generic assign expression
	sta scroll_turbo_trigger_hi
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_turbo_lead_lo
	; Calling storevariable on generic assign expression
	sta scroll_turbo_lead_hi
	; Calling storevariable on generic assign expression
	sta scroll_turbo_stage_plays
        ldx scroll_turbo_final_seconds
turbo_time_calc_loop:
        clc
        lda scroll_turbo_lead_lo
        adc #50
        sta scroll_turbo_lead_lo
        lda scroll_turbo_lead_hi
        adc #0
        sta scroll_turbo_lead_hi
        clc
        lda scroll_turbo_stage_plays
        adc #5
        sta scroll_turbo_stage_plays
        dex
        bne turbo_time_calc_loop
        lda scroll_turbo_trigger_lo
        sec
        sbc scroll_turbo_lead_lo
        sta scroll_turbo_trigger_lo
        lda scroll_turbo_trigger_hi
        sbc scroll_turbo_lead_hi
        sta scroll_turbo_trigger_hi
    
	; RasterIRQ : Hook a procedure
	lda #$0
	sta $d012
	lda #<SidRasterIRQ
	sta $fffe
	lda #>SidRasterIRQ
	sta $ffff
	asl $d019
	cli
	; Enable raster IRQ
	lda $d01a
	ora #$01
	sta $d01a
	lda #$1B
	sta $d011
MainProgram_while2288
MainProgram_loopstart2292
	; Binary clause Simplified: NOTEQUALS
	clc
	lda #$1
	; cmp #$00 ignored
	beq MainProgram_localfailed3801
	jmp MainProgram_ctb2289
MainProgram_localfailed3801
	jmp MainProgram_edblock2291
MainProgram_ctb2289: ;Main true block ;keep 
	
; // | >>> LOOP PRINCIPAL                                                          |
	jsr WaitVBlank
	
; // ESC emulador / RUN-STOP C64: salida inmediata a BASIC.
	jsr ChequearEscape
	
; // Teclas 0..9: ChequearEscape solo registra el pedido; ya no
; // ejecutamos el cambio antes de actualizar la animacion.
; // FIX18:
; // PAL-B / PAL-N ejecutan siempre, igual que el master.
; // NTSC consume COMO MAXIMO un tick visual por frame fisico.
; // Los frames extra de 60 Hz sirven para vaciar backlog sin tearing.
	lda #$1
	; Calling storevariable on generic assign expression
	sta demo_visual_do_tick
	; Binary clause Simplified: LESS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$3;keep
	bcs MainProgram_edblock3806
MainProgram_ctb3804: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta demo_visual_do_tick
	; Binary clause Simplified: GREATEREQUAL
	lda demo_logic_tick
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcc MainProgram_edblock3811
MainProgram_ctb3809: ;Main true block ;keep 
	; Test Inc dec D
	dec demo_logic_tick
	lda #$1
	; Calling storevariable on generic assign expression
	sta demo_visual_do_tick
MainProgram_edblock3811
MainProgram_edblock3806
	; Binary clause Simplified: EQUALS
	lda basic_return_counter
	; Compare with pure num / var optimization
	cmp #$ff;keep
	bne MainProgram_edblock3816
MainProgram_ctb3814: ;Main true block ;keep 
	
; // OUTRO ONLY: its loader disables the music/raster IRQ, so NTSC's
; // SID-driven tick queue no longer advances. Use WaitVBlank here.
	lda #$1
	; Calling storevariable on generic assign expression
	sta demo_visual_do_tick
MainProgram_edblock3816
	; Binary clause Simplified: EQUALS
	lda demo_visual_do_tick
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_localfailed3822
	jmp MainProgram_ctb3819
MainProgram_localfailed3822
	jmp MainProgram_edblock3821
MainProgram_ctb3819: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda sid_end_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_edblock3827
MainProgram_ctb3825: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda scroll_end_armed
	; cmp #$00 ignored
	bne MainProgram_edblock3832
MainProgram_ctb3830: ;Main true block ;keep 
	; Binary clause Simplified: GREATER
	lda sid_play_count_hi
	; Compare with pure num / var optimization
	cmp scroll_end_trigger_hi;keep
	bcc MainProgram_eblock3836
	beq MainProgram_eblock3836
MainProgram_ctb3835: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_end_armed
	jmp MainProgram_edblock3837
MainProgram_eblock3836
	; Binary clause Simplified: EQUALS
	lda sid_play_count_hi
	; Compare with pure num / var optimization
	cmp scroll_end_trigger_hi;keep
	bne MainProgram_edblock3843
MainProgram_ctb3841: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda sid_play_count_lo
	; Compare with pure num / var optimization
	cmp scroll_end_trigger_lo;keep
	bcc MainProgram_edblock3848
MainProgram_ctb3846: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_end_armed
MainProgram_edblock3848
MainProgram_edblock3843
MainProgram_edblock3837
MainProgram_edblock3832
MainProgram_edblock3827
	; Binary clause Simplified: LESS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$3;keep
	bcs MainProgram_edblock3853
MainProgram_ctb3851: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$18;keep
	bcs MainProgram_edblock3858
MainProgram_ctb3856: ;Main true block ;keep 
	
; // Only NTSC: an armed time trigger must NOT truncate a visual stage.
; // Last ascending pass from below is stage 24 (0-based stages 0..25).
; // At stage 23's bottom boundary allow the transition to stage 24;
; // re-arm during stage 24 so the original top-boundary exit completes it.
; // The IRQ also leaves demo_finished clear for NTSC when SID PLAY ends.
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_end_armed
MainProgram_edblock3858
MainProgram_edblock3853
	; Binary clause Simplified: EQUALS
	lda demo_finished
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_localfailed3864
	jmp MainProgram_ctb3861
MainProgram_localfailed3864
	jmp MainProgram_eblock3862
MainProgram_ctb3861: ;Main true block ;keep 
	; Binary clause Simplified: NOTEQUALS
	lda basic_return_counter
	; Compare with pure num / var optimization
	cmp #$ff;keep
	beq MainProgram_eblock3868
MainProgram_ctb3867: ;Main true block ;keep 
	
; // OUTRO STAGE 1: preserve the approved ~1 s black pause.
; // $FF is a one-time latch; never re-black the loaded artwork.
; // Regular main loop continues to poll RUN/STOP above.
	lda #$0
	; Calling storevariable on generic assign expression
	sta vic_border
	; Calling storevariable on generic assign expression
	sta vic_fondo
	lda #$7
	; Calling storevariable on generic assign expression
	sta vic_d011
	; Binary clause Simplified: LESS
	lda basic_return_counter
	; Compare with pure num / var optimization
	cmp basic_return_delay_frames;keep
	bcs MainProgram_eblock3873
MainProgram_ctb3872: ;Main true block ;keep 
	; Test Inc dec D
	inc basic_return_counter
	jmp MainProgram_edblock3874
MainProgram_eblock3873
	jsr FinalizarDemoEnBasic
	jsr InicializarOutroMar
	lda #$ff
	; Calling storevariable on generic assign expression
	sta basic_return_counter
MainProgram_edblock3874
	jmp MainProgram_edblock3869
MainProgram_eblock3868
	jsr ActualizarOutroMar
MainProgram_edblock3869
	jmp MainProgram_edblock3863
MainProgram_eblock3862
	lda #$0
	; Calling storevariable on generic assign expression
	sta scroll_coarse_event
	; Calling storevariable on generic assign expression
	sta scroll_update_now
	; Binary clause Simplified: EQUALS
	lda scroll_sid_link
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_eblock3881
MainProgram_ctb3880: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda scroll_fullspeed
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_eblock3886
MainProgram_ctb3885: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_update_now
	jmp MainProgram_edblock3887
MainProgram_eblock3886
                        lda scroll_phase
                        clc
                        adc scroll_phase_step
                        sta scroll_phase
                        bcc scroll_phase_no_carry
                        lda #1
                        sta scroll_update_now
                        jmp scroll_phase_done
scroll_phase_no_carry:
                        lda #0
                        sta scroll_update_now
scroll_phase_done:
                    
MainProgram_edblock3887
	jmp MainProgram_edblock3882
MainProgram_eblock3881
	; Test Inc dec D
	inc speed_counter
	; Binary clause Simplified: GREATEREQUAL
	lda speed_counter
	; Compare with pure num / var optimization
	cmp scroll_speed;keep
	bcc MainProgram_edblock3894
MainProgram_ctb3892: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta speed_counter
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_update_now
MainProgram_edblock3894
MainProgram_edblock3882
	; Binary clause Simplified: NOTEQUALS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$3;keep
	beq MainProgram_edblock3899
MainProgram_ctb3897: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$17;keep
	bcc MainProgram_edblock3904
MainProgram_ctb3902: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$19;keep
	bcs MainProgram_edblock3909
MainProgram_ctb3907: ;Main true block ;keep 
	
; // NTSC stages 23/24 and Drean stages 23/24 update every visual tick.
; // Drean-only diagnostic: also update stage 25 each tick at speed 4.
; // PAL-B and NTSC stage 25 keep their original cadence.
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_update_now
MainProgram_edblock3909
MainProgram_edblock3904
MainProgram_edblock3899
	; Binary clause Simplified: EQUALS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$4;keep
	bne MainProgram_edblock3914
MainProgram_ctb3912: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$19;keep
	bne MainProgram_edblock3919
MainProgram_ctb3917: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_update_now
MainProgram_edblock3919
MainProgram_edblock3914
	; Binary clause Simplified: EQUALS
	lda scroll_update_now
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_localfailed3925
	jmp MainProgram_ctb3922
MainProgram_localfailed3925
	jmp MainProgram_edblock3924
MainProgram_ctb3922: ;Main true block ;keep 
	; 8 bit binop
	; Add/sub where right value is constant number
	lda scroll_step
	clc
	adc scroll_turbo_base_extra
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$5;keep
	bne MainProgram_edblock3930
MainProgram_ctb3928: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda stage5_scroll_phase
	; Compare with pure num / var optimization
	cmp #$3;keep
	bne MainProgram_eblock3934
MainProgram_ctb3933: ;Main true block ;keep 
	
; // STAGE 5 / DEGRADE HORIZONTAL UNICO / RETRASO MINIMO
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	lda #$0
	; Calling storevariable on generic assign expression
	sta stage5_scroll_phase
	jmp MainProgram_edblock3935
MainProgram_eblock3934
	lda #$2
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	; Test Inc dec D
	inc stage5_scroll_phase
MainProgram_edblock3935
MainProgram_edblock3930
                    pha
                    txa
                    pha
                    tya
                    pha
                    jsr $EFE8
                    lda show_stage
                    cmp #11
                    bcc s12_speed_done
                    cmp #13
                    bcs s12_speed_done
                    ldx rotating_scroll_phase
                    // NTSC OLD/NORMAL (models 1/2): constant 2-pixel rotating steps.
                    // PAL-B and Drean keep their original slow phases 4 and 7.
                    lda detected_machine
                    cmp #3
                    bcc s12_speed_fast
                    cpx #4
                    beq s12_speed_slow
                    cpx #7
                    beq s12_speed_slow
s12_speed_fast:
                    lda #2
                    jmp s12_phase_advance
s12_speed_slow:
                    lda #1
s12_phase_advance:
                    inx
                    cpx #8
                    bne s12_phase_store
                    ldx #0
s12_phase_store:
                    stx rotating_scroll_phase
                    sta scroll_step_effective
s12_speed_done:
                    pla
                    tay
                    pla
                    tax
                    pla
                
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$17;keep
	bne MainProgram_edblock3941
MainProgram_ctb3939: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda final23_scroll_phase
	; cmp #$00 ignored
	bne MainProgram_eblock3945
MainProgram_ctb3944: ;Main true block ;keep 
	
; // STAGE 12: scroll fraccionario ligeramente acelerado, sin mover inicio.
; // Stage 11 INTACTA: 2,2,1,2,2,1,2,1.
; // Stage 12:        2,2,2,2,2,1,2,1 (+1 pixel cada 8 updates).
; // Mismo contador 0..7, asm compacto para no crecer MAIN.
	lda #$2
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	lda #$1
	; Calling storevariable on generic assign expression
	sta final23_scroll_phase
	jmp MainProgram_edblock3946
MainProgram_eblock3945
	lda final_circular_fast_step
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	; Test Inc dec D
	inc final23_scroll_phase
	; Binary clause Simplified: GREATEREQUAL
	lda final23_scroll_phase
	; Compare with pure num / var optimization
	cmp #$3;keep
	bcc MainProgram_edblock3952
MainProgram_ctb3950: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta final23_scroll_phase
MainProgram_edblock3952
MainProgram_edblock3946
MainProgram_edblock3941
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$18;keep
	bne MainProgram_edblock3957
MainProgram_ctb3955: ;Main true block ;keep 
	lda final_circular_fast_step
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
MainProgram_edblock3957
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$19;keep
	bne MainProgram_edblock3962
MainProgram_ctb3960: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$3;keep
	bcs MainProgram_eblock3966
MainProgram_ctb3965: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	clc
	lda final25_scroll_phase
	; cmp #$00 ignored
	bne MainProgram_eblock3971
MainProgram_ctb3970: ;Main true block ;keep 
	
; // FIX21: PAL-B / PAL-N conservan step 3 original.
; // NTSC recupera solo en la ultima escena alternando 3/4,
; // promedio 3.5 pixels por tick visual.
	lda final_circular_fast_step
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	lda #$1
	; Calling storevariable on generic assign expression
	sta final25_scroll_phase
	jmp MainProgram_edblock3972
MainProgram_eblock3971
	; 8 bit binop
	; Add/sub where right value is constant number
	lda final_circular_fast_step
	clc
	adc #$1
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
	lda #$0
	; Calling storevariable on generic assign expression
	sta final25_scroll_phase
MainProgram_edblock3972
	jmp MainProgram_edblock3967
MainProgram_eblock3966
	lda final_circular_fast_step
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
MainProgram_edblock3967
MainProgram_edblock3962
	; Binary clause Simplified: EQUALS
	lda scroll_sid_link
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_edblock3979
MainProgram_ctb3977: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda scroll_turbo_enabled
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_edblock3984
MainProgram_ctb3982: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda scroll_turbo_frac_step
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcc MainProgram_edblock3989
MainProgram_ctb3987: ;Main true block ;keep 
                                lda scroll_turbo_phase
                                clc
                                adc scroll_turbo_frac_step
                                sta scroll_turbo_phase
                                bcc scroll_turbo_no_extra_pixel
                                inc scroll_step_effective
scroll_turbo_no_extra_pixel:
                            
MainProgram_edblock3989
MainProgram_edblock3984
MainProgram_edblock3979
	; Binary clause Simplified: GREATER
	lda scroll_step_effective
	; Compare with pure num / var optimization
	cmp scroll_turbo_max_step;keep
	bcc MainProgram_edblock3994
	beq MainProgram_edblock3994
MainProgram_ctb3992: ;Main true block ;keep 
	lda scroll_turbo_max_step
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
MainProgram_edblock3994
	; Binary clause Simplified: LESS
	lda scroll_step_effective
	; Compare with pure num / var optimization
	cmp #$1;keep
	bcs MainProgram_edblock3999
MainProgram_ctb3997: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
MainProgram_edblock3999
                    lda detected_machine
                    cmp #$03
                    bcs ntsc_visual_minus_done
                    nop
                    nop
                    lda ntsc_visual_phase
                    clc
                    adc scroll_step_effective
                    cmp #20
                    bcc ntsc_visual_minus_store
                    sbc #20
                    dec scroll_step_effective
ntsc_visual_minus_store:
                    sta ntsc_visual_phase
ntsc_visual_minus_done:
                
                    lda $8BBF
                    cmp #$04
                    bne drean_visual_bonus_done
                    lda drean_visual_phase
                    clc
                    adc scroll_step_effective
                    cmp #200
                    bcc drean_visual_bonus_store
                    sbc #200
                    dec scroll_step_effective
drean_visual_bonus_store:
                    sta drean_visual_phase
drean_visual_bonus_done:
                
	; Binary clause Simplified: LESS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$3;keep
	bcs MainProgram_edblock4004
MainProgram_ctb4002: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$17;keep
	bcc MainProgram_edblock4009
MainProgram_ctb4007: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$19;keep
	bcs MainProgram_edblock4014
MainProgram_ctb4012: ;Main true block ;keep 
	
; // NTSC OLD and NORMAL (models 1/2): visual correction -5% (one pixel per 20 source pixels).
; // Same code for both NTSC systems. Their 37/45 and 31/37 tick clocks stay independent.
; // Machine detection yields 1..4 before demo scroll runs; machine 0 never reaches this routine.
; // Two NOP bytes retain MAIN layout; stage 23/24 late override remains unchanged.
; // DREAN VISUAL-ONLY TEST: -1 pixel / 200 BASE pixels (-0.5%).
; // SID IRQ, play count, music pitch, original speed ramps UNCHANGED.
; // Accumulate AFTER existing stage/turbo calculations; occasionally use 0 pixels.
; // Only PHYSICAL PAL-N (marker $8BBF=4). Aliased PAL-B (marker=3) skips this.
; // NTSC stages 23/24: approved trial at 5 pixels per update.
	lda #$5
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
MainProgram_edblock4014
MainProgram_edblock4009
MainProgram_edblock4004
	; Binary clause Simplified: EQUALS
	lda detected_machine
	; Compare with pure num / var optimization
	cmp #$4;keep
	bne MainProgram_edblock4019
MainProgram_ctb4017: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$17;keep
	bcc MainProgram_edblock4024
MainProgram_ctb4022: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$1a;keep
	bcs MainProgram_edblock4029
MainProgram_ctb4027: ;Main true block ;keep 
	
; // Drean PAL-N ONLY: test stages 23/24/25 at 4 pixels per visual tick.
; // Stage 25 is the additional downward scene with static characters.
; // PAL-B and NTSC stay unchanged.
	lda #$4
	; Calling storevariable on generic assign expression
	sta scroll_step_effective
MainProgram_edblock4029
MainProgram_edblock4024
MainProgram_edblock4019
	
; // STAGE 13 / SCROLL FANTASMA
	lda #$0
	; Calling storevariable on generic assign expression
	sta stage13_consumed_update
                    jsr $FFC8
                
	; Binary clause Simplified: EQUALS
	lda show_stage
	; Compare with pure num / var optimization
	cmp #$d;keep
	bne MainProgram_edblock4034
MainProgram_ctb4032: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda stage13_static_active
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_edblock4039
MainProgram_ctb4037: ;Main true block ;keep 
	
; // PRUEBA GLOBAL +2%: solo JSR (3 bytes) en MAIN; motor en $8B10.
; // Despues de overrides 23-25, antes de consumir paso y cambiar raster.
	lda #$1
	; Calling storevariable on generic assign expression
	sta stage13_consumed_update
	; 8 bit binop
	; Add/sub where right value is constant number
	lda stage13_ghost_fine_scroll
	clc
	adc scroll_step_effective
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta stage13_ghost_fine_scroll
	; Binary clause Simplified: GREATEREQUAL
	; Compare with pure num / var optimization
	cmp #$8;keep
	bcc MainProgram_edblock4044
MainProgram_ctb4042: ;Main true block ;keep 
	; Optimizer: a = a +/- b
	; Load16bitvariable : stage13_ghost_fine_scroll
	lda stage13_ghost_fine_scroll
	sec
	sbc #$8
	sta stage13_ghost_fine_scroll
	; Binary clause Simplified: LESSEQUAL
	lda stage13_ghost_next_line
	; Compare with pure num / var optimization
	cmp limit_down;keep
	beq MainProgram_ctb4047
	bcs MainProgram_eblock4048
MainProgram_ctb4047: ;Main true block ;keep 
	
; // Ultimo blink del Stage 13 = NEGRO.
	lda #$8
	; Calling storevariable on generic assign expression
	sta blink_global_phase
	lda #$0
	; Calling storevariable on generic assign expression
	sta blink_global_counter
	jsr AplicarBlinkGlobal
	jsr SalirStage13Centro
	jmp MainProgram_edblock4049
MainProgram_eblock4048
	; Test Inc dec D
	dec stage13_ghost_next_line
MainProgram_edblock4049
MainProgram_edblock4044
MainProgram_edblock4039
MainProgram_edblock4034
	; Binary clause Simplified: EQUALS
	clc
	lda stage13_consumed_update
	; cmp #$00 ignored
	bne MainProgram_localfailed4056
	jmp MainProgram_ctb4053
MainProgram_localfailed4056
	jmp MainProgram_edblock4055
MainProgram_ctb4053: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda direction
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_localfailed4062
	jmp MainProgram_ctb4059
MainProgram_localfailed4062
	jmp MainProgram_eblock4060
MainProgram_ctb4059: ;Main true block ;keep 
	; Binary clause Simplified: LESS
	lda fine_scroll
	; Compare with pure num / var optimization
	cmp scroll_step_effective;keep
	bcs MainProgram_eblock4066
MainProgram_ctb4065: ;Main true block ;keep 
	; 8 bit binop
	; Add/sub where right value is constant number
	; 8 bit binop
	; Add/sub where right value is constant number
	lda fine_scroll
	clc
	adc #$8
	 ; end add / sub var with constant
	sec
	sbc scroll_step_effective
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta fine_scroll
	; 8 bit binop
	; Add/sub where right value is constant number
	lda #$10
	clc
	adc fine_scroll
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta vic_d011
	; Binary clause Simplified: GREATEREQUAL
	lda next_line
	; Compare with pure num / var optimization
	cmp limit_up;keep
	bcc MainProgram_eblock4071
MainProgram_ctb4070: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda scroll_end_armed
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_eblock4076
MainProgram_ctb4075: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta demo_finished
	lda #$7
	; Calling storevariable on generic assign expression
	sta fine_scroll
	lda #$17
	; Calling storevariable on generic assign expression
	sta vic_d011
	jmp MainProgram_edblock4077
MainProgram_eblock4076
	jsr EventoPantallaNegra
	lda #$0
	; Calling storevariable on generic assign expression
	sta direction
	lda #$7
	; Calling storevariable on generic assign expression
	sta fine_scroll
	lda #$17
	; Calling storevariable on generic assign expression
	sta vic_d011
	jsr PrepararBufferAbajo
MainProgram_edblock4077
	jmp MainProgram_edblock4072
MainProgram_eblock4071
	jsr DesplazarArriba
MainProgram_edblock4072
	jmp MainProgram_edblock4067
MainProgram_eblock4066
	; 8 bit binop
	; Add/sub where right value is constant number
	lda fine_scroll
	sec
	sbc scroll_step_effective
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta fine_scroll
	; 8 bit binop
	; Add/sub where right value is constant number
	lda #$10
	clc
	adc fine_scroll
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta vic_d011
MainProgram_edblock4067
	jmp MainProgram_edblock4061
MainProgram_eblock4060
	; 8 bit binop
	; Add/sub where right value is constant number
	lda fine_scroll
	clc
	adc scroll_step_effective
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta fine_scroll
	; Binary clause Simplified: GREATEREQUAL
	; Compare with pure num / var optimization
	cmp #$8;keep
	bcc MainProgram_eblock4085
MainProgram_ctb4084: ;Main true block ;keep 
	; Optimizer: a = a +/- b
	; Load16bitvariable : fine_scroll
	lda fine_scroll
	sec
	sbc #$8
	sta fine_scroll
	; Binary clause Simplified: LESSEQUAL
	lda next_line
	; Compare with pure num / var optimization
	cmp limit_down;keep
	beq MainProgram_ctb4089
	bcs MainProgram_eblock4090
MainProgram_ctb4089: ;Main true block ;keep 
	; Binary clause Simplified: EQUALS
	lda scroll_end_armed
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_eblock4095
MainProgram_ctb4094: ;Main true block ;keep 
	lda #$1
	; Calling storevariable on generic assign expression
	sta demo_finished
	lda #$7
	; Calling storevariable on generic assign expression
	sta fine_scroll
	lda #$17
	; Calling storevariable on generic assign expression
	sta vic_d011
	jmp MainProgram_edblock4096
MainProgram_eblock4095
	jsr EventoPantallaNegra
	lda #$1
	; Calling storevariable on generic assign expression
	sta direction
	; 8 bit binop
	; Add/sub where right value is constant number
	lda #$7
	sec
	sbc scroll_step_effective
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta fine_scroll
	; 8 bit binop
	; Add/sub where right value is constant number
	lda #$10
	clc
	adc fine_scroll
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta vic_d011
	jsr PrepararBufferArriba
MainProgram_edblock4096
	jmp MainProgram_edblock4091
MainProgram_eblock4090
	; 8 bit binop
	; Add/sub where right value is constant number
	lda #$10
	clc
	adc fine_scroll
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta vic_d011
	jsr DesplazarAbajo
MainProgram_edblock4091
	jmp MainProgram_edblock4086
MainProgram_eblock4085
	; 8 bit binop
	; Add/sub where right value is constant number
	lda #$10
	clc
	adc fine_scroll
	 ; end add / sub var with constant
	; Calling storevariable on generic assign expression
	sta vic_d011
MainProgram_edblock4086
MainProgram_edblock4061
MainProgram_edblock4055
MainProgram_edblock3924
	jsr RevisarFinalCentrado
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_edblock4104
MainProgram_ctb4102: ;Main true block ;keep 
	jsr ActualizarBlinkStage13Constante
	jsr ActualizarBlinkGlobal
MainProgram_edblock4104
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$6;keep
	bne MainProgram_edblock4109
MainProgram_ctb4107: ;Main true block ;keep 
	jsr ActualizarScrollDegradeVertical
MainProgram_edblock4109
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$7;keep
	bne MainProgram_edblock4114
MainProgram_ctb4112: ;Main true block ;keep 
	jsr ActualizarDegradeRadial
MainProgram_edblock4114
	; Binary clause Simplified: EQUALS
	lda color_mode
	; Compare with pure num / var optimization
	cmp #$8;keep
	bne MainProgram_edblock4119
MainProgram_ctb4117: ;Main true block ;keep 
	jsr ActualizarLineasRotatorias
MainProgram_edblock4119
	jsr ActualizarInicioAnimacionPETSCII
	; Test Inc dec D
	inc anim_counter
	; Binary clause Simplified: EQUALS
	lda anim_active
	; Compare with pure num / var optimization
	cmp #$1;keep
	bne MainProgram_edblock4124
MainProgram_ctb4122: ;Main true block ;keep 
	; Binary clause Simplified: GREATEREQUAL
	lda anim_counter
	; Compare with pure num / var optimization
	cmp anim_speed;keep
	bcc MainProgram_edblock4129
MainProgram_ctb4127: ;Main true block ;keep 
	lda #$0
	; Calling storevariable on generic assign expression
	sta anim_counter
	jsr AnimarCaracterIndependiente
MainProgram_edblock4129
MainProgram_edblock4124
MainProgram_edblock3863
MainProgram_edblock3821
	; Binary clause Simplified: EQUALS
	clc
	lda demo_finished
	; cmp #$00 ignored
	bne MainProgram_edblock4134
MainProgram_ctb4132: ;Main true block ;keep 
	; Binary clause Simplified: NOTEQUALS
	lda basic_return_counter
	; Compare with pure num / var optimization
	cmp #$ff;keep
	beq MainProgram_edblock4139
MainProgram_ctb4137: ;Main true block ;keep 
	
; // FIX18: demo_visual_do_tick
; // Palette worker DESPUES del scroll: 64 bytes maximo por cuadro.
; // Mantener fuera de SYSINFO, pantalla final y OUTRO.
	jsr AlternarPaletasDemo
MainProgram_edblock4139
MainProgram_edblock4134
	jmp MainProgram_while2288
MainProgram_edblock2291
MainProgram_loopend2293
main_block_end_
	; End of program
	; Ending memory block at $5000
EndBlock5000:
	org $8000
StartBlock8000:
	; Starting new memory block at $8000
outro_restart_charset_patch
	incbin	 "C:/FPRICO/FPFINAL///outro_restart_charset_patch.bin"
end_incbin_outro_restart_charset_patch
EndBlock8000:
	org $811e
StartBlock811e:
	; Starting new memory block at $811e
demo_palette_helper
	incbin	 "C:/FPRICO/FPFINAL///demo_palette_helper.bin"
end_incbin_demo_palette_helper
EndBlock811e:
	org $8400
StartBlock8400:
	; Starting new memory block at $8400
intro_ocean_audio
	incbin	 "C:/FPRICO/FPFINAL///intro_ocean_audio.bin"
end_incbin_intro_ocean_audio
EndBlock8400:
	org $8b07
StartBlock8b07:
	; Starting new memory block at $8b07
outro_early_audio_init
	incbin	 "C:/FPRICO/FPFINAL///outro_early_audio_init.bin"
end_incbin_outro_early_audio_init
EndBlock8b07:
	org $8b10
StartBlock8b10:
	; Starting new memory block at $8b10
scroll_bonus_2pct
	incbin	 "C:/FPRICO/FPFINAL///scroll_bonus_2pct.bin"
end_incbin_scroll_bonus_2pct
EndBlock8b10:
	org $8bc0
StartBlock8bc0:
	; Starting new memory block at $8bc0
outro_gain_only
	incbin	 "C:/FPRICO/FPFINAL///outro_gain_only.bin"
end_incbin_outro_gain_only
EndBlock8bc0:
	org $8c00
StartBlock8c00:
	; Starting new memory block at $8c00
vicios_music
	incbin	 "C:/FPRICO/FPFINAL///music.bin"
end_incbin_vicios_music
EndBlock8c00:
	org $a0c1
StartBlocka0c1:
	; Starting new memory block at $a0c1
demo_o_outro_probe	dc.b $ad, $98, $3b, $f0, $c, $a9, $ef, $8d
	dc.b $0, $dc, $ad, $1, $dc, $29, $40, $d0
	dc.b $b, $a9, $40, $8d, $98, $3b, $a9, $1
	dc.b $8d, $bd, $38, $60, $4c, $1e, $81, $a9
	dc.b $fd, $8d, $0, $dc, $ad, $1, $dc, $29
	dc.b $20, $8d, $97, $3b, $a9, $ef, $8d, $0
	dc.b $dc, $ad, $1, $dc, $29, $40, $8d, $98
	dc.b $3b, $20, $73, $5a, $60
EndBlocka0c1:
	org $a100
StartBlocka100:
	org $a100
radial_maps_high:
	incbin	 "C:/FPRICO/FPFINAL///radial_maps_high.bin"
end_incbin_radial_maps_high:
EndBlocka100:
	org $b0a0
StartBlockb0a0:
	org $b0a0
rotating_lines_double_data:
	incbin	 "C:/FPRICO/FPFINAL///rotating_lines_double_base.bin"
end_incbin_rotating_lines_double_data:
EndBlockb0a0:
	org $bc60
StartBlockbc60:
	; Starting new memory block at $bc60
intro_ram_tests
	incbin	 "C:/FPRICO/FPFINAL///intro_diagnostics_charset_bankfix.bin"
end_incbin_intro_ram_tests
EndBlockbc60:
	org $bfc0
StartBlockbfc0:
	; Starting new memory block at $bfc0
intro_basic_tests_wrappers
	incbin	 "C:/FPRICO/FPFINAL///intro_basic_tests_wrappers.bin"
end_incbin_intro_basic_tests_wrappers
EndBlockbfc0:
	org $c000
StartBlockc000:
	; Starting new memory block at $c000
ui_helper
	incbin	 "C:/FPRICO/FPFINAL///ui.bin"
end_incbin_ui_helper
EndBlockc000:
	org $c3ab
StartBlockc3ab:
	; Starting new memory block at $c3ab
sid2_visual
	incbin	 "C:/FPRICO/FPFINAL///sid2_visual_safe.bin"
end_incbin_sid2_visual
EndBlockc3ab:
	org $c450
StartBlockc450:
	; Starting new memory block at $c450
intro_basic_tests_visual
	incbin	 "C:/FPRICO/FPFINAL///intro_basic_tests_visual.bin"
end_incbin_intro_basic_tests_visual
EndBlockc450:
	org $c500
StartBlockc500:
	org $c500
char_data:
	incbin	 "C:/FPRICO/FPFINAL///char.bin"
end_incbin_char_data:
EndBlockc500:
	org $ce60
StartBlockce60:
	; Starting new memory block at $ce60
stereo_helper
	incbin	 "C:/FPRICO/FPFINAL///stereo.bin"
end_incbin_stereo_helper
EndBlockce60:
	org $cfea
StartBlockcfea:
	; Starting new memory block at $cfea
intro_basic_tests_bridge
	incbin	 "C:/FPRICO/FPFINAL///intro_basic_tests_bridge.bin"
end_incbin_intro_basic_tests_bridge
EndBlockcfea:
	org $e000
StartBlocke000:
	org $e000
outro_charset_data:
	incbin	 "C:/FPRICO/FPFINAL///outrotileset.bin"
end_incbin_outro_charset_data:
EndBlocke000:
	org $e800
StartBlocke800:
	org $e800
outro_map_data:
	incbin	 "C:/FPRICO/FPFINAL///screenoutrochars.bin"
end_incbin_outro_map_data:
EndBlocke800:
	org $ec00
StartBlockec00:
	org $ec00
outro_colors_data:
	incbin	 "C:/FPRICO/FPFINAL///screenoutrocolors.bin"
end_incbin_outro_colors_data:
EndBlockec00:
	org $efe8
StartBlockefe8:
	; Starting new memory block at $efe8
ntsc_stage5_uniform
	incbin	 "C:/FPRICO/FPFINAL///ntsc_stage5_uniform.bin"
end_incbin_ntsc_stage5_uniform
EndBlockefe8:
	org $f000
StartBlockf000:
	; Starting new memory block at $f000
outro_static_loader
	incbin	 "C:/FPRICO/FPFINAL///outro_static_loader.bin"
end_incbin_outro_static_loader
EndBlockf000:
	org $f0c1
StartBlockf0c1:
	; Starting new memory block at $f0c1
outro_scroll_decode_a
	incbin	 "C:/FPRICO/FPFINAL///outro_scroll_decode_a.bin"
end_incbin_outro_scroll_decode_a
EndBlockf0c1:
	org $f100
StartBlockf100:
	; Starting new memory block at $f100
outro_sea_pixel_pan
	incbin	 "C:/FPRICO/FPFINAL///outro_sea_pan.bin"
end_incbin_outro_sea_pixel_pan
EndBlockf100:
	org $f1b5
StartBlockf1b5:
	; Starting new memory block at $f1b5
outro_scroll_decode_b
	incbin	 "C:/FPRICO/FPFINAL///outro_scroll_decode_b.bin"
end_incbin_outro_scroll_decode_b
EndBlockf1b5:
	org $f200
StartBlockf200:
	; Starting new memory block at $f200
outro_line25_scroll
	incbin	 "C:/FPRICO/FPFINAL///outro_line25_scroll.bin"
end_incbin_outro_line25_scroll
EndBlockf200:
	org $ffc8
StartBlockffc8:
	; Starting new memory block at $ffc8
palb_uniform_cadence
	incbin	 "C:/FPRICO/FPFINAL///palb_uniform_cadence_safe.bin"
end_incbin_palb_uniform_cadence
EndBlockffc8:

