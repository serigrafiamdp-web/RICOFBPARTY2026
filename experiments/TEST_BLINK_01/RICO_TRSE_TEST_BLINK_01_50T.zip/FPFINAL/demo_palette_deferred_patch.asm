; RicOS Palette Helper - delta de prueba (direcciones absolutas OrgAsm)
; Base exacta: DEMO_INTRO_OUTRO_VOLUMEN_10_RESTAURADO_FADE_80_OUTRO_125_PRUEBA.zip
; Esta fuente documenta SOLO los bloques cambiados; el resto del BIN conserva los bytes base.
; La rutina original de teclado $811E..$81AB, el constructor de mapas
; $81E4..$824A y las tablas $82F7..$8356 no se modifican.
; El worker usa ZP $FA/$FB como ya hacia el helper anterior.
; REQ=$3758, TEMP=$833D, ACTIVE=$8346, MAP=$8347..$8356.
; PHASE=$83F8 (0 idle,1 datos,2 color RAM), TARGET=$83F9, PTR=$83FA/B, LIMIT=$83FC.
; Remapeo datos fijos 63 bytes al iniciar; después 3000 bytes (B0A0..BC57),
; por bloques de 8, y finalmente 1000 color RAM (D800..DBE7) en bloques de 8.
; Cuando $38BE=$FF omite color RAM, exactamente igual que el helper original.
; En N/S se termina cualquier remapeo y se restaura gris antes de reiniciar.
; Fragmentos ASM con .org explicitos y etiquetas; el script de build fija bytes y valida offsets.

; BLOQUE $81AC .. $81AE
    .org $81AC
entry_apply:
    jmp handle  ; $81AC

; BLOQUE $81CE .. $81D0
    .org $81CE
entry_reset:
    jmp reset  ; $81CE

; BLOQUE $8287 .. $82EE
    .org $8287
scanner_init:
    lda #$01  ; $8287
    sta $83F8  ; $8289
    lda #$A0  ; $828C
    sta $83FA  ; $828E
    lda #$B0  ; $8291
    sta $83FB  ; $8293
    rts   ; $8296
handle:
    lda $83F8  ; $8297
    bne run_tick  ; $829A
    lda $3758  ; $829C
    beq handler_end  ; $829F
    cmp $8346  ; $82A1
    beq clear_request  ; $82A4
    sta $833D  ; $82A6
    sta $83F9  ; $82A9
    jsr $81E4  ; $82AC
    lda #$00  ; $82AF
    sta $3758  ; $82B1
    jsr $824B  ; $82B4
run_tick:
    jsr worker  ; $82B7
handler_end:
    rts   ; $82BA
clear_request:
    lda #$00  ; $82BB: target grayscale on repeated digit
    jmp $82A6 ; $82BD: reuse existing old->new remap path (A=0)
    rts   ; $82C0: preserved unreachable byte
reset:
    lda $83F8  ; $82C1
    beq reset_to_default  ; $82C4
drain_old:
    jsr worker  ; $82C6
    lda $83F8  ; $82C9
    bne drain_old  ; $82CC
reset_to_default:
    lda #$00  ; $82CE
    sta $3758  ; $82D0
    sta $833D  ; $82D3
    lda $8346  ; $82D6
    beq reset_end  ; $82D9
    lda #$00  ; $82DB
    sta $83F9  ; $82DD
    jsr $81E4  ; $82E0
    jsr $824B  ; $82E3
drain_reset:
    jsr worker  ; $82E6
    lda $83F8  ; $82E9
    bne drain_reset  ; $82EC
reset_end:
    rts   ; $82EE

; BLOQUE $8357 .. $83F7
    .org $8357
worker:
    lda $83FA  ; $8357
    sta $FA  ; $835A
    lda $83FB  ; $835C
    sta $FB  ; $835F
    lda #$08  ; $8361
    sta $83FC  ; $8363
    lda $83F8  ; $8366
    cmp #$02  ; $8369
    beq color_count  ; $836B
    lda $FA  ; $836D
    cmp #$A0  ; $836F
    bne start_map  ; $8371
    lda $FB  ; $8373
    cmp #$BB  ; $8375
    bne start_map  ; $8377
    lda #$08  ; $8379
    sta $83FC  ; $837B
    jmp start_map  ; $837E
color_count:
    lda $FA  ; $8381
    cmp #$C0  ; $8383
    bne start_map  ; $8385
    lda $FB  ; $8387
    cmp #$DB  ; $8389
    bne start_map  ; $838B
    lda #$08  ; $838D
    sta $83FC  ; $838F
start_map:
    ldy #$00  ; $8392
map_loop:
    lda ($FA),Y  ; $8394
    and #$0F  ; $8396
    tax   ; $8398
    lda $8347,X  ; $8399
    sta ($FA),Y  ; $839C
    iny   ; $839E
    cpy $83FC  ; $839F
    bne map_loop  ; $83A2
    tya   ; $83A4
    clc   ; $83A5
    adc $FA  ; $83A6
    sta $83FA  ; $83A8
    lda $FB  ; $83AB
    adc #$00  ; $83AD
    sta $83FB  ; $83AF
    lda $83F8  ; $83B2
    cmp #$02  ; $83B5
    beq check_color_end  ; $83B7
    lda $83FA  ; $83B9
    cmp #$58  ; $83BC
    bne work_done  ; $83BE
    lda $83FB  ; $83C0
    cmp #$BC  ; $83C3
    bne work_done  ; $83C5
    lda $38BE  ; $83C7
    cmp #$FF  ; $83CA
    beq complete  ; $83CC
    lda #$02  ; $83CE
    sta $83F8  ; $83D0
    lda #$00  ; $83D3
    sta $83FA  ; $83D5
    lda #$D8  ; $83D8
    sta $83FB  ; $83DA
    rts   ; $83DD
check_color_end:
    lda $83FA  ; $83DE
    cmp #$E8  ; $83E1
    bne work_done  ; $83E3
    lda $83FB  ; $83E5
    cmp #$DB  ; $83E8
    bne work_done  ; $83EA
complete:
    lda $83F9  ; $83EC
    sta $8346  ; $83EF
    lda #$00  ; $83F2
    sta $83F8  ; $83F4
work_done:
    rts   ; $83F7
