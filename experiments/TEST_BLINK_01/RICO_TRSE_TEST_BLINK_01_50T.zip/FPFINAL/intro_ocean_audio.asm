; PRUEBA: VOLUMEN RESTAURADO AL NIVEL MITAD, COMPARTIDO INTRO / OUTRO.
; Los valores de envolvente, sus tiempos y amplitudes base permanecen sin tocar.
; La division entera ocurre tras variaciones, retirada y limite de fade.
; Rampa 4 cuadros, cutoff -$20, filtros, rompimiento y musica intactos.
; MASTER INTACTO. La OUTRO comparte ahora este mismo modulo de audio.

; PRUEBA ENVOLVENTE SUAVE: acercamiento continuo 5..11, rompimiento 12,
; espuma aprobada 10->3. NO modificar tiempos, velocidad, SID music o filtro.
; BIN $8400, voz mono/estereo identica en fase local. MASTER INTACTO.

; PRUEBA REVERSIBLE: cutoff INTRO menos $20 en registro alto ($D416).
; Comparar con version natural y prueba -$08. Solo LUT + limites cutoff.
; LUT: max($08, original-$20) para evitar underflow en el mar inicial.
; No tocar frecuencias de osciladores, ruido, volumen, velocidad o LP/LP+BP.
; SID2 solo si detectado. MASTER no modificado. Requiere prueba WinVICE.

; RICOS / FLASH PARTY 2026 - SOLO INTRO: misma rampa, pausa ambiental, fade lento.
; Direccion $8400. Entradas $8400 INIT, $8403 TICK, $8406 OFF.
; A=fase del helper $3A00; X=hardware_profile; ($FB) apunta a SID2.
; Registros A/X/Y y stack preservados; no altera el GATE de ninguna voz.
; Un solo motor; ambas escenas llaman las mismas entradas. El MASTER permanece intacto.

    jmp $397E ; common INIT; ROM-safe shared dispatcher
    jmp $3991 ; common TICK; ROM-safe shared dispatcher
    jmp intro_audio_off
    jmp intro_audio_crest_hold

intro_audio_init:
    pha
    txa
    pha
    tya
    pha
    lda #$00
    sta fade_volume
    sta fade_divider
    sta frame_phase
    sta intro_sid_profile
    sta crest_hold_active
    sta crest_hold_lo
    sta crest_hold_hi
    sta crest_noise_divider
    sta crest_age
    sta crest_foam_divider
    lda #$0A
    sta crest_foam_volume
    lda #$30
    sta tail_smooth_cutoff
    sta foam_retreat_cutoff
    lda #$0D
    sta crest_freq1
    sta crest_freq2
    lda #$C0
    sta crest_cut1
    sta crest_cut2
    lda #$FF
    sta last_phase
    lda #$A7
    sta rng
    lda #$06
    sta wave1_var
    lda #$09
    sta wave2_var
    lda #$00
    sta ambient1_var
    sta ambient2_var
    sta $D415
    lda #$08
    sta $D416
    lda #$24
    sta $D417
    lda #$10
    sta $D418
    ; Voz 2 fuera de LP: espuma constante en el MISMO SID.
    lda #$3A
    sta $D40D
    cpx #$00
    beq intro_init_done
    ldy #$15
    lda #$00
    sta ($FB),y
    iny
    lda #$08
    sta ($FB),y
    iny
    lda #$24
    sta ($FB),y
    iny
    lda #$10
    sta ($FB),y
    ldy #$0D
    lda #$3A
    sta ($FB),y
intro_init_done:
    pla
    tay
    pla
    tax
    pla
    rts

intro_audio_tick:
    pha
    sta frame_phase
    txa
    pha
    sta intro_sid_profile
    tya
    pha
    ; Fade-in REAL mas lento, 0..15 en ~180 cuadros fisicos.
    ; Solo ajusta el techo del volumen: cresta/rampa intactas.
    inc fade_divider
    lda fade_divider
    cmp #$0C
    bne fade_complete
    lda #$00
    sta fade_divider
    lda fade_volume
    cmp #$0F
    bcs fade_complete
    inc fade_volume
fade_complete:
    ; Aleatoriedad lenta: un nuevo parametro SOLO en cada inicio de ola.
    ; SID1 gate inicia en $E0, SID2 en $60 ($3A00 original intacto).
    lda frame_phase
    cmp last_phase
    beq phase_events_done
    cmp #$E0
    bne check_wave2_start
    jsr next_rng
    and #$0F
    sta wave1_var
    lda rng
    and #$03
    clc
    adc #$0B
    sta $D408
check_wave2_start:
    lda frame_phase
    cmp #$60
    bne ambient_rng_check
    lda intro_sid_profile
    beq ambient_rng_check
    jsr next_rng
    and #$0F
    sta wave2_var
    lda rng
    and #$03
    clc
    adc #$0B
    ldy #$08
    sta ($FB),y
ambient_rng_check:
    ; En el lado SIN ola ascendente, variar solo el ruido ambiental.
    ; Cambiar semilla cada cuatro pasos de fase (~32 cuadros con mar lento),
    ; nunca cada frame. Los dos SID tienen variaciones independientes.
    lda frame_phase
    and #$03
    bne ambient_rng_done
    jsr next_rng
    and #$01
    sta ambient1_var
    jsr next_rng
    and #$01
    sta ambient2_var
ambient_rng_done:
phase_events_done:
    lda frame_phase
    sta last_phase
    ; 32 pasos despues del pico: espuma estereo se mezcla suavemente con
    ; la rampa existente. Solo donde hay realmente dos SID.
    lda #$00
    sta stereo_tail_volume
    lda intro_sid_profile
    beq stereo_tail_prepared
    lda frame_phase
    and #$7F
    cmp #$60
    bcc stereo_tail_prepared
    and #$1F
    tax
    lda stereo_tail_volume_lut,x
    sta stereo_tail_volume
    ; Ambos parlantes estan en cutoff $30 al terminar la espuma en esta prueba.
    ; El canal ambiental baja 1 punto cada 5 cuadros hacia $20:
    ; sin reapertura brusca al primer cuadro de la retirada.
    lda frame_phase
    and #$7F
    cmp #$60
    beq stereo_tail_no_step
    inc crest_noise_divider
    lda crest_noise_divider
    cmp #$05
    bne stereo_tail_no_step
    lda #$00
    sta crest_noise_divider
    lda tail_smooth_cutoff
    cmp #$08
    beq stereo_tail_no_step
    dec tail_smooth_cutoff
stereo_tail_no_step:
    lda tail_smooth_cutoff
    sta stereo_tail_cutoff
stereo_tail_prepared:
    ; Leer fase real: antes se sumaba $20 al ULTIMO dato de la LUT.
    ; Ese valor accidental desfasaba el cutoff de SID1.
    lda frame_phase
    clc
    adc #$20
    tax
    lda ocean_cutoff_lut,x
    clc
    adc wave1_var
    bcc cutoff1_ready
    lda #$FF
cutoff1_ready:
    sta $D416
    ; SID1 es el canal ambiental durante la cresta global $E0..$FF.
    lda stereo_tail_volume
    beq cutoff1_end
    lda frame_phase
    bpl cutoff1_end
    lda stereo_tail_cutoff
    sta $D416
cutoff1_end:
    ; SID2: cresta $E0-$EF; gate OFF original en $F0.
    lda intro_sid_profile
    beq intro_update_volumes
    lda frame_phase
    clc
    adc #$A0
    tax
    lda ocean_cutoff_lut,x
    clc
    adc wave2_var
    bcc cutoff2_ready
    lda #$FF
cutoff2_ready:
    ldy #$16
    sta ($FB),y
    ; SID2 es el canal ambiental durante la cresta global $60..$7F.
    lda stereo_tail_volume
    beq cutoff2_end
    lda frame_phase
    bmi cutoff2_end
    lda stereo_tail_cutoff
    sta ($FB),y
cutoff2_end:

intro_update_volumes:
    ; Balance: ola ascendente mas suave, cresta 10/15 (+1 ocasional
    ; por variacion ya existente); ruido ambiental sin cambiar.
    ; Al principio el fade-in limita cualquier volumen de la envolvente.
    lda frame_phase
    clc
    adc #$20                ; SID1: inicio E0 -> 00, cresta 60 -> 80
    tax
    lda ocean_volume_lut,x
    sta volume_target
    ; Fase local C0-FF: espuma ambiental mientras el OTRO SID asciende.
    ; Su aleatoriedad es independiente de la rampa de la ola activa.
    cpx #$C0
    bcc intro_vol1_wave_var
    lda ambient1_var
    jmp intro_vol1_apply_var
intro_vol1_wave_var:
    lda wave1_var
intro_vol1_apply_var:
    and #$01                ; variacion de un paso, sin picos repentinos
    beq intro_vol1_variation_done
    lda volume_target
    cmp #$0C
    bcs intro_vol1_variation_done
    inc volume_target
intro_vol1_variation_done:
    ; La ola izquierda rompe en SID1; la espuma derecha se sostiene
    ; y vuelve al ambiente gradualmente en la cresta de SID2.
    lda stereo_tail_volume
    beq intro_vol1_after_stereo
    lda frame_phase
    bpl intro_vol1_after_stereo
    lda volume_target
    cmp stereo_tail_volume
    bcs intro_vol1_after_stereo
    lda stereo_tail_volume
    sta volume_target
intro_vol1_after_stereo:
    ; La espuma ya bajo DURANTE la pausa de cresta. Evitar una segunda
    ; cresta en el canal anterior al pasar a fase $80/$00.
    jsr intro_limit_old_wave
    jsr intro_apply_retreat
    jsr intro_shape_break_volume
    lda volume_target
    cmp fade_volume
    bcc intro_vol1_below_fade
    lda fade_volume
intro_vol1_below_fade:
    jsr $8BD3 ; OUTRO-only gain helper, baseline unchanged  ; mitad de volumen final; LP / LP+BP intactos
    sta $D418

    lda intro_sid_profile
    beq intro_tick_done
    lda frame_phase
    clc
    adc #$A0                ; SID2: inicio 60 -> 00, cresta E0 -> 80
    tax
    lda ocean_volume_lut,x
    sta volume_target
    cpx #$C0
    bcc intro_vol2_wave_var
    lda ambient2_var
    jmp intro_vol2_apply_var
intro_vol2_wave_var:
    lda wave2_var
intro_vol2_apply_var:
    and #$01
    beq intro_vol2_variation_done
    lda volume_target
    cmp #$0C
    bcs intro_vol2_variation_done
    inc volume_target
intro_vol2_variation_done:
    lda stereo_tail_volume
    beq intro_vol2_after_stereo
    lda frame_phase
    bmi intro_vol2_after_stereo
    lda volume_target
    cmp stereo_tail_volume
    bcs intro_vol2_after_stereo
    lda stereo_tail_volume
    sta volume_target
intro_vol2_after_stereo:
    jsr intro_limit_old_wave
    jsr intro_apply_retreat
    jsr intro_shape_break_volume
    lda volume_target
    cmp fade_volume
    bcc intro_vol2_below_fade
    lda fade_volume
intro_vol2_below_fade:
    jsr $8BD3 ; OUTRO-only gain helper, baseline unchanged  ; mismo medio volumen para SID2
    ldy #$18
    sta ($FB),y
intro_tick_done:
    ; Ultimo ajuste tras la rutina original $3A00: el rompimiento de
    ; AMBOS SID usa ruido y filtro con modulacion independiente.
    ; Esta fase esta retenida cinco segundos; NO arranca otra rampa.
    jsr intro_crest_noise
    pla
    tay
    pla
    tax
    pla
    rts

; La fase local A0-BF es la cola de la ola anterior, pero AHORA
; ya se desvanece durante los 5 segundos de la cresta retenida.
; No dejar que la tabla original recree otra ola a volumen 10.
; Transicion ambiental gradual 4 -> 5 -> 6 -> 7 en C0.
intro_limit_old_wave:
    cpx #$A0
    bcc intro_limit_done
    cpx #$C0
    bcs intro_limit_done
    lda #$04
    cpx #$B0
    bcc intro_limit_compare
    lda #$05
    cpx #$B8
    bcc intro_limit_compare
    lda #$06
intro_limit_compare:
    cmp volume_target
    bcs intro_limit_done
    sta volume_target
intro_limit_done:
    rts

; Limitar el volumen de AMBOS SID al desvanecer: fase local $61-$7F
; equivale a la retirada de uno y al pre-ascenso del contrario.
; En $80 comienza el nuevo ciclo con el nivel ambiental habitual.
intro_apply_retreat:
    lda frame_phase
    and #$7F
    cmp #$60
    bcc intro_retreat_done
    and #$1F
    tax
    lda intro_retreat_lut,x
    cmp volume_target
    bcs intro_retreat_done
    sta volume_target
intro_retreat_done:
    rts

; Quiebre UNICO de 6 cuadros, con dos pasos de filtro (FA / E0).
; Despues la espuma inicia en 10 y decae lentamente hasta 3 DURANTE
; la pausa de cresta; no se mantiene otra rotura artificial 5 segundos.
intro_shape_break_volume:
    lda frame_phase
    and #$7F
    cmp #$60
    bne intro_shape_done
    lda crest_age
    cmp #$06
    bcs intro_shape_foam
    lda #$0C
    sta volume_target
    rts
intro_shape_foam:
    lda crest_foam_volume
    sta volume_target
intro_shape_done:
    rts

; Quiebre: un solo ataque breve y DOS timbres (3 + 3 cuadros).
; Espuma: frecuencia aleatoria distinta para cada SID pero CONSTANTE;
; cutoff interpolado -1 por cuadro y volumen 10 -> 3 cada 24 cuadros.
; Esto elimina los reinicios audibles que antes ocurrian cada 16 cuadros.
intro_crest_noise:
    lda frame_phase
    and #$7F
    cmp #$60
    beq intro_noise_phase_ok
    jmp intro_noise_not_crest
intro_noise_phase_ok:
    lda crest_age
    bne intro_noise_count_age
    ; Una sola asignacion aleatoria al entrar en el rompimiento.
    jsr next_rng
    and #$03
    clc
    adc #$0C
    sta crest_freq1
    jsr next_rng
    and #$03
    clc
    adc #$0C
    sta crest_freq2
    lda #$C0
    sta crest_cut1
    sta crest_cut2
    lda #$0A
    sta crest_foam_volume
    lda #$00
    sta crest_foam_divider
    sta crest_noise_divider
    lda #$30
    sta tail_smooth_cutoff
    sta foam_retreat_cutoff
intro_noise_count_age:
    lda crest_age
    cmp #$07
    bcs intro_noise_foam_tick
    inc crest_age
    jmp intro_noise_apply
intro_noise_foam_tick:
    ; Espuma en un continuo, sin randomizar de nuevo la frecuencia.
    ; Modula textura con el cutoff en resolucion de UN paso/cuadro.
    lda crest_cut1
    cmp #$30
    beq intro_noise_cut1_done
    dec crest_cut1
intro_noise_cut1_done:
    lda crest_cut2
    cmp #$30
    beq intro_noise_cut2_done
    dec crest_cut2
intro_noise_cut2_done:
    inc crest_foam_divider
    lda crest_foam_divider
    cmp #$18
    bne intro_noise_apply
    lda #$00
    sta crest_foam_divider
    lda crest_foam_volume
    cmp #$03
    beq intro_noise_apply
    dec crest_foam_volume
intro_noise_apply:
    ; $3A00 ya actualizo la frecuencia: fijar byte alto estable.
    lda crest_freq1
    sta $D40F
    lda crest_age
    cmp #$07
    bcs intro_cut1_foam
    tax
    lda crest_break_cutoff_lut,x
    jmp intro_cut1_write
intro_cut1_foam:
    lda crest_cut1
intro_cut1_write:
    sta $D416
    lda intro_sid_profile
    beq intro_noise_done
    ldy #$0F
    lda crest_freq2
    sta ($FB),y
    ldy #$16
    lda crest_age
    cmp #$07
    bcs intro_cut2_foam
    tax
    lda crest_break_cutoff_lut,x
    jmp intro_cut2_write
intro_cut2_foam:
    lda crest_cut2
intro_cut2_write:
    sta ($FB),y
    jmp intro_noise_done
intro_noise_not_crest:
    lda #$00
    sta crest_age
    lda #$0A
    sta crest_foam_volume
    ; Solo durante retirada $61-$7F / $E1-$FF, ambos ruidos
    ; quedan estables. El SID que acaba de romper recupera cutoff
    ; gradualmente hacia el valor que tendra al llegar a $80/$00.
    lda frame_phase
    and #$7F
    cmp #$61
    bcc intro_noise_after_retreat
    cmp #$80
    bcs intro_noise_after_retreat
    lda crest_freq1
    sta $D40F
    lda intro_sid_profile
    beq intro_retreat_cut_tick
    ldy #$0F
    lda crest_freq2
    sta ($FB),y
intro_retreat_cut_tick:
    inc crest_foam_divider
    lda crest_foam_divider
    and #$01
    bne intro_retreat_cut_write
    lda foam_retreat_cutoff
    cmp #$9F
    bcs intro_retreat_cut_write
    inc foam_retreat_cutoff
intro_retreat_cut_write:
    lda frame_phase
    bmi intro_retreat_cut_sid2
    lda foam_retreat_cutoff
    sta $D416
    jmp intro_noise_done
intro_retreat_cut_sid2:
    lda intro_sid_profile
    beq intro_noise_done
    ldy #$16
    lda foam_retreat_cutoff
    sta ($FB),y
    jmp intro_noise_done
intro_noise_after_retreat:
    lda #$00
    sta crest_foam_divider
intro_noise_done:
    rts

next_rng:
    lda rng
    asl
    bcc rng_stable
    eor #$1D
rng_stable:
    sta rng
    rts

intro_audio_off:
    pha
    txa
    pha
    tya
    pha
    ; No dejar el filtro activo ni el volumen de fade a medias.
    lda #$00
    sta $D417
    lda #$0F
    sta $D418
    cpx #$00
    beq intro_off_done
    lda #$00
    ldy #$17
    sta ($FB),y
    lda #$0F
    iny
    sta ($FB),y
intro_off_done:
    pla
    tay
    pla
    tax
    pla
    rts

; Entrada publica $8409. Solo se llama cuando la fase es $60/$E0.
; X = detected_machine (0,1,2 PAL / 3,4 NTSC).
; A=0 mientras sostiene la cresta; A=1 en el cuadro de salida.
; No toca ninguna voz ni altera X/Y: el tick normal sigue sonando.
intro_audio_crest_hold:
    lda crest_hold_active
    bne crest_count_down
    lda #$01
    sta crest_hold_active
    cpx #$03
    bcc crest_init_pal
    lda #$34               ; 308 NTSC = 8 originales + 300 extra.
    sta crest_hold_lo
    lda #$01
    sta crest_hold_hi
    jmp crest_count_down
crest_init_pal:
    lda #$02               ; 258 PAL = 8 originales + 250 extra.
    sta crest_hold_lo
    lda #$01
    sta crest_hold_hi
crest_count_down:
    lda crest_hold_lo
    bne crest_dec_lo
    dec crest_hold_hi
crest_dec_lo:
    dec crest_hold_lo
    lda crest_hold_lo
    ora crest_hold_hi
    bne crest_keep_waiting
    lda #$00
    sta crest_hold_active
    lda #$01               ; salir de fase $60/$E0, SIN reiniciar la pausa.
    rts
crest_keep_waiting:
    lda #$00
    rts

; EXPERIMENTO REVERSIBLE: SOLO LOS BITS DE MODO $D418.
; A llega con volumen 0..15; devuelve A = volumen | $30 (LP+BP)
; exclusivamente mientras fase global $60/$E0 permanece en cresta.
; Quiebre + espuma comparten esta fase retenida; en el resto LP original.
; X/Y se conservan, stack balanceado; no modificar fases ni SID routing.
intro_filter_mode:
    pha
    lda frame_phase
    and #$7F
    cmp #$60
    bne intro_filter_lowpass
    pla
    ora #$30
    rts
intro_filter_lowpass:
    pla
    ora #$10
    rts

fade_volume: .byte $00
fade_divider: .byte $00
frame_phase: .byte $00
intro_sid_profile: .byte $00
last_phase: .byte $FF
rng: .byte $A7
wave1_var: .byte $06
wave2_var: .byte $09
ambient1_var: .byte $00 ; variacion independiente en parlante izquierdo
ambient2_var: .byte $00 ; variacion independiente en parlante derecho
volume_target: .byte $00  ; temporal para la amplitud de cada SID
crest_hold_active: .byte $00
crest_hold_lo: .byte $00
crest_hold_hi: .byte $00
stereo_tail_volume: .byte $00
stereo_tail_cutoff: .byte $00
crest_noise_divider: .byte $00
crest_freq1: .byte $0D
crest_freq2: .byte $0D
crest_cut1: .byte $C0
crest_cut2: .byte $C0
crest_age: .byte $00
crest_foam_volume: .byte $0A  ; 10 -> 3 a lo largo de los 5 segundos
crest_foam_divider: .byte $00 ; un descenso cada 24 cuadros
tail_smooth_cutoff: .byte $30 ; espuma ambiental $50 -> $20 en retirada
foam_retreat_cutoff: .byte $30 ; espuma anterior: de $50 a $BF sin salto

; Indice de edad empieza en 1: $FA (edades 1-3) -> $E0 (4-6).
; Desde el cuadro 7 rige la espuma aleatoria que ya gustaba.
; Los 18 bytes restantes conservan tamaño/direcciones del BIN; NO se leen.
crest_break_cutoff_lut:
    .byte $DA,$DA,$DA,$DA,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0
    .byte $C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0

; LUT 256 de cutoff interpolado. La cresta queda antes del GATE OFF
; del MISMO parlante, no del otro SID.
ocean_cutoff_lut:
    .byte $08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08
    .byte $08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08
    .byte $08,$08,$08,$08,$08,$08,$08,$08,$09,$0A,$0B,$0C,$0D,$0E,$0F,$10
    .byte $11,$12,$14,$15,$17,$18,$19,$1B,$1C,$1D,$1F,$20,$22,$23,$24,$26
    .byte $27,$29,$2B,$2C,$2E,$30,$32,$33,$35,$37,$39,$3A,$3C,$3E,$40,$41
    .byte $43,$45,$48,$4A,$4D,$4F,$51,$54,$56,$58,$5B,$5D,$60,$62,$64,$67
    .byte $69,$6C,$6E,$71,$74,$76,$79,$7B,$7E,$81,$83,$86,$89,$8B,$8E,$90
    .byte $93,$97,$9B,$9E,$A2,$A6,$AA,$AE,$B2,$B5,$B9,$BD,$C1,$C5,$C8,$CC
    .byte $D0,$CF,$CE,$CD,$CC,$CB,$CA,$C9,$C8,$C7,$C6,$C5,$C4,$C3,$C2,$C1
    .byte $C0,$BE,$BC,$BA,$B8,$B6,$B4,$B2,$B0,$AD,$AB,$A9,$A7,$A5,$A3,$A1
    .byte $9F,$9D,$9B,$99,$97,$94,$92,$90,$8E,$8C,$8A,$88,$86,$83,$81,$7F
    .byte $7D,$7B,$79,$77,$75,$72,$70,$6E,$6C,$6A,$68,$66,$64,$61,$5F,$5D
    .byte $5B,$59,$57,$55,$53,$50,$4E,$4C,$4A,$48,$46,$44,$42,$3F,$3D,$3B
    .byte $39,$37,$34,$32,$30,$2D,$2B,$28,$26,$24,$21,$1F,$1D,$1A,$18,$15
    .byte $13,$11,$10,$0E,$0C,$0A,$09,$08,$08,$08,$08,$08,$08,$08,$08,$08
    .byte $08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08

; PRUEBA: ascenso 5..11 por 64 fases; quiebre 12 por 6 cuadros; espuma 10.
; Se preservan las tablas base de ambiente, fade y cinco segundos de cresta.
; Una tabla compartida por ambos SID, indexada con desfase de 128.
ocean_volume_lut:
    .byte $04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04
    .byte $04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04
    .byte $04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04
    .byte $04,$04,$04,$04,$04,$04,$04,$04,$05,$05,$05,$05,$05,$05,$05,$05
    .byte $05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$06,$06,$06,$06,$06,$06
    .byte $06,$06,$06,$06,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$08,$08
    .byte $08,$08,$08,$08,$08,$08,$08,$08,$09,$09,$09,$09,$09,$09,$09,$09
    .byte $0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0B,$0B,$0B,$0B,$0B,$0B,$0B,$0B
    .byte $0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A
    .byte $0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$09,$09,$09,$08,$08,$08,$07
    .byte $07,$07,$07,$06,$06,$06,$06,$06,$06,$05,$05,$05,$05,$05,$04,$04
    .byte $07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07
    .byte $07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$08,$08,$08,$08,$08
    .byte $08,$08,$08,$08,$09,$09,$09,$09,$09,$09,$09,$0A,$0A,$0A,$0A,$0A
    .byte $0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A
    .byte $0A,$0A,$0A,$0A,$09,$09,$09,$09,$09,$08,$08,$08,$08,$08,$08,$08

; La tabla de volumen de retirada no produce un SEGUNDO golpe.
; El cutoff de retirada se interpola a un paso por cuadro, no por fase.
stereo_tail_volume_lut:
    .byte $0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A,$0A
    .byte $09,$09,$09,$09,$09,$09,$08,$08,$08,$08,$08,$08,$07,$07,$07,$07
stereo_tail_cutoff_lut:
    .byte $F0,$E9,$E3,$DC,$D5,$CE,$C8,$C1,$BA,$B3,$AD,$A6,$9F,$98,$92,$8B
    .byte $84,$7D,$77,$70,$69,$62,$5C,$55,$4E,$47,$41,$3A,$33,$2C,$26,$1F

; Despues del rompimiento ya llegamos con espuma a volumen 3.
; Mantener la calma y retornar suavemente a ambiente 4 antes de $80.
intro_retreat_lut:
    .byte $03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03
    .byte $03,$03,$03,$03,$03,$03,$03,$03,$04,$04,$04,$04,$04,$04,$04,$04

; PRUEBA VOLUMEN MITAD: ocurre DESPUES de la envolvente y del fade.
; Se aplica a cada SID durante el tick de INTRO; no toca musica, init ni OFF.
; El JMP encadena con el filtro original sin agregar un nivel de stack.
intro_half_volume:
    lsr a                    ; SID 0..15 -> 0..7 (division entera por dos)
    jmp intro_filter_mode   ; OR $10 LP / $30 LP+BP segun fase original
