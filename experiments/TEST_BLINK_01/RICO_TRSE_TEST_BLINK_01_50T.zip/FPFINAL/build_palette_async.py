from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, re

ROOT=Path('/mnt/data')
SOURCE=ROOT/'DEMO_INTRO_OUTRO_VOLUMEN_10_RESTAURADO_FADE_80_OUTRO_125_PRUEBA.zip'
DEST=ROOT/'DEMO_PALETAS_DIFERIDAS_BLOQUES_64_TIMINGS_INTACTOS_PRUEBA.zip'
START=0x811e
END=0x8400

# Bin fixed-address, no TRSE labels or memory addresses beyond $811E..$83FF move.
old=ZipFile(SOURCE).read('demo_palette_helper.bin')
assert len(old)==569 and START+len(old)==0x8357
buf=bytearray(old+bytes(END-(START+len(old))))

OPS={
 'LDA': {'imm':0xA9,'abs':0xAD,'zp':0xA5,'indy':0xB1},
 'STA': {'abs':0x8D,'zp':0x85,'indy':0x91},
 'CMP': {'imm':0xC9,'abs':0xCD},
 'JSR': {'abs':0x20},'JMP':{'abs':0x4C},
 'BEQ':{'rel':0xF0},'BNE':{'rel':0xD0},
 'LDY':{'imm':0xA0},'INY':{'imp':0xC8},'CPY':{'abs':0xCC},
 'CLC':{'imp':0x18},'ADC':{'zp':0x65,'imm':0x69},
 'TAX':{'imp':0xAA},'TYA':{'imp':0x98},'AND':{'imm':0x29},
 'RTS':{'imp':0x60}
}
LEN={'imm':2,'abs':3,'zp':2,'indy':2,'rel':2,'imp':1}
class Block:
 def __init__(self,origin): self.origin=origin;self.pc=origin;self.items=[];self.labels={}
 def mark(self,s): assert s not in self.labels;self.labels[s]=self.pc
 def op(self,m,mode='imp',val=None):
  assert mode in OPS[m] and (val is None)==(mode=='imp'),(m,mode,val)
  self.items.append((self.pc,m,mode,val));self.pc+=LEN[mode]
 def emit(self,glob):
  result=bytearray()
  for at,m,mode,val in self.items:
   result.append(OPS[m][mode]);
   if mode=='imp':continue
   if isinstance(val,str):val=glob[val]
   if mode=='rel':
    dist=val-(at+2);assert -128<=dist<=127,(hex(at),m,dist)
    result.append(dist&255)
   elif mode in ('abs','absx'): result.extend((val&255,(val>>8)&255))
   else:assert 0<=val<=255;result.append(val)
  assert len(result)==self.pc-self.origin
  return bytes(result)

A=Block(0x81ac)
A.mark('entry_apply');A.op('JMP','abs','handle')
B=Block(0x81ce)
B.mark('entry_reset');B.op('JMP','abs','reset')
C=Block(0x8287)
C.mark('scanner_init')
# Called only after original $824B..$8286 remaps the ~63 small LUT bytes.
C.op('LDA','imm',1);C.op('STA','abs',0x83f8)
C.op('LDA','imm',0xa0);C.op('STA','abs',0x83fa)
C.op('LDA','imm',0xb0);C.op('STA','abs',0x83fb)
C.op('RTS')

C.mark('handle')
C.op('LDA','abs',0x83f8)
C.op('BNE','rel','run_tick')
C.op('LDA','abs',0x3758)
C.op('BEQ','rel','handler_end')
C.op('CMP','abs',0x8346)
C.op('BEQ','rel','clear_request')
C.op('STA','abs',0x833d) # temp target used by original map constructor
C.op('STA','abs',0x83f9) # save target while user may queue next key
C.op('JSR','abs',0x81e4) # original old->new mapping table
C.op('LDA','imm',0)
C.op('STA','abs',0x3758)
C.op('JSR','abs',0x824b) # remap small LUT, initialize pointer
C.mark('run_tick');C.op('JSR','abs','worker')
C.mark('handler_end');C.op('RTS')
C.mark('clear_request');C.op('LDA','imm',0);C.op('JMP','abs',0x82a6);C.op('RTS')  # Same digit toggles back to grayscale via apply target

C.mark('reset')
C.op('LDA','abs',0x83f8)
C.op('BEQ','rel','reset_to_default')
C.mark('drain_old')
C.op('JSR','abs','worker')
C.op('LDA','abs',0x83f8)
C.op('BNE','rel','drain_old')
C.mark('reset_to_default')
C.op('LDA','imm',0);C.op('STA','abs',0x3758);C.op('STA','abs',0x833d)
C.op('LDA','abs',0x8346)
C.op('BEQ','rel','reset_end')
C.op('LDA','imm',0);C.op('STA','abs',0x83f9)
C.op('JSR','abs',0x81e4)
C.op('JSR','abs',0x824b)
C.mark('drain_reset')
C.op('JSR','abs','worker')
C.op('LDA','abs',0x83f8)
C.op('BNE','rel','drain_reset')
C.mark('reset_end');C.op('RTS')

W=Block(0x8357)
W.mark('worker')
# Only invoked with PHASE nonzero: handler/reset check this before JSR.
W.op('LDA','abs',0x83fa);W.op('STA','zp',0xfa)
W.op('LDA','abs',0x83fb);W.op('STA','zp',0xfb)
W.op('LDA','imm',0x40);W.op('STA','abs',0x83fc) # 64 bytes max, physical frame budget
W.op('LDA','abs',0x83f8)
W.op('CMP','imm',2)
W.op('BEQ','rel','color_count')
W.op('LDA','zp',0xfa);W.op('CMP','imm',0xa0)
W.op('BNE','rel','start_map')
W.op('LDA','zp',0xfb);W.op('CMP','imm',0xbb)
W.op('BNE','rel','start_map')
W.op('LDA','imm',0x18);W.op('STA','abs',0x83fc) # last 24 of 2840
W.op('JMP','abs','start_map')
W.mark('color_count')
W.op('LDA','zp',0xfa);W.op('CMP','imm',0xc0)
W.op('BNE','rel','start_map')
W.op('LDA','zp',0xfb);W.op('CMP','imm',0xdb)
W.op('BNE','rel','start_map')
W.op('LDA','imm',0x28);W.op('STA','abs',0x83fc) # last 40 of 1000
W.mark('start_map');W.op('LDY','imm',0)
W.mark('map_loop')
# Color-table data are 4-bit VIC colors (1,11,12,15 in base); masks are harmless
# on both B0A0 arrays and Color RAM. Avoid a branch per byte.
W.op('LDA','indy',0xfa)
W.op('AND','imm',0x0f)
W.op('TAX')
OPS['LDA']['absx']=0xbd;LEN['absx']=3
W.op('LDA','absx',0x8347)
W.op('STA','indy',0xfa)
W.op('INY')
W.op('CPY','abs',0x83fc)
W.op('BNE','rel','map_loop')
W.op('TYA');W.op('CLC');W.op('ADC','zp',0xfa);W.op('STA','abs',0x83fa)
W.op('LDA','zp',0xfb);W.op('ADC','imm',0);W.op('STA','abs',0x83fb)
W.op('LDA','abs',0x83f8);W.op('CMP','imm',2)
W.op('BEQ','rel','check_color_end')
W.op('LDA','abs',0x83fa);W.op('CMP','imm',0xb8)
W.op('BNE','rel','work_done')
W.op('LDA','abs',0x83fb);W.op('CMP','imm',0xbb)
W.op('BNE','rel','work_done')
W.op('LDA','abs',0x38be);W.op('CMP','imm',0xff)
W.op('BEQ','rel','complete')
W.op('LDA','imm',2);W.op('STA','abs',0x83f8)
W.op('LDA','imm',0);W.op('STA','abs',0x83fa)
W.op('LDA','imm',0xd8);W.op('STA','abs',0x83fb)
W.op('RTS')
W.mark('check_color_end')
W.op('LDA','abs',0x83fa);W.op('CMP','imm',0xe8)
W.op('BNE','rel','work_done')
W.op('LDA','abs',0x83fb);W.op('CMP','imm',0xdb)
W.op('BNE','rel','work_done')
W.mark('complete')
W.op('LDA','abs',0x83f9);W.op('STA','abs',0x8346)
W.op('LDA','imm',0);W.op('STA','abs',0x83f8)
W.mark('work_done');W.op('RTS')

blocks=[A,B,C,W]
labels={}
for block in blocks:
 for name,loc in block.labels.items(): assert name not in labels;labels[name]=loc
print("BLOCK_LENGTHS C",hex(C.pc),"W",hex(W.pc),"available",0x83f8-0x8357)
assert C.pc<=0x82f7,(hex(C.pc),'C overflow')
assert W.pc<=0x83f8,(hex(W.pc),'W overlaps state')
for block in blocks:
 out=block.emit(labels)
 buf[block.origin-START:block.origin-START+len(out)]=out
# Critical: zero previously active scanner code that is now unused, prevent accidental entry.
# Do NOT wipe old $8287..$82F6 outside our emitted C block: no branches land there.
# State bytes initially zero, in address range after code before $8400.
for i in range(0x83f8,0x83fd):buf[i-START]=0
assert bytes(buf[:0x81ac-START])==old[:0x81ac-START]
assert bytes(buf[0x81e4-START:0x8287-START])==old[0x81e4-START:0x8287-START]
assert bytes(buf[0x82f7-START:0x8357-START])==old[0x82f7-START:0x8357-START]
assert len(buf)==END-START
assert buf[0x81ac-START]==0x4c and buf[0x81ce-START]==0x4c
assert buf[0x8357-START]==0xad

with ZipFile(SOURCE) as z:
 assert z.testzip() is None
 names=[n for n in z.namelist() if not n.startswith('LEEME_')]
 data={n:z.read(n) for n in names}
ras=data['DEMO.ras'].decode('utf-8-sig')
old_call='''        // Teclas 0..9: aplicar UNA vez por pulsacion, despues de restaurar CIA/IRQ.
        // Exclusivo de DEMO; SYSINFO y OUTRO no ejecutan este modulo.
        if demo_palette_request > 0 then begin
            AlternarPaletasDemo();
            demo_palette_request := 0;
        end;'''
new_call='''        // Teclas 0..9: ChequearEscape solo registra el pedido; ya no
        // ejecutamos el cambio antes de actualizar la animacion.'''
assert ras.count(old_call)==1,ras.count('AlternarPaletasDemo();')
ras=ras.replace(old_call,new_call,1)
end_marker="        end; // FIX18: demo_visual_do_tick\n\n    end;"
assert ras.count(end_marker)==1
ras=ras.replace(end_marker,'''        end; // FIX18: demo_visual_do_tick

        // Palette worker DESPUES del scroll: 64 bytes maximo por cuadro.
        // Mantener fuera de SYSINFO, pantalla final y OUTRO.
        if demo_finished = 0 then begin
            if basic_return_counter <> 255 then begin
                AlternarPaletasDemo();
            end;
        end;

    end;''',1)

# cleanup JSRed once from restart N/S; new reset drains incomplete operation and restores exact gray palette.
assert ras.count('jsr $81CE')==1 and ras.count('jsr $811E')==1
assert ras.count('jsr $81AC')==1
assert 'basic_return_delay_frames : byte = 125;' in ras
assert 'ldx #$50\nintro_black_pause_loop:' in ras
assert 'jsr $8403             ; TODO modulo aprobado: cutoff, ola, espuma,' in ras
# Source comments describe actual palette semantics, no timing changes.
ras=ras.replace('''// PAL DEMO: los algoritmos y 10 paletas residen en BIN aislado $811E.
// La rutina Pascal solo llama al modulo; cero codigo pesado en MAIN.''','''// PALETAS 0..9: detector original intacto; aplicacion diferida en BIN $811E.
// Cada llamada hace como maximo 64 bytes y permite un ultimo pedido en cola.
// En el reinicio N/S, $81CE termina la cola y restaura gris con IRQ detenidas.''',1)
data['DEMO.ras']=(b'\xef\xbb\xbf' if data['DEMO.ras'].startswith(b'\xef\xbb\xbf') else b'') + ras.encode('utf-8')
data['demo_palette_helper.bin']=bytes(buf)

asm=['; RicOS Palette Helper - delta de prueba (direcciones absolutas OrgAsm)',
     '; Base exacta: DEMO_INTRO_OUTRO_VOLUMEN_10_RESTAURADO_FADE_80_OUTRO_125_PRUEBA.zip',
     '; Esta fuente documenta SOLO los bloques cambiados; el resto del BIN conserva los bytes base.',
     '; La rutina original de teclado $811E..$81AB, el constructor de mapas',
     '; $81E4..$824A y las tablas $82F7..$8356 no se modifican.',
     '; El worker usa ZP $FA/$FB como ya hacia el helper anterior.',
     '; REQ=$3758, TEMP=$833D, ACTIVE=$8346, MAP=$8347..$8356.',
     '; PHASE=$83F8 (0 idle,1 datos,2 color RAM), TARGET=$83F9, PTR=$83FA/B, LIMIT=$83FC.',
     '; Remapeo datos fijos 63 bytes al iniciar; después 2840 bytes (B0A0..BBB7),',
     '; por bloques de 64, y finalmente 1000 color RAM (D800..DBE7) en bloques de 64.',
     '; Cuando $38BE=$FF omite color RAM, exactamente igual que el helper original.',
     '; En N/S se termina cualquier remapeo y se restaura gris antes de reiniciar.',
     '; Fragmentos ASM con .org explicitos y etiquetas; el script de build fija bytes y valida offsets.', '']
for b in blocks:
 asm.append(f'; BLOQUE ${b.origin:04X} .. ${b.pc-1:04X}')
 asm.append(f'    .org ${b.origin:04X}')
 labs_by_loc={loc:name for name,loc in b.labels.items()}
 for at,cmd,mode,operand in b.items:
  if at in labs_by_loc:asm.append(labs_by_loc[at]+':')
  s='' if mode=='imp' else ('#' if mode=='imm' else '') + (f'${operand:04X}' if isinstance(operand,int) and mode=='abs' else f'${operand:02X}' if isinstance(operand,int) and mode in ('imm','zp','indy','absx') else str(operand))
  if mode=='indy':s='('+s+'),Y'
  if mode=='absx':s=s+',X'
  asm.append(f'    {cmd.lower()} {s}  ; ${at:04X}'.rstrip())
 asm.append('')
data['demo_palette_deferred_patch.asm']='\n'.join(asm).encode('utf-8')
data['build_palette_async.py']=Path(__file__).read_bytes()
notes='''RicOS / Flashparty 2026 - PALETAS DIFERIDAS EN BLOQUES DE 64 (PRUEBA)
===================================================================
Base: DEMO_INTRO_OUTRO_VOLUMEN_10_RESTAURADO_FADE_80_OUTRO_125_PRUEBA.zip
El nuevo ZIP contiene el proyecto completo; no mezclar con versiones anteriores.

CAMBIO: el escaneo original de teclas 0..9 queda intacto. DEMO.ras llama
al modulo al FINAL de cada vuelta, DESPUES de actualizar la animacion, sin
borrar la solicitud desde Pascal. Cuando el helper
esta libre, crea el mapa old->new, remapea las 63 entradas auxiliares e inicia
su puntero. Cada cuadro procesa como maximo 64 bytes del bloque fijo
$B0A0-$BBB7 y, luego, $D800-$DBE7 cuando el flag original lo autoriza.
En vez de bloquear ~3.800 accesos en un solo cuadro, se hacen 60+ pasos
pequenos. Una tecla posterior permanece en cola, se aplica una vez termine
la anterior, sin remapear dos veces accidentalmente un bloque a medio cambiar.

LIMITACION VISUAL: color RAM solo tiene una copia. Al actualizarse en bloques,
es posible observar una transicion espacial durante algunos cuadros; NO se
promete un cambio atomico sin mezcla de paletas. Preservar continuidad del
scroll es la prioridad de esta PRIMERA prueba. Si la transicion visible no
agrada, se debe disenar un commit ligado a una pantalla negra/ocultacion.

REINICIO N/S: al detenerse la demo se completa cualquier transferencia
pendiente y se remapea al gris en la ruta original de restauracion.

Conservados byte a byte: todos los BIN excepto demo_palette_helper.bin.
Conservados en DEMO.ras: audio INTRO/OUTRO, 80 cuadros de fade de salida,
125 de espera OUTRO, distribucion de filas, SID, codigo raster y timings
PAL B/NTSC/Drean (excepto la unica llamada al helper y comentarios).

USO: descomprimir en carpeta nueva, compilar DEMO.ras con TRSE/OrgAsm.
Verificacion estatica/CRC/limites: SI. Compilacion TRSE y pruebas en
WinVICE y hardware PAL B/NTSC/Drean: PENDIENTES. MASTER NO MODIFICADO.
'''
with ZipFile(DEST,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
 z.writestr('LEEME_PALETAS_DIFERIDAS.txt',notes.encode('utf-8'))
with ZipFile(DEST) as z, ZipFile(SOURCE) as base:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 changed={n for n in names if z.read(n)!=base.read(n)}
 assert changed=={'DEMO.ras','demo_palette_helper.bin'},changed
 bins=[n for n in names if n.endswith('.bin')]
 assert all(z.read(n)==base.read(n) for n in bins if n!='demo_palette_helper.bin')
 assert len(re.findall(r'incbin\("([^"\n]+)"',ras))==48
 assert set(re.findall(r'incbin\("([^"\n]+)"',ras)).issubset(z.namelist())
 print('PASS ZIP CRC; files',len(z.namelist()),'all 48 incbin dependencies present.')
 print('PASS only changed existing files:',', '.join(sorted(changed)))
 print('PASS palette code locations: init $%04X..$%04X; handler/reset $%04X..$%04X; worker $%04X..$%04X.'%(C.origin,labels['handle']-1,labels['handle'],C.pc-1,W.origin,W.pc-1))
 print('PASS palette helper size',len(buf),'ends $%04X'%(START+len(buf)-1),'before $8400 audio; state starts $83F8.')
 print('PASS original keyboard, mapper and palette tables preserved; music, audio and screen resources unchanged.')
 print('NOTE TRSE compilation, emulator and hardware testing NOT performed.')
 print('OUTPUT',DEST,'SIZE',DEST.stat().st_size,'SHA256',hashlib.sha256(DEST.read_bytes()).hexdigest())
